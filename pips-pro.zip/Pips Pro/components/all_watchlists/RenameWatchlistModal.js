import { View, Platform, TouchableOpacity, Text, TextInput, KeyboardAvoidingView } from "react-native";
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';
import { authScreens } from "../../styles/auth_screens";
import { Button } from "@rneui/themed";
import { ScrollView } from "react-native-gesture-handler";
import { useCallback, useMemo, useRef, useState } from "react";
import { useFocusEffect } from "@react-navigation/native";
import { snackBarStyles } from "../../styles/snackbar";
import { Snackbar } from "react-native-paper";
import { MaterialIcons } from '@expo/vector-icons';
import { Formik } from "formik";
import { object, string } from 'yup';
import { rename_watchlist } from "../../reusable_methods/all_watchlists/rename_watchlist";

const RenameWatchlistSchema = object({
    watchlist: string().required('This field is required')
})

// Display a modal where the user can rename their watchlists
export function RenameWatchlistModal({ route, navigation }) {
    const { current_watchlist_id, watchlist_name } = route.params; // Route parameters
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [loading, set_loading] = useState(false);
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);
    const controller = useRef(new AbortController());
    const formikRef = useRef();
    const [watchlist_name_state, set_watchlist_name_state] = useState(watchlist_name);

    // Memoize the styles to avoid recalculating them on each render
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort(); // Cancel all pending requests
                controller.current = new AbortController();
                set_snackbar_toggle(false);
                set_snackbar_err(false);
                set_snackbar_msg('');
            }
        }, [])
    )

    return (
        <KeyboardAvoidingView keyboardVerticalOffset={20} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', height: 43, marginTop: 13, paddingHorizontal: 16 }}>
                <View style={{ width: 31.0, height: 31.0 }}></View>
                <Text style={{ color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontWeight: 'bold', fontSize: 18 }}>Rename watchlist</Text>
                <TouchableOpacity onPress={() => navigation.goBack()}><AntDesign name="closecircleo" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity>
            </View>

            <ScrollView style={{ flex: 1 }}>
                <Formik
                    innerRef={formikRef}
                    initialValues={{ watchlist: watchlist_name }}
                    validationSchema={RenameWatchlistSchema}
                    onSubmit={(values) => rename_watchlist(controller, watchlist_name_state, set_watchlist_name_state, current_watchlist_id, watchlist_name, values.watchlist, navigation, loading, set_loading, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err)}
                >
                    {({ handleChange, handleSubmit, values, errors, touched, handleBlur }) => (
                        <View style={{ paddingHorizontal: 16, marginTop: 76 }}>
                            <View style={[authScreens.email_or_username_inp_container, { borderColor: (errors.watchlist && touched.watchlist) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                                <TextInput
                                    style={[authScreens.email_or_username_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                                    placeholder="Watchlist Name"
                                    editable={loading === true ? false : true}
                                    placeholderTextColor={'#999696'}
                                    value={values.watchlist}
                                    keyboardType="default"
                                    keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                                    textContentType='none'
                                    onBlur={handleBlur('watchlist')} 
                                    onChangeText={handleChange('watchlist')}
                                />
                            </View>
                            { (touched.watchlist && errors.watchlist) ? (<Text style={authScreens.errorText}>{errors.watchlist}</Text>) : '' }

                            <View style={authScreens.btn_container}>
                                <Button title="Rename" onPress={handleSubmit} loading={loading} titleStyle={authScreens.btn_font} containerStyle={{ width: '100%' }} buttonStyle={authScreens.btn} />
                            </View>
                        </View>
                    )}
                </Formik>
            </ScrollView>

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>
        </KeyboardAvoidingView>
    );
}