import { View, Text, RefreshControl } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';
import { refresh_active_watchlist } from '../../reusable_methods/watchlist/refresh_active_watchlist';
import { useCallback, useMemo } from 'react';
import { Button } from '@rneui/themed';
import { authScreens } from '../../styles/auth_screens';
import { channels } from '../../styles/channels';

export function WatchlistData({ watchlist_state, refreshing, setRefreshing, refresh_controller, navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    // Memoize the styles to avoid recalculating them on each render
    const channels_styles = useMemo(() => channels(is_darkmode), [is_darkmode]);

    // Listen to pull to refresh event
    const onRefresh = useCallback(async () => {
        await refresh_active_watchlist(refresh_controller, setRefreshing);
    }, []);

    return (
        <ScrollView
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30 }}
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <AntDesign name="inbox" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />

                {
                    watchlist_state === false ?
                        <View style={{ alignItems: 'center' }}>
                            <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>You have no watchlists available. Create a new watchlist below</Text>
                            <Button title="Create" onPress={() => navigation.navigate('CreateWatchlistModal')} titleStyle={authScreens.btn_font} containerStyle={channels_styles.btn_width} buttonStyle={channels_styles.btn} />
                        </View>
                    : watchlist_state === 'no_access' ?
                        <View style={{ alignItems: 'center' }}>
                            <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>Login to view your watchlists</Text>
                            <Button title="Login" onPress={() => navigation.navigate('Login')} titleStyle={authScreens.btn_font} containerStyle={channels_styles.btn_width} buttonStyle={channels_styles.btn} />
                        </View>
                    : <></>
                }
            </View>
        </ScrollView>
    );
}