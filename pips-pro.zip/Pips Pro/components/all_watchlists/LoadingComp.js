import { watchList } from "../../styles/watchlist";
import { useSelector } from 'react-redux';
import { View, FlatList } from "react-native";
import { Skeleton } from "@rneui/themed";
import { useMemo } from "react";

// A skeleton loader for the active watchlist
export function LoadingComp({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    const renderItem = ({ item }) => {
        return (
            <View style={{ flexDirection: 'column', paddingLeft: 17, paddingRight: 17, marginBottom: 16, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
                <Skeleton animation='wave' width={130} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginBottom: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                <Skeleton animation='wave' width="100%" style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 10 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
            </View>
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [watchList, is_darkmode]);

    return (
        <FlatList
            style={[watchList.modal_flatlist, { paddingTop: 15 }]}
            scrollEnabled={false}
            data={Array.from({length: 10}, (_, i) => i + 1)}
            renderItem={memoizedRenderItem}
            keyExtractor={(item) => item}
        />
    );
}