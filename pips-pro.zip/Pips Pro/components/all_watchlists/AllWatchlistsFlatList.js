import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { useSelector } from "react-redux";
import { useMemo } from "react";
import { allWatchlists } from "../../styles/all_watchlists";
import { watchList } from "../../styles/watchlist";
import { useActionSheet } from '@expo/react-native-action-sheet';
import { menu_sheet } from "../../reusable_methods/all_watchlists/menu_sheet";
import { view_action } from "../../reusable_methods/all_watchlists/menu_sheet_actions/view_action";

// All the users watchlists
export function AllWatchlistsFlatList({ navigation, handleScroll, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, loading_modal, set_loading_modal, delete_watchlist_controller }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const all_watchlists = useSelector((state) => state.watch_list_state.all_watchlists); // The users watchlists
    const { showActionSheetWithOptions } = useActionSheet();

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    const renderItem = ({ item, index }) => {
        return (
            <View>
                <TouchableOpacity onPress={() => view_action(navigation, item.id)} onLongPress={() => menu_sheet(showActionSheetWithOptions, is_darkmode, navigation, item.active_watchlist_id, item.id, item.name, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, loading_modal, set_loading_modal, delete_watchlist_controller)} delayLongPress={200} style={{ backgroundColor: item.active_watchlist_id === item.id ? '#f19200' : (is_darkmode === true ? '#000000' : '#ffffff') }}>
                    <View style={all_watchlists_styles.watchlist_item}>
                        <Text style={[all_watchlists_styles.watchlist_name, { color: item.active_watchlist_id === item.id ? '#ffffff' : (is_darkmode === true ? '#ffffff' : '#000000') }]}>{item.name}</Text>
                        <View style={[all_watchlists_styles.symbols_list, { height: 20.5 }]}>
                            {
                                item.symbols.length > 0 ?
                                    item.symbols.map((symbol, symbol_index) => (
                                        <Text key={symbol_index} style={{ marginLeft: (symbol_index > 0) ? 6 : 0, fontFamily: 'RobotoRegular', fontSize: 17, color: item.active_watchlist_id === item.id ? '#ffffff' : (is_darkmode === true ? '#ffffff' : '#000000') }}>{symbol.symbol}</Text>
                                    ))
                                : <Text style={{ fontFamily: 'RobotoRegular', fontSize: 17 }}>   </Text>
                            }
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [watchList, all_watchlists_styles]);

    return (
        <FlatList
            style={[watchList.flatlist_br, { paddingTop: 15 }]}
            data={all_watchlists}
            onScroll={handleScroll}
            showsVerticalScrollIndicator={true}
            renderItem={memoizedRenderItem}
            keyExtractor={(item) => item.index}
        />
    );
}