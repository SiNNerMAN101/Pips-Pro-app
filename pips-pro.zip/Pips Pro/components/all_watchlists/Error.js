import { View, Text, RefreshControl } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSelector } from 'react-redux';
import { MaterialIcons } from '@expo/vector-icons';
import { useCallback } from 'react';
import { refresh_active_watchlist } from '../../reusable_methods/watchlist/refresh_active_watchlist';

export function Error({ refreshing, setRefreshing, refresh_controller }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    // Listen to pull to refresh event
    const onRefresh = useCallback(async () => {
        await refresh_active_watchlist(refresh_controller, setRefreshing);
    }, []);

    return (
        <ScrollView
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30 }}
            refreshControl={
                <RefreshControl
                    tintColor={is_darkmode ? '#ffffff' : '#000000'} // color of the spinner
                    colors={['#000000']} // Android-specific spinner color
                    refreshing={refreshing}
                    onRefresh={onRefresh}
                />
            }
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <MaterialIcons name="report-gmailerrorred" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>Your watchlists couldn't be fetched</Text>
            </View>
        </ScrollView>
    );
}