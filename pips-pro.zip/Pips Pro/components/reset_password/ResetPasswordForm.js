import { TextInput, View, Text, TouchableOpacity } from 'react-native';
import { authScreens } from "../../styles/auth_screens";
import { useCallback, useRef, useState } from "react";
import { Button } from '@rneui/themed';
import { Formik } from "formik";
import { object, string } from 'yup';
import { useFocusEffect } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { reset_user_password } from '../../reusable_methods/forgot_password/reset_user_password';
import { Ionicons } from '@expo/vector-icons';

const PasswordSchema = object({
    new_password: string().required('This field is required').min(7, 'Password must be at least 7 characters').max(7, 'Password must be at least 7 characters').test('password-must-be-a-mix-of-numbers-and-letters', 'Password must have both letters and numbers', (val) => {
        var validRegex = /^(?=.*[a-zA-Z])(?=.*[0-9]).{6,}$/;
        return val.match(validRegex);
    })
})

export function ResetPasswordForm({ route, navigation, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [user_details, set_user_details] = useState({ user_id: 0, confirmation_code: '' });
    const [is_loading, set_is_loading] = useState(false); // State of the continue/login button
    const [controller, set_controller] = useState(new AbortController()); // Abort controller for canceling pending requests
    const [secure_password, set_secure_password] = useState(true);

    const formikRef = useRef();

    // This hook will be called when the screen is focused
    useFocusEffect(
        useCallback(() => {
            // This hook will be called when the screen is focused
            const get_route_params = () => {
                let route_params = route.params;

                if (route_params && route_params.user_id && route_params.confirmation_code) {
                    set_user_details({ user_id: route_params.user_id, confirmation_code: route_params.confirmation_code }); // Store user details in the state
                }
            }
    
            get_route_params();

            return () => {
                controller.abort();
                // This function will be called when the screen loses focus
                setTimeout(() => {
                    set_controller(new AbortController()); // Reset the abort controller to generate a new signal
                    set_snackbar_toggle(false); set_is_loading(false);
                    set_secure_password(true);
                    formikRef.current?.resetForm(); // Reset signup form
                }, 500);
            };
        }, [])
    );

    return (
        <Formik
            innerRef={formikRef}
            initialValues={{ new_password: '' }}
            validationSchema={PasswordSchema}
            onSubmit={(values) => reset_user_password(values.new_password, user_details.user_id, user_details.confirmation_code, navigation, is_loading, set_is_loading, controller, set_controller, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err)}
        >
            {({ handleChange, handleSubmit, values, errors, touched, handleBlur }) => (
                <View style={authScreens.formBody}>
                    <View style={[authScreens.password_inp_container, { borderColor: (errors.new_password && touched.new_password) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                        <TextInput
                            style={[authScreens.password_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                            placeholder="New Password"
                            editable={is_loading === true ? false : true}
                            placeholderTextColor={'#999696'}
                            secureTextEntry={secure_password}
                            value={values.new_password}
                            keyboardType="default"
                            keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                            onBlur={handleBlur('new_password')} 
                            onChangeText={handleChange('new_password')}
                        />
                        <TouchableOpacity onPress={() => set_secure_password(!secure_password)}>
                            <Ionicons name={secure_password === true ? "eye-off" : "eye"} size={25} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                        </TouchableOpacity>
                    </View>
                    { (touched.new_password && errors.new_password) ? (<Text style={authScreens.errorText}>{errors.new_password}</Text>) : '' }

                    <View style={authScreens.btn_container}>
                        <Button title="Reset Password" loading={is_loading === true ? true : false} titleStyle={authScreens.btn_font} containerStyle={{ width: '100%' }} buttonStyle={authScreens.btn} onPress={handleSubmit} />
                    </View>
                </View>
            )}
        </Formik>
    );
}