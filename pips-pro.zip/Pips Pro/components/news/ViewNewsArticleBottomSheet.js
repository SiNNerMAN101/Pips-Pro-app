import { View, TouchableOpacity, Text } from 'react-native';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';
import BottomSheet, { BottomSheetBackdrop, BottomSheetScrollView } from "@gorhom/bottom-sheet";
import { useCallback, useState } from 'react';
import { SignalCardImage } from '../watchlist/SignalCardImage';
import * as WebBrowser from 'expo-web-browser';
import { Skeleton } from '@rneui/themed';

// Display details about the current selected news article
export function ViewNewsArticleBottomSheet({ sheetRef, news_article, snapPoints, handleSheetChange, handleClosePress }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const [result, setResult] = useState(null);
    
    // Open web browser to display website that contains the full details of the news article
    const handleOpenBrowser = async (url) => {
        let result = await WebBrowser.openBrowserAsync(url);
        setResult(result);
    };

    // Backdrop of the bottomsheet
    const renderBackdrop = useCallback(
		(props) => (
			<BottomSheetBackdrop
				{...props}
				disappearsOnIndex={-1}
				appearsOnIndex={0}
			/>
		),
		[]
	);

    return (
        <BottomSheet
            ref={sheetRef}
            index={-1}
            snapPoints={snapPoints}
            onChange={handleSheetChange}
            backdropComponent={renderBackdrop}
            enablePanDownToClose={true}
            handleIndicatorStyle={{
                backgroundColor: is_darkmode === true ? '#E4E7EC' : '#a7abb1',
                width: 50,
            }}
            handleStyle={{ backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 1, borderStyle: 'solid', borderTopLeftRadius: 10, borderTopRightRadius: 10 }}
        >
            <View style={{ flexDirection: 'row', position: 'absolute', top: 0, left: 0, right: 0, zIndex: 1, backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', alignContent: 'center', justifyContent: 'flex-end', paddingHorizontal: 16, paddingVertical: 10, paddingBottom: 15, borderTopColor: is_darkmode === true ? '#131722' : '#ffffff', borderBottomWidth: 1, borderBottomColor: is_darkmode === true ? '#434651' : '#e0e3eb', borderStyle: 'solid' }}>
                <TouchableOpacity onPress={() => handleClosePress()}><AntDesign name="closecircleo" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity>
            </View>
            
            <BottomSheetScrollView style={{ flex: 1, backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', marginTop: 50, paddingHorizontal: 16 }} showsVerticalScrollIndicator={true}>
                <Text style={{ fontSize: 23, fontFamily: 'RobotoBold', fontWeight: 'bold', color: is_darkmode === true ? '#ffffff' : '#000000', marginTop: 20 }}>{news_article.title}</Text>

                <View style={{ marginTop: 30 }}>
                    { 
                        news_article.banner_image === '' ? 
                            <Skeleton animation='wave' width='100%' style={{ backgroundColor: '#dedede', borderRadius: 8 }} skeletonStyle={{ backgroundColor: '#d1d1d1' }} height={200} />
                        : <SignalCardImage img_url={news_article.banner_image} /> 
                    }
                </View>

                <Text style={{ alignItems: 'center', fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#7f7f7f' : '#727272', marginTop: 15, fontSize: 15 }}>{news_article.time_published}</Text>
                
                {
                    news_article.summary !== '' ?
                        <Text style={{ fontSize: 17, fontFamily: 'RobotoRegular', lineHeight: 27, marginTop: 15, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{news_article.summary}</Text>
                    : <></>
                }

                <TouchableOpacity onPress={() => handleOpenBrowser(news_article.url)}><Text style={{ color: '#f19200', fontFamily: 'RobotoRegular', fontSize: 17, marginBottom: 50, marginTop: 15 }}>Click this link to read more...</Text></TouchableOpacity>
            </BottomSheetScrollView>
        </BottomSheet>
    );
}