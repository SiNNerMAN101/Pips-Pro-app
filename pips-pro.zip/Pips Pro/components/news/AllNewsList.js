import { View, TouchableOpacity, Text, FlatList, RefreshControl, Platform } from 'react-native';
import { useSelector } from 'react-redux';
import { Skeleton } from '@rneui/themed';
import { useCallback, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { fetch_latest_news } from '../../reusable_methods/news/fetch_latest_news';
import { store } from '../../store/store';
import { set_news_state } from '../../state/news';
import { format_datetime } from '../../reusable_methods/news/format_datetime';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ScrollView } from 'react-native-gesture-handler';
import { Image } from 'expo-image';

// Display the news list for both company stocks, crypto and forex
export function AllNewsList({ navigation, handleSnapPress, news_scroll_ref }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const news_state = useSelector((state) => state.news.news_state); // all news
    const [news, set_news] = useState([]);
    const [controller, set_controller] = useState(new AbortController());
    const [refreshing, set_refreshing] = useState(false);

    const execute = useCallback(async () => {
        await fetch_latest_news(news, set_news, controller, set_refreshing);
    });

    // Refresh to fetch latest news
    const handleRefresh = async () => {
        if (refreshing === false){
             // Set refreshing to true to show the loading indicator
            set_refreshing(true);

            store.dispatch(set_news_state({ value: 'loading' }));
            set_news([]);
            await fetch_latest_news(news, set_news, controller, set_refreshing);
        }
    };

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus           
            execute();
        
            // Return a cleanup function to run when the screen loses focus
            return () => {
                // Run this function when the screen loses focus
                controller.abort();
                setTimeout(() => {
                    store.dispatch(set_news_state({ value: 'loading' }));
                }, 250);
            };
        }, [])
    );

    const insets = useSafeAreaInsets();

    return (
        <View style={{ flex: 1 }}>
            {
                news_state === true ?
                    <FlatList 
                        style={{ backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', padding: 20, paddingVertical: 30, flex: 1 }}
                        showsHorizontalScrollIndicator={false}
                        ref={news_scroll_ref}
                        refreshControl={
                            <RefreshControl
                                colors={[is_darkmode === true ? '#ffffff' : '#000000']}
                                tintColor={is_darkmode === true ? '#ffffff' : '#000000'}
                                style={{ height: 0 }}
                                refreshing={refreshing}
                                onRefresh={handleRefresh}
                            />
                        }
                        data={news}
                        renderItem={({ item, index }) => (
                            <TouchableOpacity style={{ marginBottom: index !== news.length - 1 ? 40 : (Platform.OS === 'ios' ? 80 : 54) }} onPress={() => handleSnapPress(0, { title: item.headline, time_published: format_datetime(item.datetime, item.source), source: item.source, summary: item.summary, banner_image: item.image, url: item.url })} key={index}>
                                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                    <Text style={{ alignItems: 'center', fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#7f7f7f' : '#727272' }}>{format_datetime(item.datetime, item.source)}</Text>
                                </View>
                                <Text style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', marginTop: 10, fontSize: 20, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.headline}</Text>
                            </TouchableOpacity>
                        )}
                        keyExtractor={(item) => item.id}
                    />
                : news_state === 'loading' ?
                    <FlatList 
                        style={{ backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', padding: 20, paddingVertical: 30, flex: 1 }}
                        showsHorizontalScrollIndicator={false}
                        data={[1, 2, 3, 4, 5, 6]}
                        renderItem={({ item, index }) => (
                            <View style={{ marginBottom: index !== news.length - 1 ? 40 : (Platform.OS === 'ios' ? 80 : 54) }} key={index}>
                                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                    <Skeleton animation='wave' width={120} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede' }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={20} />
                                </View>
                                <View style={{ marginTop: 10 }}>
                                    <Skeleton animation='wave' width='100%' style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede' }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={20} />
                                    <Skeleton animation='wave' width='100%' style={{ marginTop: 6, backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede' }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={20} />
                                </View>
                            </View>
                        )}
                    />
                : news_state === false ?
                    <ScrollView
                        refreshControl={
                            <RefreshControl
                                colors={[is_darkmode === true ? '#ffffff' : '#000000']}
                                tintColor={is_darkmode === true ? '#ffffff' : '#000000'}
                                style={{ height: 0 }}
                                refreshing={refreshing}
                                onRefresh={handleRefresh}
                            />
                        }
                        contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
                        style={{ flex: 1, padding: 20, paddingVertical: 30 }}
                    >
                        <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                            <Image
                                style={{ width: 105, height: 105 }}
                                allowDownscaling={false}
                                source={is_darkmode === true ? require('../../assets/net_err_white.png') : require('../../assets/net_err_black.png')}
                                contentFit="cover"
                            />
                            <Text style={{ marginTop: 15, color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>Couldn't fetch news, check your network</Text>
                        </View>
                    </ScrollView>
                : <></>
            }
        </View>
    );
}