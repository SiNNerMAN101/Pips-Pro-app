import { useSelector } from 'react-redux';
import { useMemo } from "react";
import { Text, View, Platform, TouchableOpacity } from 'react-native';
import { allWatchlists } from '../../styles/all_watchlists';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AntDesign } from '@expo/vector-icons';
import { createIdeaStyles } from '../../styles/create_idea';
import IdeaTypeField from './fields_from_final_touches/IdeaTypeField';
import ContentField from './fields_from_final_touches/ContentField';
import MarketTypeField from './fields_from_final_touches/MarketTypeField';
import CategoryField from './fields_from_final_touches/CategoryField';

export default function FinalTouches({ set_current_view, navigation, title, body, form_info, set_form_info }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const insets = useSafeAreaInsets();

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);
    const create_idea_styles = useMemo(() => createIdeaStyles(is_darkmode, insets), [is_darkmode, insets]);

    return (
        <KeyboardAwareScrollView enableOnAndroid={true} enableAutomaticScroll={(Platform.OS === 'ios')} style={[all_watchlists_styles.native_header, create_idea_styles.scroll_view]}>
            <View style={create_idea_styles.header}>
                <View style={create_idea_styles.header_left}></View>
                <Text style={create_idea_styles.header_title}>Final touches</Text>
                <TouchableOpacity onPress={() => set_current_view(2)}><AntDesign name="back" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity>
            </View>
            
            <View style={[create_idea_styles.mt25, create_idea_styles.mb36]}>
                <IdeaTypeField form_info={form_info} set_form_info={set_form_info} />

                <ContentField form_info={form_info} set_form_info={set_form_info} />

                <MarketTypeField navigation={navigation} form_info={form_info} />

                <CategoryField navigation={navigation} />
            </View>
        </KeyboardAwareScrollView>
    );
}