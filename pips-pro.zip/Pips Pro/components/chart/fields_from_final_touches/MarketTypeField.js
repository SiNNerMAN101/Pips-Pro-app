import { useSelector } from 'react-redux';
import { useMemo } from "react";
import { Text, View, TouchableOpacity, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { createIdeaStyles } from '../../../styles/create_idea';
import { Ionicons } from '@expo/vector-icons';

export default function MarketTypeField({ navigation, form_info }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const user_selected_market_type = useSelector((state) => state.chart.user_selected_market_type); // The market type that the user selected
    const insets = useSafeAreaInsets();

    // Memoize the styles to avoid recalculating them on each render
    const create_idea_styles = useMemo(() => createIdeaStyles(is_darkmode, insets), [is_darkmode, insets]);

    return (
        <View style={create_idea_styles.mt30}>
            <Text style={create_idea_styles.form_field_title}>Market type</Text>
            <View style={create_idea_styles.field_view2}>
                <Pressable onPress={() => navigation.navigate('MarketTypeModal')} style={{ flexDirection: 'row', flex: 1, marginLeft: 10, alignItems: 'center', justifyContent: 'space-between' }}>
                    {
                        user_selected_market_type !== null ?
                            <Text style={{ color: '#ffffff', fontSize: 17, fontFamily: 'RobotoBold' }}>{user_selected_market_type === 1 ? 'Stock' : user_selected_market_type === 2 ? 'Forex' : 'Crypto'}</Text>
                        : <Text style={{ color: '#999696', fontSize: 17, fontFamily: 'RobotoRegular' }}>Select a market type</Text>
                    }
                    
                    <TouchableOpacity onPress={() => navigation.navigate('MarketTypeModal')} style={create_idea_styles.caret}>
                        <Ionicons name="caret-down-circle-outline" size={21} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                </Pressable>
            </View>
        </View> 
    );
}