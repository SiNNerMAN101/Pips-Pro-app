import { useSelector } from 'react-redux';
import { useMemo } from "react";
import { Text, View, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { createIdeaStyles } from '../../../styles/create_idea';

export default function ContentField({ form_info, set_form_info }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const insets = useSafeAreaInsets();

    const toggle_content = (value) => {
        set_form_info({ idea_type: form_info.idea_type, content: value, read_length: form_info.read_length });
    }

    // Memoize the styles to avoid recalculating them on each render
    const create_idea_styles = useMemo(() => createIdeaStyles(is_darkmode, insets), [is_darkmode, insets]);

    return (
        <View style={create_idea_styles.mt30}>
            <Text style={create_idea_styles.form_field_title}>Content</Text>
            <View style={create_idea_styles.field_view}>
                <View style={create_idea_styles.toggle_view}>
                    <TouchableOpacity onPress={() => toggle_content(1)} style={[ create_idea_styles.field_toggle_tab, { backgroundColor: form_info.content === 1 ? '#3a3a3a' : (is_darkmode === true ? '#000000' : '#ffffff') } ]}>
                        <Text style={[ create_idea_styles.field_toggle_text, { fontFamily: form_info.content === 1 ? 'RobotoBold' : 'RobotoRegular' } ]}>Analysis</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => toggle_content(2)} style={[ create_idea_styles.field_toggle_tab, { backgroundColor: form_info.content === 2 ? '#3a3a3a' : (is_darkmode === true ? '#000000' : '#ffffff') } ]}>
                        <Text style={[ create_idea_styles.field_toggle_text, { fontFamily: form_info.content === 2 ? 'RobotoBold' : 'RobotoRegular' } ]}>Tutorial</Text>
                    </TouchableOpacity>
                </View>
            </View>
            {
                form_info.content === 1 ?
                    <Text style={create_idea_styles.form_field_desc}>The content of this idea should be based on a detailed market analysis, technical predictions, buy/sell signals or a forecast of price movements. This typically involves charts, indicators, and your interpretation of market conditions.</Text>
                : <Text style={create_idea_styles.form_field_desc}>This idea should share educational content or explaining a trading concept. This could be a step-by-step guide, a how-to, or tips aimed at teaching others about specific trading strategies or tools.</Text>
            }
        </View>
    );
}