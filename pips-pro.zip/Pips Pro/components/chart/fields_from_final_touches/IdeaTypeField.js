import { useSelector } from 'react-redux';
import { useMemo } from "react";
import { Text, View, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AntDesign } from '@expo/vector-icons';
import { createIdeaStyles } from '../../../styles/create_idea';

export default function IdeaTypeField({ form_info, set_form_info }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const insets = useSafeAreaInsets();

    const toggle_idea_type = (value) => {
        set_form_info({ idea_type: value, content: form_info.content, read_length: form_info.read_length });
    }

    // Memoize the styles to avoid recalculating them on each render
    const create_idea_styles = useMemo(() => createIdeaStyles(is_darkmode, insets), [is_darkmode, insets]);

    return (
        <View>
            <Text style={create_idea_styles.form_field_title}>Idea type</Text>
            <View style={create_idea_styles.field_view}>
                <View style={create_idea_styles.toggle_view}>
                    <TouchableOpacity onPress={() => toggle_idea_type(1)} style={[ create_idea_styles.field_toggle_tab, { backgroundColor: form_info.idea_type === 1 ? '#3a3a3a' : (is_darkmode === true ? '#000000' : '#ffffff') } ]}>
                        <Text style={[ create_idea_styles.field_toggle_text, { fontFamily: form_info.idea_type === 1 ? 'RobotoBold' : 'RobotoRegular' } ]}>Public</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => toggle_idea_type(2)} style={[ create_idea_styles.field_toggle_tab2, { backgroundColor: form_info.idea_type === 2 ? '#3a3a3a' : (is_darkmode === true ? '#000000' : '#ffffff') } ]}>
                        <AntDesign name="lock1" size={20} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                        <Text style={[ create_idea_styles.field_toggle_text, { fontFamily: form_info.idea_type === 2 ? 'RobotoBold' : 'RobotoRegular', marginLeft: 6 } ]}>Private</Text>
                    </TouchableOpacity>
                </View>
            </View>
            {
                form_info.idea_type === 1 ?
                    <Text style={create_idea_styles.form_field_desc}>This idea will be visible to all users and will appear on public pages, including your profile, as well as in both public and private channels.</Text>
                : <Text style={create_idea_styles.form_field_desc}>This idea will only be visible to users in private channels that you’ve created or are a member of and will not be displayed on public pages including your profile.</Text>
            }
        </View>
    );
}