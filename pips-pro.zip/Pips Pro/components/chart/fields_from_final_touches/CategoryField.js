import { useDispatch, useSelector } from 'react-redux';
import { useMemo } from "react";
import { Text, View, TouchableOpacity, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { createIdeaStyles } from '../../../styles/create_idea';
import { Ionicons } from '@expo/vector-icons';
import { remove_category } from '../../../state/chart';

export default function CategoryField({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const insets = useSafeAreaInsets();
    const dispatch = useDispatch();
    const user_selected_categories = useSelector((state) => state.chart.user_selected_categories); // The list of the categories that the user has selected

    // Memoize the styles to avoid recalculating them on each render
    const create_idea_styles = useMemo(() => createIdeaStyles(is_darkmode, insets), [is_darkmode, insets]);

    return (
        <View style={create_idea_styles.mt30}>
            <Text style={create_idea_styles.form_field_title}>Category</Text>
            <View style={create_idea_styles.field_view2}>
                {
                    user_selected_categories.length > 0 ?
                        <>
                            <ScrollView horizontal={true}>
                                {
                                    user_selected_categories.map((category, index) => (
                                        <View key={index} style={[create_idea_styles.field_toggle_tab3, { marginLeft: index > 0 ? 8 : 0 }]}>
                                            <Text style={create_idea_styles.field_toggle_text2}>{category.title}</Text>
                                            <Pressable onPress={() => dispatch(remove_category({ id: category.id }))}>
                                                <Ionicons name="close" style={{ marginLeft: 8 }} size={16} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                                            </Pressable>
                                        </View>
                                    ))
                                }
                            </ScrollView>
                            <TouchableOpacity style={create_idea_styles.caret} onPress={() => navigation.navigate('IdeaCategoryModal')}>
                                <Ionicons name="caret-down-circle-outline" size={21} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                            </TouchableOpacity>
                        </>
                    :   <Pressable onPress={() => navigation.navigate('IdeaCategoryModal')} style={{ flexDirection: 'row', flex: 1, marginLeft: 10, alignItems: 'center', justifyContent: 'space-between' }}>
                            <Text style={{ color: '#999696', fontSize: 17, fontFamily: 'RobotoRegular' }}>Select any categories</Text>
                            <TouchableOpacity onPress={() => navigation.navigate('IdeaCategoryModal')} style={create_idea_styles.caret}>
                                <Ionicons name="caret-down-circle-outline" size={21} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                            </TouchableOpacity>
                        </Pressable>
                }
            </View>
        </View>
    );
}