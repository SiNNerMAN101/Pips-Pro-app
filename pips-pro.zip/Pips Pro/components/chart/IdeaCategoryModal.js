import { FlatList, Text, TouchableOpacity } from 'react-native';;
import { useDispatch, useSelector } from 'react-redux';
import BottomSheet, { BottomSheetBackdrop, BottomSheetView } from "@gorhom/bottom-sheet";
import { useCallback, useMemo, useState } from 'react';
import { Easing } from 'react-native-reanimated'; // Use Easing from Reanimated
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { Divider, ListItem } from '@rneui/themed';
import { Icon } from 'react-native-paper';
import { allWatchlists } from '../../styles/all_watchlists';
import { update_category_expansion, update_main_category_list_chkbox, update_sub_category_list_chkbox } from '../../state/chart';

export function IdeaCategoryModal({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // State of the app if user is logged in or not
    const insets = useSafeAreaInsets();
    const dispatch = useDispatch();
    const categories_list = useSelector((state) => state.chart.categories_list); // The list of all categories available for creating trading ideas
    const category_disabled = useSelector((state) => state.chart.category_disabled); // The state of all category check boxes wether enabled or disabled

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    const renderItem = ({ item, index }) => {
        return (
            <ListItem.Accordion
                icon={() => <Ionicons name="caret-down" style={{ marginLeft: 8 }} size={16} color={is_darkmode === true ? '#ffffff' : '#000000'} />}
                containerStyle={{ backgroundColor: '#1e1e1e' }}
                content={
                    <>
                        <ListItem.CheckBox
                            containerStyle={{ backgroundColor: '#1e1e1e' }}
                            // Use ThemeProvider to change the defaults of the checkbox
                            iconType="material-community"
                            checkedIcon="checkbox-marked"
                            uncheckedIcon="checkbox-blank-outline"
                            checked={item.checked}
                            onPress={() => dispatch(update_main_category_list_chkbox({ index: index, checked_value: !item.checked }))}
                        />
                        <ListItem.Content style={{ marginLeft: 15 }}>
                            <ListItem.Title style={{ color: '#ffffff' }}>{item.title}</ListItem.Title>
                        </ListItem.Content>
                    </>
                }
                isExpanded={item.expanded}
                onPress={() => dispatch(update_category_expansion({ index: index, exp_value: !item.expanded }))}
            >
                {item.sub_list.map((sublist_item, i) => (
                    <ListItem style={{ marginLeft: 25 }} key={i} containerStyle={{ backgroundColor: '#1e1e1e' }}>
                        <ListItem.CheckBox
                            // Use ThemeProvider to change the defaults of the checkbox
                            iconType="material-community"
                            checkedIcon="checkbox-marked"
                            uncheckedIcon="checkbox-blank-outline"
                            containerStyle={{ backgroundColor: '#1e1e1e' }}
                            checked={sublist_item.checked}
                            onPress={() => dispatch(update_sub_category_list_chkbox({ main_index: index, sub_index: i, checked_value: !sublist_item.checked }))}
                        />
                        <ListItem.Content>
                            <ListItem.Title style={{ color: '#ffffff' }}>{sublist_item.title}</ListItem.Title>
                        </ListItem.Content>
                    </ListItem>
                ))}
            </ListItem.Accordion>
        );
    };

    return (
        <FlatList
            style={[all_watchlists_styles.native_header, { flex: 1, backgroundColor: '#1e1e1e' }]}
            data={categories_list}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
        />
    );
};