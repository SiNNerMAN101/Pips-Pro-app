import { FlatList, Text, TouchableOpacity } from 'react-native';;
import { useDispatch, useSelector } from 'react-redux';
import BottomSheet, { BottomSheetBackdrop, BottomSheetView } from "@gorhom/bottom-sheet";
import { useCallback, useMemo, useState } from 'react';
import { Easing } from 'react-native-reanimated'; // Use Easing from Reanimated
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { Divider, ListItem } from '@rneui/themed';
import { Icon } from 'react-native-paper';
import { allWatchlists } from '../../styles/all_watchlists';
import { set_user_selected_market_type, update_category_expansion, update_main_category_list_chkbox, update_sub_category_list_chkbox } from '../../state/chart';

export function MarketTypeModal({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // State of the app if user is logged in or not
    const insets = useSafeAreaInsets();
    const dispatch = useDispatch();
    const market_types_list = useSelector((state) => state.chart.market_types_list); // The list of all market types available on pipspro
    const user_selected_market_type = useSelector((state) => state.chart.user_selected_market_type); // The market type that the user selected

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    const renderItem = ({ item, index }) => {
        return (
            <ListItem.Accordion
                containerStyle={{ backgroundColor: '#1e1e1e' }}
                content={
                    <>
                        <ListItem.CheckBox
                            containerStyle={{ backgroundColor: '#1e1e1e' }}
                            // Use ThemeProvider to change the defaults of the checkbox
                            checkedIcon="dot-circle-o"
                            uncheckedIcon="circle-o"
                            checked={user_selected_market_type === item.id}
                            onPress={() => dispatch(set_user_selected_market_type({ value: item.id }))}
                        />
                        <ListItem.Content style={{ marginLeft: 15 }}>
                            <ListItem.Title style={{ color: '#ffffff' }}>{item.title}</ListItem.Title>
                        </ListItem.Content>
                    </>
                }
                isExpanded={false}
            >
                <></>
            </ListItem.Accordion>
        );
    };

    return (
        <FlatList
            style={[all_watchlists_styles.native_header, { flex: 1, backgroundColor: '#1e1e1e' }]}
            data={market_types_list}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
        />
    );
};