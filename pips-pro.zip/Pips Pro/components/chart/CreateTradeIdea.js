import { useSelector } from 'react-redux';
import { useMemo, useRef, useState } from "react";
import { Text, View, Platform, ScrollView, TouchableOpacity } from 'react-native';
import { allWatchlists } from '../../styles/all_watchlists';
import { authScreens } from '../../styles/auth_screens';
import { TextInput } from 'react-native';
import { Button } from '@rneui/themed';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { TextEditorToolbar } from '../../components/create_trade_idea/TextEditorToolbar';
import { handle_toolbar_interaction } from '../../reusable_methods/trade_ideas/handle_toolbar_interaction';
import { Formik } from 'formik';
import { object, string } from 'yup';
import { AntDesign } from '@expo/vector-icons';
import { createIdeaStyles } from '../../styles/create_idea';

const CreateIdeaSchema = object({
    title: string().required('This field is required'),
    body: string().required('This field is required')
})

export default function CreateTradeIdea({ set_current_view, title, body, set_title, set_body }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const [is_loading, set_is_loading] = useState(false); // State of the continue/login button
    const [editable, set_editable] = useState(true); 
    const insets = useSafeAreaInsets();
    const formikRef = useRef();

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);
    const create_idea_styles = useMemo(() => createIdeaStyles(is_darkmode, insets), [is_darkmode, insets]);

    const [selection, setSelection] = useState({ start: 0, end: 0 });

    // Capture the selected text range
    const handleSelectionChange = ({ nativeEvent: { selection } }) => {
        setSelection(selection);
    };

    const run = (textdata) => {
        const convertedText = textdata
        .replace(/\[link url="(.*?)"\]/g, '<a href="$1">$1</a>') // Replaces the [link] tags
        .replace(/\[b\]/g, '<strong>') // Replace the open [b] tags
        .replace(/\[\/b\]/g, '</strong>') // Replace the close [b] tags
        .replace(/\[i\]/g, '<i>') // Replace the open [i] tags
        .replace(/\[\/i\]/g, '</i>') // Replace the close [i] tags
        .replace(/\[s\]/g, '<s>') // Replace the open [s] tags
        .replace(/\[\/s\]/g, '</s>') // Replace the close [s] tags
        .replace(/\[list-1\]/g, '<ul>') // Replace the open [list-1] tags
        .replace(/\[\/list-1\]/g, '</ul>') // Replace the close [list-1] tags
        .replace(/\[list-2\]/g, '<ol>') // Replace the open [list-2] tags
        .replace(/\[\/list-2\]/g, '</ol>') // Replace the close [list-2] tags
        .replace(/\[item\]/g, '<li>') // Replace the open [item] tags
        .replace(/\[\/item\]/g, '</li>') // Replace the close [item] tags
        .replace(/\n/g, '<br>')        // Convert newlines to <br> tags
        .replace(/ {2}/g, '&nbsp;&nbsp;');  // Preserve multiple spaces

        console.log(convertedText);
    }

    return (
        <KeyboardAwareScrollView enableOnAndroid={true} enableAutomaticScroll={(Platform.OS === 'ios')} style={[all_watchlists_styles.native_header, { padding: 10, paddingLeft: insets.left === 0 ? 10 : insets.left, paddingRight: insets.right === 0 ? 10 : insets.right, backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }]}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', height: 43, marginTop: 13, paddingHorizontal: 16 }}>
                <View style={{ width: 31.0, height: 31.0 }}></View>
                <Text style={{ color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontWeight: 'bold', fontSize: 20 }}>Create idea</Text>
                <TouchableOpacity onPress={() => set_current_view(1)}><AntDesign name="closecircleo" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity>
            </View>
            
            <Formik
                innerRef={formikRef}
                initialValues={{ title: title, body: body }}
                validationSchema={CreateIdeaSchema}
                onSubmit={(values) => set_current_view(3)}
            >
                {({ handleChange, handleSubmit, values, errors, touched, handleBlur, setFieldValue }) => (
                    <View style={create_idea_styles.mb36}>
                        <View style={{ marginVertical: 15, marginBottom: 25 }}>
                            <View style={[authScreens.email_or_username_inp_container, { borderColor: (errors.title && touched.title) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                                <TextInput
                                    style={[authScreens.email_or_username_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                                    placeholder="A clear title that describes your idea"
                                    placeholderTextColor={'#999696'}
                                    value={values.title}
                                    keyboardType="default"
                                    onChange={(e) => set_title(e.nativeEvent.text)}
                                    keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                                    textContentType='none'
                                    onBlur={handleBlur('title')} 
                                    onChangeText={handleChange('title')}
                                />
                            </View>
                            { (touched.title && errors.title) ? (<Text style={authScreens.errorText}>{errors.title}</Text>) : null }
                        </View>

                        <TextEditorToolbar handle_toolbar_interaction={handle_toolbar_interaction} selection={selection} setSelection={setSelection} values={values} setFieldValue={setFieldValue} />

                        <TextInput
                            style={[authScreens.channel_desc_inp, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', borderColor: (errors.body && touched.body) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), color: is_darkmode === true ? '#ffffff' : '#000000', marginTop: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0, height: 300 }]}
                            placeholder="Please provide a clear, meaningful and detailed description of your analysis and prediction"
                            multiline={true}
                            editable={editable}
                            placeholderTextColor={'#999696'}
                            keyboardType="default"
                            onChange={(e) => set_body(e.nativeEvent.text)}
                            value={values.body}
                            textContentType='none'
                            onBlur={handleBlur('body')} 
                            onChangeText={handleChange('body')}
                            onSelectionChange={handleSelectionChange}
                        />
                        { (touched.body && errors.body) ? (<Text style={authScreens.errorText}>{errors.body}</Text>) : null }

                        <View style={authScreens.btn_container}>
                            <Button title="Continue" loading={is_loading === true ? true : false} titleStyle={authScreens.btn_font} containerStyle={authScreens.btn_width} buttonStyle={authScreens.btn} onPress={handleSubmit} />
                        </View>
                    </View>
                )}
            </Formik>
        </KeyboardAwareScrollView>
    );
}