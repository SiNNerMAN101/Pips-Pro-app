import { Text, TouchableOpacity } from 'react-native';;
import { useDispatch, useSelector } from 'react-redux';
import BottomSheet, { BottomSheetBackdrop, BottomSheetView } from "@gorhom/bottom-sheet";
import { useCallback } from 'react';
import { Easing } from 'react-native-reanimated'; // Use Easing from Reanimated
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { set_btm_sheet_index, set_btm_sheet_option, set_enable_btm_sheet } from '../../state/chart';

export function MenuBottomSheet({ bottomSheetRef, handleSheetChanges }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // State of the app if user is logged in or not
    const btm_sheet_index = useSelector((state) => state.chart.btm_sheet_index); // The index of the snap points for the bottom sheet
    const enable_btm_sheet = useSelector((state) => state.chart.enable_btm_sheet); // The state of the bottom sheet either enabled or disabled
    const insets = useSafeAreaInsets();
    const dispatch = useDispatch();

    // Custom animation configuration to increase the speed
    const animationConfigs = {
        duration: 300,  // Increase or decrease this value to control speed (in milliseconds)
        easing: Easing.out(Easing.exp), // Easing function from Reanimated
    };

    // Render backdrop (overlay)
    const renderBackdrop = useCallback((props) => (
        <BottomSheetBackdrop
            {...props}
            disappearsOnIndex={-1} // Automatically hide backdrop when Bottom Sheet is closed
            appearsOnIndex={0} // Show backdrop when Bottom Sheet opens
        />
    ), []);

    // Detect when the user clicks on any options in the menu bottom sheet
    const option_toggle = (value) => {
        dispatch(set_btm_sheet_option({ value: value }));
        dispatch(set_btm_sheet_index({ value: -1 }));
        bottomSheetRef.current?.close(); // Close the BottomSheet
    }

    return (
        <>
            {
                enable_btm_sheet === true ?
                    <BottomSheet
                        ref={bottomSheetRef}
                        index={btm_sheet_index}
                        snapPoints={['30%']}
                        onChange={handleSheetChanges}
                        enablePanDownToClose={true}
                        animationConfigs={animationConfigs} // Customize animation speed here
                        backdropComponent={renderBackdrop}
                        handleIndicatorStyle={{ backgroundColor: is_darkmode === true ? '#ffffff' : '#000000' }}
                        backgroundStyle={{ backgroundColor: is_darkmode === true ? '#1d1d1d' : '#ffffff', shadowOffset: { width: 0, height: -2 }, shadowOpacity: 0.25, shadowRadius: 3.84, elevation: 5, }}
                    >
                        <BottomSheetView style={{ flex: 1, paddingBottom: insets.bottom, paddingLeft: insets.left, paddingRight: insets.right }}>
                            <Text style={{ color: '#ffffff', marginHorizontal: 20, fontFamily: 'RobotoBold', fontSize: 21.5 }}>Menu</Text>
                            <BottomSheetView style={{ marginHorizontal: 20, marginTop: 15 }}>
                                <TouchableOpacity onPress={() => option_toggle(1)} style={{ flexDirection: 'row', padding: 10, borderRadius: 10, alignItems: 'center', backgroundColor: '#323335' }}>
                                    <MaterialIcons name="save-alt" size={25} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                                    <Text style={{ color: '#ffffff', marginLeft: 7, fontFamily: 'RobotoRegular', fontSize: 18 }}>Save chart picture</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => option_toggle(2)} style={{ flexDirection: 'row', padding: 10, marginTop: 15, borderRadius: 10, alignItems: 'center', backgroundColor: '#323335' }}>
                                    <MaterialIcons name="lightbulb-outline" size={25} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                                    <Text style={{ color: '#ffffff', marginLeft: 7, fontFamily: 'RobotoRegular', fontSize: 18 }}>Create idea</Text>
                                </TouchableOpacity>
                            </BottomSheetView>
                        </BottomSheetView>
                    </BottomSheet>
                : null
            }
        </>
    );
};