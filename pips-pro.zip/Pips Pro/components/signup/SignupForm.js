import { TextInput, View, Text, TouchableOpacity, Platform } from 'react-native';
import { authScreens } from "../../styles/auth_screens";
import { useCallback, useRef, useState } from "react";
import { Button } from '@rneui/themed';
import { Formik } from "formik";
import { object, string } from 'yup';
import { useFocusEffect } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { signup_user } from '../../reusable_methods/signup/signup_user';
import { Ionicons } from '@expo/vector-icons';

const SignupSchema = object({
    email: string().required('This field is required').test('is-valid-email', 'Email must be valid', (val) => {
        var validRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return val.match(validRegex);
    }),
    user_name: string().required('This field is required').test('there-must-be-no-empty-or-white-space', 'This field is required', (val) => {
        var validRegex = /^\s*$/;
        return !val.match(validRegex);
    }).test('first-character-must-be-a-letter', 'Username has to start with a letter', (val) => {
        var validRegex = /^[a-zA-Z]/;
        return val.match(validRegex);
    }),
    password: string().required('This field is required').min(7, 'Password must be at least 7 characters').max(7, 'Password must be at least 7 characters').test('password-must-be-a-mix-of-numbers-and-letters', 'Password must have both letters and numbers', (val) => {
        var validRegex = /^(?=.*[a-zA-Z])(?=.*[0-9]).{6,}$/;
        return val.match(validRegex);
    })
})

export function SignupForm({ navigation, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [is_loading, set_is_loading] = useState(false); // State of the continue/login button
    const [secure_password, set_secure_password] = useState(true);
    const [controller, set_controller] = useState(new AbortController()); // Abort controller for canceling pending requests

    const formikRef = useRef();

    // This hook will be called when the screen is focused
    useFocusEffect(
        useCallback(() => {
            // This hook will be called when the screen is focused
            return () => {
                controller.abort();
                set_snackbar_msg('');
                set_snackbar_err(false);
                set_snackbar_toggle(false);
                // This function will be called when the screen loses focus
                setTimeout(() => {
                    set_controller(new AbortController()); // Reset the abort controller to generate a new signal
                    set_snackbar_toggle(false); set_is_loading(false);
                    formikRef.current?.resetForm(); // Reset signup form
                }, 500);
            };
        }, [])
    );

    return (
        <Formik
            innerRef={formikRef}
            initialValues={{ email: '', user_name: '', password: '' }}
            validationSchema={SignupSchema}
            onSubmit={(values) => signup_user(values.email, values.user_name, values.password, navigation, snackbar_toggle, snackbar_err, snackbar_msg, is_loading, set_is_loading, controller, set_controller, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err)}
        >
            {({ handleChange, handleSubmit, values, errors, touched, handleBlur }) => (
                <View style={authScreens.formBody}>
                    <View style={[authScreens.email_or_username_inp_container, { borderColor: (errors.email && touched.email) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                        <TextInput
                            style={[authScreens.email_or_username_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                            placeholder="Email"
                            editable={is_loading === true ? false : true}
                            placeholderTextColor={'#999696'}
                            value={values.email}
                            keyboardType="default"
                            keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                            onBlur={handleBlur('email')} 
                            onChangeText={handleChange('email')}
                        />
                    </View>
                    { (touched.email && errors.email) ? (<Text style={authScreens.errorText}>{errors.email}</Text>) : '' }

                    <View style={authScreens.mt_23}>
                        <View style={[authScreens.email_or_username_inp_container, { borderColor: (errors.user_name && touched.user_name) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                            <TextInput
                                style={[authScreens.email_or_username_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                                placeholder="Username"
                                editable={is_loading === true ? false : true}
                                placeholderTextColor={'#999696'}
                                value={values.user_name}
                                keyboardType="default"
                                keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                                onBlur={handleBlur('user_name')} 
                                onChangeText={handleChange('user_name')}
                            />
                        </View>
                    </View>
                    { (touched.user_name && errors.user_name) ? (<Text style={authScreens.errorText}>{errors.user_name}</Text>) : '' }

                    <View style={authScreens.mt_23}>
                        <View style={[authScreens.password_inp_container, { borderColor: (errors.password && touched.password) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                            <TextInput
                                style={[authScreens.password_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                                placeholder="Password"
                                editable={is_loading === true ? false : true}
                                placeholderTextColor={'#999696'}
                                secureTextEntry={secure_password}
                                value={values.password}
                                keyboardType="default"
                                keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                                onBlur={handleBlur('password')} 
                                onChangeText={handleChange('password')}
                            />
                            <TouchableOpacity onPress={() => set_secure_password(!secure_password)}>
                                <Ionicons name={secure_password === true ? "eye-off" : "eye"} size={25} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                            </TouchableOpacity>
                        </View>
                    </View>
                    { (touched.password && errors.password) ? (<Text style={authScreens.errorText}>{errors.password}</Text>) : '' }

                    <View style={authScreens.btn_container}>
                        <Button title="Continue" loading={is_loading === true ? true : false} titleStyle={authScreens.btn_font} containerStyle={{ width: '100%' }} buttonStyle={authScreens.btn} onPress={handleSubmit} />
                    </View>
                </View>
            )}
        </Formik>
    );
}