import { View, Text, ScrollView, TouchableOpacity, Platform } from "react-native";
import { authScreens } from "../../styles/auth_screens";
import { useSelector } from 'react-redux';
import { Image } from "expo-image";
import { SignupForm } from "./SignupForm";

export default function SignupContainer({ route, navigation, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <ScrollView showsVerticalScrollIndicator={false} style={authScreens.form_container}>
            <View style={authScreens.logo_view}>
                <Image
                    style={authScreens.logo}
                    allowDownscaling={false}
                    source={require('../../assets/logo-black.png')}
                    contentFit="cover"
                />
                <Text style={authScreens.logo_text}>
                    <Text style={authScreens.left_logo_text}>Pips</Text><Text style={authScreens.right_logo_text}>Pro</Text>
                </Text>
            </View>
            
            <Text style={[authScreens.head_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Create a new account</Text>

            <View style={authScreens.bottom_view}>
                <Text style={[authScreens.bottom_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Already have an account?</Text>
                <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                    <Text style={authScreens.ll_txt}> Sign in</Text>
                </TouchableOpacity>
            </View>

            <SignupForm navigation={navigation} snackbar_toggle={snackbar_toggle} snackbar_msg={snackbar_msg} snackbar_err={snackbar_err} set_snackbar_toggle={set_snackbar_toggle} set_snackbar_msg={set_snackbar_msg} set_snackbar_err={set_snackbar_err} />
        </ScrollView>
    );
}