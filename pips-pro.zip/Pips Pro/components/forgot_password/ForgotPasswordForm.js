import { TextInput, View, Text } from 'react-native';
import { authScreens } from "../../styles/auth_screens";
import { useCallback, useRef, useState } from "react";
import { Button } from '@rneui/themed';
import { Formik } from "formik";
import { object, string } from 'yup';
import { useSelector } from 'react-redux';
import { useFocusEffect } from '@react-navigation/native';
import { send_confirmation_code } from '../../reusable_methods/forgot_password/send_confirmation_code';

const ForgotPasswordSchema = object({
    email: string().required('This field is required').test('there-must-be-no-empty-or-white-space', 'This field is required', (val) => {
        var validRegex = /^\s*$/;
        return !val.match(validRegex);
    })
})

export function ForgotPasswordForm({ navigation, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [is_loading, set_is_loading] = useState(false); // State of the continue/login button
    const [controller, set_controller] = useState(new AbortController()); // Abort controller for canceling pending requests

    const formikRef = useRef();

    // This hook will be called when the screen is focused
    useFocusEffect(
        useCallback(() => {
            // This hook will be called when the screen is focused
            return () => {
                controller.abort();
                // This function will be called when the screen loses focus
                setTimeout(() => {
                    set_controller(new AbortController()); // Reset the abort controller to generate a new signal
                    set_snackbar_toggle(false); set_is_loading(false);
                    formikRef.current?.resetForm(); // Reset forgot password form
                }, 500);
            };
        }, [])
    );

    return (
        <Formik
            innerRef={formikRef}
            initialValues={{ email: '' }}
            validationSchema={ForgotPasswordSchema}
            onSubmit={(values) => send_confirmation_code(values.email, navigation, snackbar_toggle, snackbar_err, snackbar_msg, is_loading, set_is_loading, controller, set_controller, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err)}
        >
            {({ handleChange, handleSubmit, values, errors, touched, handleBlur }) => (
                <View style={authScreens.formBody}>
                    <View style={[authScreens.email_or_username_inp_container, { borderColor: (errors.email && touched.email) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                        <TextInput
                            style={[authScreens.email_or_username_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                            placeholder="Email"
                            editable={is_loading === true ? false : true}
                            placeholderTextColor={'#999696'}
                            value={values.email}
                            keyboardType="default"
                            keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                            onBlur={handleBlur('email')} 
                            onChangeText={handleChange('email')}
                        />
                    </View>
                    { (touched.email && errors.email) ? (<Text style={authScreens.errorText}>{errors.email}</Text>) : '' }

                    <View style={authScreens.btn_container}>
                        <Button title="Continue" loading={is_loading === true ? true : false} titleStyle={authScreens.btn_font} containerStyle={{ width: '100%' }} buttonStyle={authScreens.btn} onPress={handleSubmit} />
                    </View>
                </View>
            )}
        </Formik>
    );
}