import { View, Text, TouchableOpacity, Platform } from 'react-native';
import { authScreens } from "../../styles/auth_screens";
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { useSelector } from 'react-redux';

export function Header({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <View style={authScreens.go_back_btn_view}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={[authScreens.go_back_btn, { marginLeft: Platform.OS === 'ios' ? -9.5 : 0 }]}>
                {
                    Platform.OS === 'ios' ?
                        <>
                            <Ionicons name="chevron-back-outline" size={31} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                            <Text style={[authScreens.go_back_btn_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Back</Text>
                        </>
                    : <MaterialIcons name="arrow-back" size={31} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                }
            </TouchableOpacity>
        </View>
    );
}