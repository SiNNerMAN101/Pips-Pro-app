import { useSelector } from 'react-redux';
import { useMemo } from 'react';
import { Dialog } from 'react-native-paper';
import { loadingDialogStyles } from '../../styles/loading_dialog';
import { ActivityIndicator } from 'react-native';

export function LoadingDialog({ loading_modal, type }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    
    // Memoize the styles to avoid recalculating them on each render
    const loading_dialog_styles = useMemo(() => loadingDialogStyles(is_darkmode), [is_darkmode]);

    return (
        <Dialog
            visible={loading_modal}
            style={loading_dialog_styles.overlay}
            dismissableBackButton={false}
        >
            <Dialog.Title style={loading_dialog_styles.dialog_title}>{ type === 1 ? 'Verifying code...' : 'Sending new code...' }</Dialog.Title>
            <Dialog.Content>
                <ActivityIndicator size="large" color={is_darkmode === true ? '#ffffff' : '#000000'} />
            </Dialog.Content>
        </Dialog>
    );
}