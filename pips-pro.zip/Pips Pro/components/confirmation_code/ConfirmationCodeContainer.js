import { View, Text, ScrollView } from "react-native";
import { authScreens } from "../../styles/auth_screens";
import { useSelector } from 'react-redux';
import { Image } from "expo-image";
import { VerifyConfirmationCodeForm } from "./VerifyConfirmationCodeForm";

export default function ConfirmationCodeContainer({ route, navigation, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_loading_modal, set_type }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <ScrollView showsVerticalScrollIndicator={false} style={authScreens.form_container}>
            <View style={authScreens.logo_view}>
                <Image
                    style={authScreens.logo}
                    allowDownscaling={false}
                    source={require('../../assets/logo-black.png')}
                    contentFit="cover"
                />
                <Text style={authScreens.logo_text}>
                    <Text style={authScreens.left_logo_text}>Pips</Text><Text style={authScreens.right_logo_text}>Pro</Text>
                </Text>
            </View>
            
            <Text style={[authScreens.head_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Verify confirmation code</Text>

            <VerifyConfirmationCodeForm route={route} navigation={navigation} snackbar_toggle={snackbar_toggle} snackbar_msg={snackbar_msg} snackbar_err={snackbar_err} set_snackbar_toggle={set_snackbar_toggle} set_snackbar_msg={set_snackbar_msg} set_snackbar_err={set_snackbar_err} set_loading_modal={set_loading_modal} set_type={set_type} />
        </ScrollView>
    );
}