import { View } from "react-native";
import { useState, useRef, useMemo, useCallback } from "react";
import { SymbolsFlatlist } from "./add_symbol_modal/SymbolsFlatlist";
import { useSelector } from 'react-redux';
import { SymbolsFlatlistLoading } from "./add_symbol_modal/SymbolsFlatlistLoading";
import { SearchBarForAddSymbolModal } from "./add_symbol_modal/SearchBarForAddSymbolModal";
import { useFocusEffect } from "@react-navigation/native";
import { addSymbolModalStyles } from "../../styles/watchlist/add_symbol_modal";

// Display a modal where the user can search and select a symbol of their choice to add to their watchlists
export function AddSymbolModal({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [loading, setLoading] = useState(true);
    const controller = useRef(new AbortController());

    // Memoize the styles to avoid recalculating them on each render
    const add_symbol_modal_styles = useMemo(() => addSymbolModalStyles(is_darkmode), [is_darkmode]);

    // Create a ref for the TextInput component
    const textInputRef = useRef();

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            textInputRef.current.focus();
            
            // Return a cleanup function to run when the screen loses focus
            return () => {
                setSearchQuery(""); // Make the search bar empty
                controller.current.abort(); // Abort any pending requests
                controller.current = new AbortController(); // Reset the controller state
            };
        }, [])
    );

    return (
        <>
            <View style={add_symbol_modal_styles.container}>
                <View style={add_symbol_modal_styles.searchbar_view}>
                    <SearchBarForAddSymbolModal textInputRef={textInputRef} controller={controller} navigation={navigation} setSearchQuery={setSearchQuery} searchQuery={searchQuery} setLoading={setLoading} setSearchResults={setSearchResults} />
                </View>

                {
                    loading === true ?
                        <SymbolsFlatlistLoading />
                    : <SymbolsFlatlist searchResults={searchResults} />
                }
            </View>
        </>
    );
}