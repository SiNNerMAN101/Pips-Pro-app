import { View } from 'react-native';
import { Image } from 'expo-image';
import { useState } from "react";
import { Avatar } from '@rneui/themed';

// Loading placeholder for symbol images
export function LoadSymbolImage({ img_url, symbol_name }) {
    const [loading, setLoading] = useState(true);

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => (
        <Avatar
            size={37}
            rounded
            titleStyle={{ color: '#ffffff' }}
            title={symbol_name.charAt(0)}
            containerStyle={{ backgroundColor: "#cecece" }}
        />
    );

    return (
        <View style={{ width: 37, height: 37 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: 37, height: 37, borderRadius: 50 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={img_url}
                contentFit="cover"
            />
        </View>
    );
}