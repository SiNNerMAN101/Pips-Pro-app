import { View } from 'react-native';
import { Image } from 'expo-image';
import { useState } from "react";
import { Avatar } from '@rneui/themed';

// Loading placeholder for symbol exchange image
export function LoadSymbolExchangeImage({ img_url, exchange_name }) {
    const [loading, setLoading] = useState(true);

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => (
        <Avatar
            size={18}
            rounded
            titleStyle={{ color: '#ffffff' }}
            title={exchange_name.charAt(0)}
            containerStyle={{ backgroundColor: "#cecece" }}
        /> 
    );

    return (
        <View style={{ width: 18, height: 18 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: 18, height: 18, borderRadius: 50 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={img_url}
                contentFit="cover"
            />
        </View>
    );
}