import { View, TouchableOpacity, Text } from 'react-native';
import { SymbolForNews } from "../SymbolForNews";
import { Avatar } from '@rneui/themed';
import { useSelector } from 'react-redux';
import * as WebBrowser from 'expo-web-browser';
import { useState } from 'react';

// Display the news list for the current viewed symbol
export function NewsView({  }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const [result, setResult] = useState(null);

    const _handlePressButtonAsync = async (url) => {
        let result = await WebBrowser.openBrowserAsync(url);
        setResult(result);
    };

    let news = [
        { 
            id: 1, 
            title: "iPhone 16 Rumors Roundup: Everything We Know About Apple's Next Flagship - Apple  ( NASDAQ:AAPL )",
            summary: "Apple Inc.'s AAPL upcoming flagship series, the iPhone 16, is generating a lot of buzz. Here's a roundup of all the rumors and leaks about the highly anticipated device. What Happened: The tech giant is expected to release its iPhone 16 series in September, continuing its tradition of annual ...",
            url: "https://markets.businessinsider.com/news/stocks/apple-s-next-big-leap-how-ai-software-and-wwdc-announcements-could-fuel-growth-1033272311",
            banner_image: 'https://cdn.benzinga.com/files/imagecache/1024x768xUP/images/story/2024/04/22/Apple-Store-Fifth-Avenue.jpeg',
            time_published: '20240404T104526',
            source: 'Benzinga',
            ticker_sentiment: [
                {
                    ticker: "NVDA",
                    logo: null
                },
                {
                    ticker: "AAPL",
                    logo: 'https://substackcdn.com/image/fetch/w_848,c_limit,f_webp,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8ed3d547-94ff-48e1-9f20-8c14a7030a02_2000x2000.jpeg'
                },
                {
                    ticker: "TSM",
                    logo: null
                }
            ]
        },

        { 
            id: 2,
            title: "Not UK Or Japan: India To Emerge As Apple's Third-Largest iPhone Market In Just 2 Years - Apple  ( NASDAQ:AAPL )",
            summary: "This story was first published on the Benzinga India portal. By 2026, India is set to surpass both Japan and the UK to become the third-largest iPhone market for Apple Inc. AAPL, according to a report by Counterpoint Research.",
            url: "https://decrypt.co/227296/what-happens-when-last-bitcoin-mined",
            banner_image: null,
            time_published: '20240404T094453',
            source: 'Benzinga',
            ticker_sentiment: [
                {
                    ticker: "NVDA",
                    logo: null
                }
            ]
        }
    ]

    let format_date = (timestamp, source) => {
        // Extract month, day, hour, and minute from the timestamp
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        const month = parseInt(timestamp.slice(4, 6)) - 1;
        const day = parseInt(timestamp.slice(6, 8));
        const hour = parseInt(timestamp.slice(9, 11));
        const minute = parseInt(timestamp.slice(11, 13));

        // Format the date
        const formattedDate = `${hour}:${minute < 10 ? '0' + minute : minute} · ${monthNames[month]} ${day} · ${source}`;

        return formattedDate;
    }


    return (
        <View style={{ paddingHorizontal: 16, marginTop: 43 }}>
            {/* Render news list */}
            {news.map((item, index) => (
                <TouchableOpacity onPress={() => _handlePressButtonAsync(item.url)} style={{ marginBottom: 50 }} key={index}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <View style={{ flexDirection: 'row' }}>
                            {item.ticker_sentiment.map((ticker, index) => (
                                <View key={index}>
                                    { 
                                        ticker.logo === null ?  
                                            <Avatar
                                                size={19}
                                                rounded
                                                titleStyle={{ color: '#ffffff' }}
                                                title={ticker.ticker.charAt(0)}
                                                containerStyle={{ backgroundColor: "#cecece" }}
                                            />
                                        : <SymbolForNews img_url={ticker.logo} symbol_name={ticker.ticker} /> 
                                    }
                                </View>
                            ))}
                        </View>
                        <Text style={{ alignItems: 'center', fontFamily: 'RobotoRegular', marginLeft: 10, color: is_darkmode === true ? '#7f7f7f' : '#727272' }}>{format_date(item.time_published, item.source)}</Text>
                    </View>
                    <Text style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', marginTop: 10, fontSize: 20, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.title}</Text>
                </TouchableOpacity>
            ))}
        </View>
    );
}