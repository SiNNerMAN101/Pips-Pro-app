import { View } from 'react-native';
import { Image } from 'expo-image';
import { useState } from "react";
import { Avatar } from '@rneui/themed';
import { useSelector } from 'react-redux';

// Loading placeholder for symbol double images
export function LoadSymbolDoubleImageSecond({ item, color }) {
    const [loading, setLoading] = useState(true);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => ( 
        <Avatar
            size={27}
            rounded
            titleStyle={{ position: 'relative', top: -2, color: '#ffffff' }}
            title={item.to.charAt(0)}
            containerStyle={{ borderWidth: 2, borderColor: is_darkmode === true ? color : '#ffffff', borderStyle: 'solid', backgroundColor: '#cecece' }}
        /> 
    );

    return (
        <View style={{ width: 27, height: 27, position: 'relative', top: -10, right: 16.5 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: 27, height: 27, borderRadius: 50, borderColor: is_darkmode === true ? color : '#ffffff', borderWidth: 2 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={item.img_url2}
                contentFit="cover"
            />
        </View>
    );
}