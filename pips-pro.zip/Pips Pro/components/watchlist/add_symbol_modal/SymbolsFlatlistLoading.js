import { symbolsFlatlistLoadingStyles } from "../../../styles/watchlist/symbol_flatlist_loading";
import { useSelector } from 'react-redux';
import { View, FlatList } from "react-native";
import { Skeleton } from "@rneui/themed";
import { useMemo } from "react";

// A skeleton loader for the add symbol modal
export function SymbolsFlatlistLoading({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    // Memoize the styles to avoid recalculating them on each render
    const flatlist_styles = useMemo(() => symbolsFlatlistLoadingStyles(is_darkmode), [is_darkmode]);

    const renderItem = ({ item }) => {
        return (
            <View style={flatlist_styles.item}>
                <View style={flatlist_styles.first_section}>
                    <Skeleton circle animation='wave' width={37} style={flatlist_styles.profile} skeletonStyle={flatlist_styles.skeleton_style} height={37} />   

                    <View style={{ marginLeft: 13 }}>
                        <Skeleton animation='wave' width={120} style={flatlist_styles.symbol_name} skeletonStyle={flatlist_styles.skeleton_style} height={13} />
                        <Skeleton animation='wave' width={120} style={flatlist_styles.symbol_desc} skeletonStyle={flatlist_styles.skeleton_style} height={13} />
                    </View>
                </View>

                <View style={flatlist_styles.second_section}>
                    <View style={flatlist_styles.mr8}>
                        <View style={flatlist_styles.dfsc}>
                            <Skeleton animation='wave' width={25} style={flatlist_styles.ert} skeletonStyle={flatlist_styles.skeleton_style} height={13} />
                        </View>
                        <Skeleton animation='wave' width={60} style={flatlist_styles.symbol_name} skeletonStyle={flatlist_styles.skeleton_style} height={13} />
                    </View>

                    <View style={{ padding: 8 }}>
                        <Skeleton animation='wave' width={23} style={flatlist_styles.profile} skeletonStyle={flatlist_styles.skeleton_style} height={23} />
                    </View>
                </View>
            </View>
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [flatlist_styles]);

    return (
        <FlatList
            style={[flatlist_styles.modal_flatlist, { marginTop: 20 }]}
            data={Array.from({length: 6}, (_, i) => i + 1)}
            showsVerticalScrollIndicator={false}
            scrollEnabled={false}
            renderItem={memoizedRenderItem}
        />
    );
}