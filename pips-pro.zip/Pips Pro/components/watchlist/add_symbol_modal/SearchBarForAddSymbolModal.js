import { useEffect, useMemo } from "react";
import { useSelector } from 'react-redux';
import { SearchBar } from '@rneui/themed';
import { Platform } from "react-native";
import { handle_search } from "../../../reusable_methods/add_symbol_modal/handle_search";
import { addSymbolModalSearchBarStyles } from "../../../styles/watchlist/add_symbol_modal_search_bar";

// Search bar for the add symbol modal
export function SearchBarForAddSymbolModal({ textInputRef, controller, navigation, setSearchQuery, searchQuery, setLoading, setSearchResults }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const accessToken = useSelector((state) => state.login_state.accessToken); // Current state of darkmode

    // Memoize the styles to avoid recalculating them on each render
    const add_symbol_modal_searchbar_styles = useMemo(() => addSymbolModalSearchBarStyles(is_darkmode), [is_darkmode]);
    
    // Handle search bar text change
    const handleChangeText = (text) => {
        controller.current.abort(); // Abort any pending requests
        controller.current = new AbortController(); // Reset the controller state
        setSearchQuery(text);
    };

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {

            if (/^\s*$/.test(searchQuery) === false) {
                handle_search(setLoading, setSearchResults, searchQuery, accessToken, controller);
            }
        }, 500); // Adjust the delay as needed (e.g., 500 milliseconds)

        return () => clearTimeout(delayDebounceFn);
    }, [searchQuery]); // Re-run the effect whenever searchQuery changes

    return (
        <SearchBar
            ref={textInputRef}
            inputStyle={add_symbol_modal_searchbar_styles.input_style}
            inputContainerStyle={add_symbol_modal_searchbar_styles.input_container_style}
            onCancel={() => {
                navigation.goBack();
            }}
            platform="ios"
            showCancel={true}
            cancelButtonTitle="Close"
            cancelButtonProps={{ buttonTextStyle: add_symbol_modal_searchbar_styles.cancel_btn }}
            searchIcon={Platform.OS === 'ios' ? {name: 'search'} : null} clearIcon={Platform.OS === 'ios' ? {name: 'close-circle'} : null}
            containerStyle={add_symbol_modal_searchbar_styles.container_style}
            lightTheme={true}
            keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
            placeholder="Search"
            onChangeText={handleChangeText}
            value={searchQuery}
            autoCapitalize={"characters"}
        />
    );
}