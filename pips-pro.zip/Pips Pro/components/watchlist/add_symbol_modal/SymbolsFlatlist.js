import { FlatList } from "react-native";
import { StockSymbol } from "./symbol_component/StockSymbol";
import { ForexSymbol } from "./symbol_component/ForexSymbol";
import { CryptoSymbol } from "./symbol_component/CryptoSymbol";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useSelector } from "react-redux";
import { useMemo } from "react";
import { symbolsFlatlistStyles } from "../../../styles/watchlist/symbol_flatlist";

// List containing searched symbols
export function SymbolsFlatlist({ searchResults }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    let insets = useSafeAreaInsets()

    // Memoize the styles to avoid recalculating them on each render
    const flatlist_styles = useMemo(() => symbolsFlatlistStyles(is_darkmode, insets), [is_darkmode, insets]);

    const renderItem = ({ item }) => {
        return (
            <>
                {   
                    item.type === 'stock' ?
                        <StockSymbol item={item} />
                    : item.type === 'forex' ?
                        <ForexSymbol item={item} />
                    : item.type === 'crypto' ?
                        <CryptoSymbol item={item} />
                    : <></>
                }
            </>
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [flatlist_styles]);

    return (
        <FlatList
            style={flatlist_styles.modal_flatlist}
            data={searchResults}
            showsVerticalScrollIndicator={false}
            scrollEnabled={false}
            renderItem={memoizedRenderItem}
            keyExtractor={(item) => item.index}
        />
    );
}