import { View } from 'react-native';
import { Image } from 'expo-image';
import { useState } from "react";
import { Avatar } from '@rneui/themed';
import { useSelector } from 'react-redux';

// Loading placeholder for symbol double images
export function LoadSymbolDoubleImageSecond({ item, color }) {
    const [loading, setLoading] = useState(true);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => ( 
        <Avatar
            size={23}
            rounded
            titleStyle={{ position: 'relative', top: 0.2, color: '#ffffff' }}
            title={item.short_name.split('/')[1].charAt(0)}
            containerStyle={{ backgroundColor: "#cecece" }}
        />
    );

    return (
        <View style={{ width: 27, height: 27, right: 16.5, justifyContent: 'center', alignItems: 'center', backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderRadius: 50, borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 0.6, position: 'relative', top: -10 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: 23, height: 23, borderRadius: 50 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={item.image2}
                contentFit="cover"
            />
        </View>
    );
}