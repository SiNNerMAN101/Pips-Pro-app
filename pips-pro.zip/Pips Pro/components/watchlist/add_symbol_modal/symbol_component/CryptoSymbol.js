import { View, Text, TouchableOpacity } from "react-native";
import { Avatar } from "@rneui/themed";
import { AntDesign } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import { LoadSymbolImage } from "../../LoadSymbolImage";
import { useMemo } from "react";
import { symbolComponentsStyles } from "../../../../styles/watchlist/symbol_components";

// Crypto symbol render
export function CryptoSymbol({ item }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const logged_in = useSelector((state) => state.login_state.logged_in); // Users current logged in state

    // Memoize the styles to avoid recalculating them on each render
    const symbol_comp_styles = useMemo(() => symbolComponentsStyles(is_darkmode), [is_darkmode]);

    return (
        <TouchableOpacity style={symbol_comp_styles.item}>
            <View style={symbol_comp_styles.symbol_details}>
                { 
                    item.image === null ? 
                        <Avatar
                            size={37}
                            rounded
                            titleStyle={symbol_comp_styles.avatar_title}
                            title={item.short_name.charAt(0)}
                            containerStyle={symbol_comp_styles.avatar_bg}
                        />
                    : <LoadSymbolImage img_url={item.image} symbol_name={item.short_name} /> 
                }

                <View style={symbol_comp_styles.ml13}>
                    <Text style={symbol_comp_styles.symbol_short_name}>{item.short_name.split('/').join('')}</Text>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={symbol_comp_styles.symbol_name}>{item.name}</Text>
                </View>
            </View>

            <View style={symbol_comp_styles.symbol_values}>
                <View style={symbol_comp_styles.mr8}>
                    <Text style={symbol_comp_styles.symbol_changes}>-- : --</Text>
                    <Text style={symbol_comp_styles.symbol_type}>{item.type}</Text>
                </View>

                {
                    logged_in === true ?
                        <TouchableOpacity style={{ padding: 8 }}>
                            <AntDesign name="plus" size={23} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                        </TouchableOpacity>
                    : <></>
                }
            </View>
        </TouchableOpacity>
    );
}