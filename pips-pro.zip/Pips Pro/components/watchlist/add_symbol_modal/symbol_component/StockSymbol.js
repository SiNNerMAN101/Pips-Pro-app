import { View, Text, TouchableOpacity } from "react-native";
import { Avatar } from "@rneui/themed";
import { LoadSymbolImage } from "../../LoadSymbolImage";
import { LoadSymbolExchangeImage } from "../../LoadSymbolExchangeImage";
import { AntDesign } from '@expo/vector-icons';
import { useSelector } from 'react-redux';

// Stock symbol render
export function StockSymbol({ item }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const logged_in = useSelector((state) => state.login_state.logged_in); // Users current logged in state

    return (
        <TouchableOpacity style={{ flexDirection: 'row', marginHorizontal: 15,  marginRight: 0, justifyContent: 'space-between', marginBottom: 10, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
            <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                { 
                    item.image === null ? 
                        <Avatar
                            size={37}
                            rounded
                            titleStyle={{ color: '#ffffff' }}
                            title={item.short_name.charAt(0)}
                            containerStyle={{ backgroundColor: "#cecece" }}
                        />
                    : <LoadSymbolImage img_url={item.image} symbol_name={item.short_name} /> 
                }

                <View style={{ marginLeft: 13 }}>
                    <Text style={{ fontSize: 17, fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.short_name}</Text>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ maxWidth: 153, fontFamily: 'RobotoRegular', fontSize: 15, color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b', marginTop: 4 }}>{item.name}</Text>
                </View>
            </View>

            <View style={{ flexDirection: 'row', alignSelf: 'center', alignItems: 'center', justifyContent: 'flex-end', flex: 1, marginRight: 8 }}>
                <View style={{ marginRight: 8 }}>
                    {
                        item.exch !== undefined && item.exch !== '' ? 
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                { 
                                    item.exchange_img === null ? 
                                        <Avatar
                                            size={18}
                                            rounded
                                            titleStyle={{ color: '#ffffff' }}
                                            title={item.exch.charAt(0)}
                                            containerStyle={{ backgroundColor: "#cecece" }}
                                        />
                                    : <LoadSymbolExchangeImage img_url={item.exchange_img} exchange_name={item.exch} /> 
                                }
                                <Text style={{ fontFamily: 'RobotoRegular', marginLeft: 4, color: is_darkmode === true ? '#ffffff' : '#000000', fontSize: 17 }}>{item.exch}</Text>
                            </View> 
                        : <Text style={{ fontSize: 15, color: is_darkmode === true ? '#ffffff' : '#000000', textAlign: 'right' }}>-- : --</Text>
                    }
                    <Text style={{ textAlign: 'right', fontFamily: 'RobotoRegular', marginTop: 4, fontSize: 15, color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b' }}>{item.type}</Text>
                </View>

                {
                    logged_in === true ?
                        <TouchableOpacity style={{ padding: 8 }}>
                            <AntDesign name="plus" size={23} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                        </TouchableOpacity>
                    : <></>
                }
            </View>
        </TouchableOpacity>
    );
}