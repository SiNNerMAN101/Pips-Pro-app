import { View, Text, TouchableOpacity } from "react-native";
import { Avatar } from "@rneui/themed";
import { AntDesign } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import { LoadSymbolDoubleImageFirst } from "../LoadSymbolDoubleImageFirst";
import { LoadSymbolDoubleImageSecond } from "../LoadSymbolDoubleImageSecond";

// Forex symbol render
export function ForexSymbol({ item }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const logged_in = useSelector((state) => state.login_state.logged_in); // Users current logged in state

    return (
        <TouchableOpacity style={{ flexDirection: 'row', marginHorizontal: 15,  marginRight: 0, justifyContent: 'space-between', marginBottom: 10, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
            <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                <View style={{ height: 37, width: 37, flexDirection: 'row', alignItems: 'flex-end' }}>
                    { 
                        item.image1 === null ? 
                            <View style={{ width: 27, height: 27, zIndex: 3, justifyContent: 'center', alignItems: 'center', backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderRadius: 50, borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 0.6, position: 'relative', top: 0.5 }}>
                                <Avatar
                                    size={23}
                                    rounded
                                    titleStyle={{ position: 'relative', top: 0.2, color: '#ffffff' }}
                                    title={item.short_name.split('/')[0].charAt(0)}
                                    containerStyle={{ backgroundColor: "#cecece" }}
                                />
                            </View>
                        : <LoadSymbolDoubleImageFirst item={item} color={'#131722'} /> 
                    }

                    { 
                        item.image2 === null ? 
                            <View style={{ width: 27, height: 27, right: 16.5, justifyContent: 'center', alignItems: 'center', backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderRadius: 50, borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 0.6, position: 'relative', top: -10 }}>
                                <Avatar
                                    size={23}
                                    rounded
                                    titleStyle={{ position: 'relative', top: 0.2, color: '#ffffff' }}
                                    title={item.short_name.split('/')[1].charAt(0)}
                                    containerStyle={{ backgroundColor: "#cecece" }}
                                />
                            </View>
                        : <LoadSymbolDoubleImageSecond item={item} color={'#131722'} /> 
                    }
                </View>

                <View style={{ marginLeft: 13 }}>
                    <Text style={{ fontSize: 17, fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.short_name.split('/').join('')}</Text>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ maxWidth: 153, fontFamily: 'RobotoRegular', fontSize: 15, color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b', marginTop: 4 }}>{item.name}</Text>
                </View>
            </View>

            <View style={{ flexDirection: 'row', alignSelf: 'center', alignItems: 'center', justifyContent: 'flex-end', flex: 1, marginRight: 8 }}>
                <View style={{ marginRight: 8 }}>
                    <Text style={{ fontSize: 15, color: is_darkmode === true ? '#ffffff' : '#000000', textAlign: 'right' }}>-- : --</Text>
                    <Text style={{ marginTop: 4, fontFamily: 'RobotoRegular', fontSize: 15, color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b', textAlign: 'right' }}>{item.type}</Text>
                </View>

                {
                    logged_in === true ?
                        <TouchableOpacity style={{ padding: 8 }}>
                            <AntDesign name="plus" size={23} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                        </TouchableOpacity>
                    : <></>
                }
            </View>
        </TouchableOpacity>
    );
}