import BottomSheet from "@gorhom/bottom-sheet";
import { useState, useEffect, useRef } from "react";
import { refreshWidget } from "../../../reusable_methods/watchlist/refreshWidget";
import { useSelector } from 'react-redux';
import { InnerContent } from "./overview_bttmsheet_components/InnerContent";

// The bottom sheet to display a symbol overview widget
export function SymbolOverviewBottomSheet({ navigation, handleClosePress, raw_symbol, btm_changes, sheetRef, snapPoints, handleSheetChange, renderBackdrop, overview_widget, onRefreshWidget, symbol, onSymbolChange, symbol_data, onChangeSymbolData, symbol_type, onChangeSymbolType, setModalVisible }) {
    const scrollViewRef = useRef();
    let [ refresh_webview, onRefreshWebView ] = useState(false);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    
    // Function to scroll to the top
    const scrollToTop = () => {
        scrollViewRef.current.scrollTo({ y: 0, animated: false });
    };

    // Effect hook to watch for changes in the bottom sheets display
    useEffect(() => {
        scrollToTop();
    }, [btm_changes]); // Dependency array

    // Refresh the symbol overview widget
    let refresh_symbol_overview_widget = () => {
        onRefreshWebView(true);

        setTimeout(() => {
            onRefreshWebView(false);
            refreshWidget(overview_widget, onRefreshWidget, is_darkmode);
        }, 120);
    }

    // Add the symbol selected by the user to the current active watchlist
    let add_symbol_to_watchlist = () => {
        
    }

    return (
        <BottomSheet
            ref={sheetRef}
            index={-1}
            snapPoints={snapPoints}
            onChange={handleSheetChange}
            backdropComponent={renderBackdrop}
            enablePanDownToClose={true}
            handleIndicatorStyle={{
                backgroundColor: is_darkmode === true ? '#E4E7EC' : '#a7abb1',
                width: 50,
            }}
            handleStyle={{ backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 1, borderStyle: 'solid', borderTopLeftRadius: 10, borderTopRightRadius: 10 }}
        >
            <InnerContent add_symbol_to_watchlist={add_symbol_to_watchlist} handleClosePress={handleClosePress} scrollViewRef={scrollViewRef} refresh_webview={refresh_webview} overview_widget={overview_widget} symbol_data={symbol_data} />
        </BottomSheet>
    );
}