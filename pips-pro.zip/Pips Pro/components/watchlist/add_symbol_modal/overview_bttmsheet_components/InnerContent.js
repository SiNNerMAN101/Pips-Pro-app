import { View, Text, TouchableOpacity, Platform } from "react-native";
import { AntDesign } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import { BottomSheetView, BottomSheetScrollView } from "@gorhom/bottom-sheet";
import { watchList } from "../../../../styles/watchlist";
import WebView from "react-native-webview";
import { FlatList } from "react-native-gesture-handler";
import { NewsView } from "../../overview_bottom_sheet/NewsView";

// The contents contained within the symbol overview widget in the add symbol modal
export function InnerContent({ add_symbol_to_watchlist, handleClosePress, scrollViewRef, refresh_webview, overview_widget, symbol_data }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <View style={{ flex: 1 }}>
            <View style={[watchList.bottomsheet_header, { backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderTopColor: is_darkmode === true ? '#131722' : '#ffffff', borderBottomColor: is_darkmode === true ? '#434651' : '#e0e3eb' }]}>
                <TouchableOpacity onPress={add_symbol_to_watchlist}><AntDesign name="plus" color={is_darkmode === true ? '#ffffff' : '#000000'} size={26} /></TouchableOpacity>
                <TouchableOpacity onPress={() => handleClosePress()}><AntDesign name="closecircleo" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity>
            </View>
            
            <BottomSheetScrollView ref={scrollViewRef} style={[ watchList.bottomsheet_scrollview, { backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' }]} showsVerticalScrollIndicator={false}>
                <BottomSheetView pointerEvents={Platform.OS === 'ios' ? 'auto' : 'none'} style={[ watchList.bottomsheet_view, { borderTopColor: is_darkmode === true ? '#434651' : '#e0e3eb' }]}>
                    {
                        refresh_webview === false ?
                            <WebView 
                                style={{ backgroundColor: 'transparent' }}
                                originWhitelist={['*']}
                                source={{ html: overview_widget }} 
                                scrollEnabled={false}
                            />
                        : refresh_webview === true ?
                            <></>
                        : <></>
                    }
                </BottomSheetView>

                <FlatList 
                    contentContainerStyle={watchList.flatlist_in_bottomsheet_container}
                    showsHorizontalScrollIndicator={false}
                    style={[watchList.flatlist_in_bottomsheet_styles, { borderColor: is_darkmode === true ? '#434651' : '#e0e3eb' }]}
                    horizontal 
                    data={symbol_data}
                    renderItem={({ item }) => (
                        <View style={{ paddingHorizontal: 16 }}>
                            <Text style={{ fontSize: 15, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.title}</Text>
                            <Text style={{ fontWeight: 'bold', fontSize: 15, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.value}</Text>
                        </View>
                    )}
                />

                <NewsView />
            </BottomSheetScrollView>
        </View>
    );
}