import { View, Text, RefreshControl } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSelector } from 'react-redux';
import { AntDesign, Ionicons } from '@expo/vector-icons';
import { refresh_active_watchlist } from '../../reusable_methods/watchlist/refresh_active_watchlist';
import { useCallback, useMemo } from 'react';
import { Button } from '@rneui/themed';
import { authScreens } from '../../styles/auth_screens';
import { channels } from '../../styles/channels';

export function WatchlistData({ watchlist_state, refreshing, setRefreshing, refresh_controller, navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    // Memoize the styles to avoid recalculating them on each render
    const channels_styles = useMemo(() => channels(is_darkmode), [is_darkmode]);

    // Listen to pull to refresh event
    const onRefresh = useCallback(async () => {
        await refresh_active_watchlist(refresh_controller, setRefreshing);
    }, []);

    return (
        <ScrollView
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30 }}
            refreshControl={
                watchlist_state !== 'deleted' && watchlist_state !== false ?
                    <RefreshControl
                        tintColor={is_darkmode ? '#ffffff' : '#000000'} // color of the spinner
                        colors={['#000000']} // Android-specific spinner color
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                    />
                : <></>
            }
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                {
                    watchlist_state === 'deleted' ?
                        <Ionicons name="trash-bin-outline" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    : <AntDesign name="inbox" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                }   

                {
                    watchlist_state === false ?
                        <View style={{ alignItems: 'center' }}>
                            <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>There are no symbols in this watchlist</Text>
                            <Button title="Add symbol" onPress={() => navigation.navigate('AddSymbolModal')} titleStyle={authScreens.btn_font} containerStyle={{ width: 125 }} buttonStyle={channels_styles.btn} />
                        </View>
                    : watchlist_state === 'non_active' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>View your watchlists below</Text>
                    : watchlist_state === 'no_watchlist' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>You have no watchlists available. Create a new watchlist below</Text>
                    : watchlist_state === 'deleted' ? 
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>This watchlist has been deleted</Text>
                    : <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>This watchlist is empty</Text>
                }
            </View>
        </ScrollView>
    );
}