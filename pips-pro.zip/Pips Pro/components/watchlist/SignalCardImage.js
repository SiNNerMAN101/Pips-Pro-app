import { View } from 'react-native';
import { Image } from 'expo-image';
import { useState } from "react";
import { Skeleton } from '@rneui/themed';

// Loading placeholder for signal card images in the overview widget bottomsheet
export function SignalCardImage({ img_url }) {
    const [loading, setLoading] = useState(true);

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => (
        <Skeleton animation='wave' width='100%' style={{ backgroundColor: '#dedede', borderRadius: 8 }} skeletonStyle={{ backgroundColor: '#d1d1d1' }} height={200} />
    );

    return (
        <View style={{ width: '100%', height: 200, borderRadius: 8 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: '100%', height: 200, borderRadius: 8 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={img_url}
                contentFit="cover"
            />
        </View>
    );
}