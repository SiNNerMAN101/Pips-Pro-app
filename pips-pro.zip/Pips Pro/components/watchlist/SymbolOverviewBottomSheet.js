import BottomSheet, { BottomSheetView, BottomSheetScrollView, BottomSheetBackdrop } from "@gorhom/bottom-sheet";
import { useState, useEffect, useRef, useCallback } from "react";
import { Text, View, TouchableOpacity, Platform } from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { WebView } from 'react-native-webview';
import { MaterialIcons } from '@expo/vector-icons';
import { refreshWidget } from "../../reusable_methods/watchlist/refreshWidget";
import { NewsView } from "./overview_bottom_sheet/NewsView";
import { useSelector } from 'react-redux';
import { watchList } from "../../styles/watchlist";

// The bottom sheet to display a symbol overview widget
export function SymbolOverviewBottomSheet({ navigation, handleClosePress, raw_symbol, btm_changes, sheetRef, snapPoints, handleSheetChange, overview_widget, onRefreshWidget, symbol, onSymbolChange, symbol_data, onChangeSymbolData, symbol_type, onChangeSymbolType }) {
    const scrollViewRef = useRef();
    let [ refresh_webview, onRefreshWebView ] = useState(false);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    
    // Function to scroll to the top
    const scrollToTop = () => {
        scrollViewRef.current.scrollTo({ y: 0, animated: false });
    };

    // Effect hook to watch for changes in the bottom sheets display and scroll the bottomsheet to the top
    useEffect(() => {
        scrollToTop();
    }, [btm_changes]); // Dependency array

    // Refresh the symbol overview widget
    let refresh_symbol_overview_widget = () => {
        onRefreshWebView(true);

        setTimeout(() => {
            onRefreshWebView(false);
            refreshWidget(overview_widget, onRefreshWidget, is_darkmode);
        }, 120);
    }

    // Navigate to the chart screen and display a chart for the selected symbol
    let open_chart = () => {
        handleClosePress();
        setTimeout(() => {
            navigation.navigate('Tabs', {
                screen: 'Chart',
                params: { symbol: raw_symbol },
            });
        }, 230);
    }

    // Backdrop of the bottomsheet
    const renderBackdrop = useCallback(
		(props) => (
			<BottomSheetBackdrop
				{...props}
				disappearsOnIndex={-1}
				appearsOnIndex={0}
			/>
		),
		[]
	);

    return (
        <BottomSheet
            ref={sheetRef}
            index={-1}
            snapPoints={snapPoints}
            onChange={handleSheetChange}
            backdropComponent={renderBackdrop}
            enablePanDownToClose={true}
            handleIndicatorStyle={{
                backgroundColor: is_darkmode === true ? '#E4E7EC' : '#a7abb1',
                width: 50,
            }}
            handleStyle={{ backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 1, borderStyle: 'solid', borderTopLeftRadius: 10, borderTopRightRadius: 10 }}
        >
            <View style={[watchList.bottomsheet_header, { backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderTopColor: is_darkmode === true ? '#131722' : '#ffffff', borderBottomColor: is_darkmode === true ? '#434651' : '#e0e3eb' }]}>
                <TouchableOpacity onPress={open_chart}><MaterialIcons name="insert-chart-outlined" color={is_darkmode === true ? '#ffffff' : '#000000'} size={26} /></TouchableOpacity>
                <TouchableOpacity onPress={refresh_symbol_overview_widget}><MaterialIcons name="refresh" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity>
            </View>
            
            <BottomSheetScrollView ref={scrollViewRef} style={[ watchList.bottomsheet_scrollview, { backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' }]} showsVerticalScrollIndicator={false}>
                <BottomSheetView pointerEvents={Platform.OS === 'ios' ? 'auto' : 'none'} style={[ watchList.bottomsheet_view, { borderTopColor: is_darkmode === true ? '#434651' : '#e0e3eb' }]}>
                    {
                        refresh_webview === false ?
                            <WebView 
                                style={{ backgroundColor: 'transparent' }}
                                originWhitelist={['*']}
                                source={{ html: overview_widget }} 
                                scrollEnabled={false}
                            />
                        : refresh_webview === true ?
                            <></>
                        : <></>
                    }
                </BottomSheetView>

                <FlatList 
                    contentContainerStyle={watchList.flatlist_in_bottomsheet_container}
                    showsHorizontalScrollIndicator={false}
                    style={[watchList.flatlist_in_bottomsheet_styles, { borderColor: is_darkmode === true ? '#434651' : '#e0e3eb' }]}
                    horizontal 
                    data={symbol_data}
                    renderItem={({ item }) => (
                        <View style={{ paddingHorizontal: 16 }}>
                            <Text style={{ fontSize: 16, fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.title}</Text>
                            <Text style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', fontSize: 16, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.value}</Text>
                        </View>
                    )}
                />

                <NewsView />
            </BottomSheetScrollView>
        </BottomSheet>
    );
}