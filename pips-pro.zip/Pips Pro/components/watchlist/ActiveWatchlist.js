import { RefreshControl, Text, View } from "react-native";
import { watchList } from "../../styles/watchlist";
import { useSelector } from 'react-redux';
import { FlatList } from "react-native-gesture-handler";
import { StockSymbol } from "./active_watchlist_comp/StockSymbol";
import { ForexSymbol } from "./active_watchlist_comp/ForexSymbol";
import { CryptoSymbol } from "./active_watchlist_comp/CryptoSymbol";
import { useCallback } from "react";
import { refresh_active_watchlist } from "../../reusable_methods/watchlist/refresh_active_watchlist";

// A render of the current active watchlist
export function ActiveWatchlist({ refreshing, setRefreshing, refresh_controller }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const active_watchlist = useSelector((state) => state.watch_list_state.active_watchlist); // The users active watchlist state
    const active_watchlist_name = useSelector((state) => state.watch_list_state.active_watchlist_name); // The users active watchlist name

    // Listen to pull to refresh event
    const onRefresh = useCallback(async () => {
        await refresh_active_watchlist(refresh_controller, setRefreshing);
    }, []);

    const renderItem = ({ item }) => {
        return (
            <>
                {   
                    item.type === 'stock' ?
                        <StockSymbol enableSymbolMenuBottomSheet={enableSymbolMenuBottomSheet} item={item} handleSnapPress={handleSnapPress} />
                    : item.type === 'forex' ?
                        <ForexSymbol enableSymbolMenuBottomSheet={enableSymbolMenuBottomSheet} item={item} handleSnapPress={handleSnapPress} />
                    : item.type === 'crypto' ?
                        <CryptoSymbol enableSymbolMenuBottomSheet={enableSymbolMenuBottomSheet} item={item} handleSnapPress={handleSnapPress} />
                    : <></>
                }
            </>
        );
    };

    return (
        <View style={{ flex: 1 }}>
            <Text style={[watchList.active_watchlist_name, { color: is_darkmode === true ? '#ffffff' : '#000000' } ]}>{active_watchlist_name}</Text>

            <FlatList
                style={{ marginRight: 0, marginLeft: 20, flex: 1, backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }}
                data={active_watchlist}
                refreshControl={
                    <RefreshControl
                      refreshing={refreshing}
                      onRefresh={onRefresh}
                    />
                }
                showsVerticalScrollIndicator={true}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
            />
        </View>
    );
}