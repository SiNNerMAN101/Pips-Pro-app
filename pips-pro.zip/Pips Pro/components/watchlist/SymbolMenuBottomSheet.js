import { View } from "react-native";
import { BottomSheet, ListItem } from '@rneui/themed';
import { Ionicons, AntDesign } from '@expo/vector-icons';
import { useSelector } from 'react-redux';

// A menu looking bottom sheet to be displayed when the user clicks on a symbol in the current active watchlist
export function SymbolMenuBottomSheet({ handleSnapPress, symbol_menu_bottom_sheet, setSymbolMenuBottomSheet }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const v_list = [
        { title: 'Open chart', icon: 'bar-chart-outline', type: 'ionicons' },
        { title: 'Open symbol overview', icon: 'layout', type: 'antdesign' },
        {
          title: 'Remove',
          containerStyle: { backgroundColor: 'red' },
          titleStyle: { color: 'red' },
          icon: 'trash-outline',
          type: 'ionicons'
        },
    ];

    // Handle click events on any of the list items in the bottomsheet
    const handle_item_click = (index) => {
        if (index === 1){
            setSymbolMenuBottomSheet(0, symbol_menu_bottom_sheet.symbol, symbol_menu_bottom_sheet.market_data, symbol_menu_bottom_sheet.symbol_type, false);
            
            handleSnapPress(0, symbol_menu_bottom_sheet.symbol, symbol_menu_bottom_sheet.market_data, symbol_menu_bottom_sheet.symbol_type);
        } else if (index === 2){
            setSymbolMenuBottomSheet({ index: 0, symbol: '', market_data: [], symbol_type: '', state: false });
        }
    }

    return (
        <BottomSheet onBackdropPress={() => setSymbolMenuBottomSheet({ index: 0, symbol: '', market_data: [], symbol_type: '', state: false })} modalProps={{}} isVisible={symbol_menu_bottom_sheet.state}>
            <View>
                {v_list.map((l, i) => (
                    <ListItem
                    key={i}
                    onPress={() => handle_item_click(i)}
                    containerStyle={{ paddingBottom: (i === 2) ? 50 : 8, backgroundColor: (is_darkmode === true) ? '#131722' : '#ffffff' }}
                    >
                        { l.type === 'ionicons' ? <Ionicons name={l.icon} color={(i === 2) ? 'red' : (is_darkmode === true ? '#ffffff' : '#000000')} size={23} /> : <AntDesign name={l.icon} size={23} color={is_darkmode === true ? '#ffffff' : '#000000'} /> }
                        <ListItem.Content>
                            <ListItem.Title style={[l.titleStyle, { color: (i === 2) ? 'red' : (is_darkmode === true ? '#ffffff' : '#000000'), fontFamily: 'RobotoRegular' }]}>{l.title}</ListItem.Title>
                        </ListItem.Content>
                    </ListItem>
                ))}
            </View>
        </BottomSheet>
    );
}