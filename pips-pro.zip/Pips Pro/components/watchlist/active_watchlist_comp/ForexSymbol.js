import { View, Text, TouchableOpacity } from "react-native";
import { Avatar } from "@rneui/themed";
import { useSelector } from 'react-redux';
import { LoadSymbolDoubleImageFirst } from "../LoadSymbolDoubleImageFirst";
import { LoadSymbolDoubleImageSecond } from "../LoadSymbolDoubleImageSecond";

// Forex symbol render
export function ForexSymbol({ item }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <TouchableOpacity style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
            <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                <View style={{ height: 37, width: 37, flexDirection: 'row', alignItems: 'flex-end' }}>
                    { 
                        item.image1 === null ? 
                            <View style={{ width: 27, height: 27, zIndex: 3, justifyContent: 'center', alignItems: 'center', backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderRadius: 50, borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 0.6, position: 'relative', top: 0.5 }}>
                                <Avatar
                                    size={23}
                                    rounded
                                    titleStyle={{ position: 'relative', top: 0.2, color: '#ffffff' }}
                                    title={item.symbol.split('/')[0].charAt(0)}
                                    containerStyle={{ backgroundColor: "#cecece" }}
                                />
                            </View>
                        : <LoadSymbolDoubleImageFirst item={item} color={'#131722'} /> 
                    }

                    { 
                        item.image2 === null ? 
                            <View style={{ width: 27, height: 27, right: 16.5, justifyContent: 'center', alignItems: 'center', backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', borderRadius: 50, borderColor: is_darkmode === true ? '#131722' : '#ffffff', borderWidth: 0.6, position: 'relative', top: -10 }}>
                                <Avatar
                                    size={23}
                                    rounded
                                    titleStyle={{ position: 'relative', top: 0.2, color: '#ffffff' }}
                                    title={item.symbol.split('/')[1].charAt(0)}
                                    containerStyle={{ backgroundColor: "#cecece" }}
                                />
                            </View>
                        : <LoadSymbolDoubleImageSecond item={item} color={'#131722'} /> 
                    }
                </View>

                <View style={{ marginLeft: 13 }}>
                    <Text style={{ fontSize: 17, fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.symbol}</Text>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ maxWidth: 153, fontFamily: 'RobotoRegular', fontSize: 15, color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b', marginTop: 4 }}>{item.full_name}</Text>
                </View>
            </View>

            <View style={{ flexDirection: 'column', flex: 1, alignSelf: 'center'}}>
                <Text style={{ textAlign: 'right', fontFamily: 'RobotoRegular', marginRight: 20, fontSize: 17, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.latest_price.c}</Text>
                <Text style={{ textAlign: 'right', fontFamily: 'RobotoRegular', marginTop: 4, marginRight: 20, fontSize: 15, color: conv_changes(item.latest_price.ch, item.latest_price.cp).type === 'positive' ? 'green' : conv_changes(item.latest_price.ch, item.latest_price.cp).type === 'negative' ? 'red' : (is_darkmode === true) ? '#ffffff' : '#000000' }}>{conv_changes(item.latest_price.ch, item.latest_price.cp).data}</Text>
            </View>
        </TouchableOpacity>
    );
}