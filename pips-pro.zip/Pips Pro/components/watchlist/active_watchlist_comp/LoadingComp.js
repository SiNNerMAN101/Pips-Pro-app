import { watchList } from "../../../styles/watchlist";
import { useSelector } from 'react-redux';
import { View, FlatList } from "react-native";
import { Skeleton } from "@rneui/themed";
import { useMemo } from "react";

// A skeleton loader for the active watchlist
export function LoadingComp({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    const renderItem = ({ item }) => {
        return (
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 17, marginBottom: 10, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
                <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                    <Skeleton circle animation='wave' width={37} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede' }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={37} />   

                    <View style={{ marginLeft: 13 }}>
                        <Skeleton animation='wave' width={120} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginBottom: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                        <Skeleton animation='wave' width={120} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                    </View>
                </View>

                <View style={{ flexDirection: 'row', alignSelf: 'center', alignItems: 'center', justifyContent: 'flex-end', flex: 1, marginRight: 20 }}>
                    <View>
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 3 }}>
                            <Skeleton animation='wave' width={25} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', flex: 1 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                        </View>
                        <Skeleton animation='wave' width={60} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                    </View>
                </View>
            </View>
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [watchList, is_darkmode]);

    return (
        <FlatList
            style={[watchList.modal_flatlist, { paddingTop: 20 }]}
            scrollEnabled={false}
            data={Array.from({length: 10}, (_, i) => i + 1)}
            renderItem={memoizedRenderItem}
            keyExtractor={(item) => item}
        />
    );
}