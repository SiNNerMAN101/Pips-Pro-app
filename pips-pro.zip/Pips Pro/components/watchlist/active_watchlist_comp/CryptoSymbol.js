import { View, Text, TouchableOpacity } from "react-native";
import { Avatar } from "@rneui/themed";
import { useSelector } from 'react-redux';
import { LoadSymbolImage } from "../LoadSymbolImage";

// Crypto symbol render
export function CryptoSymbol({ item }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <TouchableOpacity style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
            <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                { 
                    item.image === null ? 
                        <Avatar
                            size={37}
                            rounded
                            titleStyle={{ color: '#ffffff' }}
                            title={item.symbol.charAt(0)}
                            containerStyle={{ backgroundColor: "#cecece" }}
                        />
                    : <LoadSymbolImage img_url={item.image} symbol_name={item.symbol} /> 
                }

                <View style={{ marginLeft: 13 }}>
                    <Text style={{ fontSize: 17, fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.symbol}</Text>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ maxWidth: 153, fontFamily: 'RobotoRegular', fontSize: 15, color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b', marginTop: 4 }}>{item.full_name}</Text>
                </View>
            </View>

            <View style={{ flexDirection: 'column', flex: 1, alignSelf: 'center'}}>
                <Text style={{ textAlign: 'right', fontFamily: 'RobotoRegular', marginRight: 20, fontSize: 17, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.latest_price.c}</Text>
                <Text style={{ textAlign: 'right', fontFamily: 'RobotoRegular', marginTop: 4, marginRight: 20, fontSize: 15, color: conv_changes(item.latest_price.ch, item.latest_price.cp).type === 'positive' ? 'green' : conv_changes(item.latest_price.ch, item.latest_price.cp).type === 'negative' ? 'red' : (is_darkmode === true) ? '#ffffff' : '#000000' }}>{conv_changes(item.latest_price.ch, item.latest_price.cp).data}</Text>
            </View>
        </TouchableOpacity>
    );
}