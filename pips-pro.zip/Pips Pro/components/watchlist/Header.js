import { View, TouchableOpacity, Text } from 'react-native';
import { Image } from 'expo-image';
import { watchList } from '../../styles/watchlist';
import { useSelector } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';

// The header for the watchlist screen
export function Header({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const watchlist_state = useSelector((state) => state.watch_list_state.watchlist_state); // Current watchlist state

    return (
        <View style={[watchList.header_bar, { borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd', backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }]}>
            <TouchableOpacity onPress={() => navigation.navigate('AllWatchLists')} style={watchList.left_btn}>
                <Ionicons name="list-outline" size={31} color={is_darkmode === true ? '#ffffff' : '#000000'} />
            </TouchableOpacity>

            <TouchableOpacity> 
                {/* <Text style={[watchList.header_title, { color: is_darkmode === true ? '#ffffff' : '#000000' }]}>{active_watchlist_name}</Text> */}
                <Image
                    style={watchList.logo}
                    source={require('../../assets/logo-black.png')}
                    contentFit="cover"
                />
            </TouchableOpacity>

            <TouchableOpacity disabled={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? true : false} onPress={() => navigation.navigate('AddSymbolModal')} style={watchList.right_btn}>
                <Ionicons name="add-outline" size={31} color={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? '#5a5a5a' : is_darkmode === true ? '#ffffff' : '#000000'} />
            </TouchableOpacity>
        </View>
    );
}