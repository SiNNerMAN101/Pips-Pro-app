import { Image } from 'expo-image';

// Avatar image to be displayed if the user is not logged in
export function AvatarImage({ is_in_home , size }) {

    return (
        <Image
            style={{ width: size, height: size, borderRadius: 100, marginLeft: is_in_home === true ? 20 : 0 }}
            source={require('../../assets/user.png')}
            contentFit="cover"
            allowDownscaling={false}
        />
    );
}