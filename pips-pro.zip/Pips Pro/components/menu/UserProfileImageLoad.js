import { View } from 'react-native';
import { useState } from "react";
import { Avatar } from '@rneui/themed';
import { Image } from 'expo-image';

// Loading placeholder for user profile image
export function UserProfileImageLoad({ img_url, user_name, color_code, size }) {
    const [loading, setLoading] = useState(true);

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => (
        <Avatar
            size={size}
            rounded
            titleStyle={{ color: '#ffffff' }}
            title={user_name.charAt(0)}
            containerStyle={{ backgroundColor: color_code, borderRadius: 8 }}
        /> 
    );

    return (
        <View style={{ width: size, height: size }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: size, height: size, borderRadius: 8 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={img_url}
                contentFit="cover"
            />
        </View>
    );
}