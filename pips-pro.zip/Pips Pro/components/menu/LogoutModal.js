import { useSelector } from 'react-redux';
import { useCallback, useMemo } from 'react';
import { ActivityIndicator, BackHandler, Text } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { logout } from '../../reusable_methods/menu/logout';
import { StatusBar } from 'expo-status-bar';
import { loadingDialogStyles } from '../../styles/loading_dialog';

export function LogoutModal({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    // Memoize the styles to avoid recalculating them on each render
    const loading_dialog_styles = useMemo(() => loadingDialogStyles(is_darkmode), [is_darkmode]);

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        await logout(navigation);
    }, []);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            const backAction = () => {
                // Returning true prevents the default back action
                return true;
            };
        
            const backHandler = BackHandler.addEventListener(
                'hardwareBackPress',
                backAction
            );

            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                backHandler.remove();
            }
        }, [])
    )

    return (
        <SafeAreaView style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }}>
            <Text style={[loading_dialog_styles.dialog_title, { marginBottom: 15 }]}>Logging out</Text>
            <ActivityIndicator size='large' color={is_darkmode === true ? '#ffffff' : '#000000'} />

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </SafeAreaView>
    );
}