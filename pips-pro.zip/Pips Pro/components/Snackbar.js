import React, { useState, useEffect } from "react";
import { View, Text, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { snackBar } from "../styles/snackbar";
import { MaterialIcons } from '@expo/vector-icons';

export function Snackbar({ 
    message,
    visible,
    error,
    duration, // Default duration in milliseconds
    containerStyle,
    messageStyle,
    textColor }) {
        const [isVisible, setIsVisible] = useState(false);
        const insets = useSafeAreaInsets();

        useEffect(() => {
            if (visible === true) {
                setIsVisible(true);

                const timeout = setTimeout(() => {
                    setIsVisible(false);
                }, duration);

                return () => clearTimeout(timeout);
            } else {
                setIsVisible(false);
            }
        }, [visible, duration]);

        return isVisible ? (
            <View
                style={[
                    snackBar.container,
                    containerStyle,
                    { backgroundColor: error === true ? '#e91c1c' : '#2E67F8', marginBottom: 40 },
                ]}
            >
                <MaterialIcons name={error === true ? "error-outline" : "check-circle-outline"} size={24} color="#ffffff" />
                <Text style={[snackBar.messageText, messageStyle, { color: textColor }]}>
                    {message}
                </Text>
            </View>
        ) : null;
}