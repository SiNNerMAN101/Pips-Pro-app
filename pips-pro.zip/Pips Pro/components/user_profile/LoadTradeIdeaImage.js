import { View } from 'react-native';
import { useState } from "react";
import { Skeleton } from '@rneui/themed';
import { Image } from 'expo-image';
import { useSelector } from 'react-redux';

// Loading placeholder for the trade idea image
export function LoadTradeIdeaImage({ img_url }) {
    const [loading, setLoading] = useState(true);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => (
        <Skeleton animation='wave' width="100%" style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', borderRadius: 10, marginBottom: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1', borderRadius: 10 }} height={200} />
    );

    return (
        <View style={{ width: '100%', height: 200, borderRadius: 10 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: '100%', height: 200, borderRadius: 10, borderWidth: 0.8, borderStyle: 'solid', borderColor: '#cdcdcd' },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={img_url}
                contentFit="cover"
            />
        </View>
    );
}