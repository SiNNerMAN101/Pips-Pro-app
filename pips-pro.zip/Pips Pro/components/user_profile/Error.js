import { Text, View } from "react-native";
import { useSelector } from 'react-redux';
import { MaterialIcons } from '@expo/vector-icons';

export default function Error({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    return (
        <View
            style={{ flex: 1, padding: 20, paddingVertical: 30, justifyContent: 'center', alignItems: 'center' }}
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <MaterialIcons name="report-gmailerrorred" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>An error just occured</Text>
            </View>
        </View>    
    );
}