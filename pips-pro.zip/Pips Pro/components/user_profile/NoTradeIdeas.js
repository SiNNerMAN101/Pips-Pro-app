import { Text, View } from "react-native";
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';

export default function NoTradeIdeas({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    return (
        <View
            style={{ flex: 1, padding: 20, paddingVertical: 30, justifyContent: 'center', alignItems: 'center' }}
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <AntDesign name="inbox" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />   
                <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>No trade ideas here yet</Text>
            </View>
        </View>       
    );
}