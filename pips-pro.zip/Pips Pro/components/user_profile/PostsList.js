import { Text, TouchableOpacity, View } from "react-native";
import { useSelector } from 'react-redux';
import { postContentStyles } from "../../styles/community/post_content_styles";
import { useMemo } from "react";
import { LoadTradeIdeaImage } from "./LoadTradeIdeaImage";
import { AntDesign, FontAwesome } from '@expo/vector-icons';

export default function PostsList({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const trade_ideas = useSelector((state) => state.trade_ideas.trade_ideas); // The state of the trade idea list
    const user_details = useSelector((state) => state.login_state.user_details); // User current account details

    // Memoize the styles to avoid recalculating them on each render
    const post_content_styles = useMemo(() => postContentStyles(is_darkmode), [is_darkmode]);

    return (
        <>
            {trade_ideas.map((item, index) => (
                <View key={index} style={post_content_styles.post_item}>
                    <LoadTradeIdeaImage img_url={item.main_media_url} />
                    <Text style={post_content_styles.title}>{item.title}</Text>

                    <View style={post_content_styles.post_data}>
                        <View>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ backgroundColor: '#f19200', paddingVertical: 2.5, paddingHorizontal: 6, borderRadius: 20 }}>
                                    <Text style={{ fontSize: 12, fontFamily: 'RobotoRegular', color: '#ffffff' }}>public</Text>
                                </View>
                            </View>
        
                            <Text style={post_content_styles.date}>{item.date}</Text>
                        </View>

                        <View style={post_content_styles.post_data_box}>
                            <TouchableOpacity style={post_content_styles.like_btn}>
                                <AntDesign name="like2" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                                <Text style={post_content_styles.comment_like_value}>{item.likes}</Text>
                            </TouchableOpacity>

                            <TouchableOpacity style={post_content_styles.comment_btn}>
                                <FontAwesome name="commenting-o" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                                <Text style={post_content_styles.comment_like_value}>{item.comments}</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            ))}
        </>
    );
}