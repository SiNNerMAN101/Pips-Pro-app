import { View, Text } from "react-native";
import { useSelector } from 'react-redux';
import { Avatar } from "@rneui/themed";
import { UserProfileImageLoad } from '../../components/menu/UserProfileImageLoad';
import { useMemo } from "react";
import { profileContentStyles } from "../../styles/user_profile/profile_content";

export default function ProfileDetails({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const user_details = useSelector((state) => state.login_state.user_details); // User current account details

    // Memoize the styles to avoid recalculating them on each render
    const profile_content_styles = useMemo(() => profileContentStyles(is_darkmode), [is_darkmode]);

    return (
        <>
            <View style={profile_content_styles.user_profile_img_and_name}>
                { 
                    user_details.profile_image === null || user_details.profile_image === undefined ? 
                        <Avatar
                            size={63}
                            rounded
                            titleStyle={{ color: '#ffffff' }}
                            title={user_details.username.charAt(0)}
                            containerStyle={{ backgroundColor: user_details.color_code, borderRadius: 8 }}
                        />
                    : <UserProfileImageLoad img_url={user_details.profile_image} user_name={user_details.username} color_code={user_details.color_code} size={63} /> 
                }

                <View>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={profile_content_styles.username}>{ user_details.username }</Text>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={profile_content_styles.email}>{ user_details.email }</Text>
                </View>
            </View>

            <View style={profile_content_styles.user_data_box}>
                <View>
                    <Text style={profile_content_styles.user_data_value}>0</Text>
                    <Text style={profile_content_styles.user_data_label}>Reputation</Text>
                </View>

                <View>
                    <Text style={profile_content_styles.user_data_value}>0</Text>
                    <Text style={profile_content_styles.user_data_label}>Published</Text>
                </View>

                <View>
                    <Text style={profile_content_styles.user_data_value}>0</Text>
                    <Text style={profile_content_styles.user_data_label}>Followers</Text>
                </View>

                <View>
                    <Text style={profile_content_styles.user_data_value}>0</Text>
                    <Text style={profile_content_styles.user_data_label}>Following</Text>
                </View>
            </View>
        </>
    );
}