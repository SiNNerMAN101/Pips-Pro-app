import { View } from "react-native";
import { useSelector } from 'react-redux';
import { Skeleton } from "@rneui/themed";

export default function PostsLoading({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    return (
        <>
            {Array.from({length: 5}, (_, i) => i + 1).map((item, index) => (
                <View key={index} style={{ flexDirection: 'column', paddingLeft: 17, paddingRight: 17, marginBottom: 16, paddingBottom: 21 }}>
                    <Skeleton animation='wave' width="100%" style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginBottom: 3, borderRadius: 10 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1', borderRadius: 10 }} height={200} />
                    <Skeleton animation='wave' width="100%" style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 9 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={16} />
                    <Skeleton animation='wave' width="80%" style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 9 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={16} />
        
                    <View style={{ marginTop: 15, flexDirection: 'row', justifyContent: 'space-between' }}>
                        <View>
                            <Skeleton animation='wave' width={65} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={12} />
                            <Skeleton animation='wave' width={65} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 7 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={12} />
                        </View>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Skeleton animation='wave' width={45} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginRight: 14 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={30} />
                            <Skeleton animation='wave' width={45} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginLeft: 14 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={30} />
                        </View>
                    </View>
                </View>
            ))}
        </>
    );
}