import { TextInput, View, Text, TouchableOpacity } from 'react-native';
import { authScreens } from "../../styles/auth_screens";
import { useRef, useState, useCallback } from "react";
import { Formik } from "formik";
import { object, string } from 'yup';
import { useFocusEffect } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { Button } from '@rneui/themed';
import { auth_user } from '../../reusable_methods/login/auth_user';
import { set_reset_password } from '../../state/loginState';
import { store } from '../../store/store';
import { Ionicons } from '@expo/vector-icons';
import { BackHandler } from 'react-native';

const LoginSchema = object({
    email_or_username: string().required('This field is required'),
    password: string().required('This field is required')
})

export function LoginForm({ route, navigation, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const reset_password = useSelector((state) => state.login_state.reset_password); // Detect if the user recently reset their password
    const [is_loading, set_is_loading] = useState(false); // State of the continue/login button
    const [controller, set_controller] = useState(new AbortController()); // Abort controller for canceling pending requests
    const [secure_password, set_secure_password] = useState(true);

    const formikRef = useRef();

    // This hook will be called when the screen is focused
    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            const backAction = () => {
                // Navigate to the watchlist screen
                navigation.navigate('Watchlist');

                // Returning true prevents the default back action
                return true;
            };
        
            const backHandler = BackHandler.addEventListener(
                'hardwareBackPress',
                backAction
            );

            // This hook will be called when the screen is focused
            const get_route_params = () => {
                if (reset_password === true) {
                    set_snackbar_msg('Your password has been reset successfully');
                    set_snackbar_err(false);
                    set_snackbar_toggle(true);
                }
            }
    
            get_route_params();

            return () => {
                backHandler.remove();
                controller.abort();
                set_snackbar_msg('');
                set_snackbar_err(false);
                set_snackbar_toggle(false);
                // This function will be called when the screen loses focus
                setTimeout(() => {
                    set_controller(new AbortController()); // Reset the abort controller to generate a new signal
                    set_snackbar_toggle(false); set_is_loading(false);
                    store.dispatch(set_reset_password({ value: false }));
                    set_secure_password(true);
                    formikRef.current?.resetForm(); // Reset login form
                }, 500);
            };
        }, [reset_password])
    );

    return (
        <Formik
            innerRef={formikRef}
            initialValues={{ email_or_username: '', password: '' }}
            validationSchema={LoginSchema}
            onSubmit={(values) => auth_user(values.email_or_username, values.password, navigation, snackbar_toggle, snackbar_err, snackbar_msg, is_loading, set_is_loading, controller, set_controller, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err)}
        >
            {({ handleChange, handleSubmit, values, errors, touched, handleBlur }) => (
                <View style={authScreens.formBody}>
                    <View style={[authScreens.email_or_username_inp_container, { borderColor: (errors.email_or_username && touched.email_or_username) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                        <TextInput
                            style={[authScreens.email_or_username_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                            placeholder="Email or Username"
                            editable={is_loading === true ? false : true}
                            placeholderTextColor={'#999696'}
                            value={values.email_or_username}
                            keyboardType="default"
                            keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                            textContentType='none'
                            onBlur={handleBlur('email_or_username')} 
                            onChangeText={handleChange('email_or_username')}
                        />
                    </View>
                    { (touched.email_or_username && errors.email_or_username) ? (<Text style={authScreens.errorText}>{errors.email_or_username}</Text>) : '' }

                    <View style={authScreens.mt_23}>
                        <View style={[authScreens.password_inp_container, { borderColor: (errors.password && touched.password) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc'), backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}>
                            <TextInput
                                style={[authScreens.password_inp_field, { backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000' }]}
                                placeholder="Password"
                                editable={is_loading === true ? false : true}
                                placeholderTextColor={'#999696'}
                                secureTextEntry={secure_password}
                                value={values.password}
                                keyboardType="default"
                                keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                                onBlur={handleBlur('password')} 
                                onChangeText={handleChange('password')}
                            />
                            <TouchableOpacity onPress={() => set_secure_password(!secure_password)}>
                                <Ionicons name={secure_password === true ? "eye-off" : "eye"} size={25} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                            </TouchableOpacity>
                        </View>
                    </View>
                    { (touched.password && errors.password) ? (<Text style={authScreens.errorText}>{errors.password}</Text>) : '' }

                    <View style={authScreens.btn_container}>
                        <Button title="Continue" loading={is_loading === true ? true : false} titleStyle={authScreens.btn_font} containerStyle={{ width: '100%' }} buttonStyle={authScreens.btn} onPress={handleSubmit} />
                    </View>
                </View>
            )}
        </Formik>
    );
}