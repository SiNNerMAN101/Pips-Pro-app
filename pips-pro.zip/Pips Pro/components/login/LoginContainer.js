import { View, Text, ScrollView, TouchableOpacity, Platform } from "react-native";
import { authScreens } from "../../styles/auth_screens";
import { Divider } from "@rneui/themed";
import { LoginForm } from "../../components/login/LoginForm";
import { useSelector } from 'react-redux';
import { Image } from "expo-image";
import { apple_auth } from "../../reusable_methods/login/apple_auth";
import * as Google from 'expo-auth-session/providers/google'
import { useEffect } from "react";

// Google auth credentials
const GOOGLE_ANDROID_CLIENT_ID = "729377998656-d7julqq02cjqqtk1b137ehajdcm8cl2o.apps.googleusercontent.com"
const GOOGLE_iOS_CLIENT_ID = "729377998656-4b739702agq497gfp3e0m6sarpjnmcv0.apps.googleusercontent.com"

export default function LoginContainer({ route, navigation, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, loading_modal, set_loading_modal }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    /******************** Google SignIn *********************/
    const [request, response, promptAsync] = Google.useAuthRequest({
        androidClientId: GOOGLE_ANDROID_CLIENT_ID,
        iosClientId: GOOGLE_iOS_CLIENT_ID
    })

    useEffect(() => {
        handleSignInWithGoogle();
    }, [response])

    const handleSignInWithGoogle = async () => {
        if (response?.type === "success") {
            console.log(response.authentication.accessToken)
        }
    }

    return (
        <ScrollView showsVerticalScrollIndicator={false} style={authScreens.form_container}>
            <View style={authScreens.logo_view}>
                <Image
                    style={authScreens.logo}
                    source={require('../../assets/logo-black.png')}
                    contentFit="cover"
                />
                <Text style={authScreens.logo_text}>
                    <Text style={authScreens.left_logo_text}>Pips</Text><Text style={authScreens.right_logo_text}>Pro</Text>
                </Text>
            </View>
            
            <Text style={[authScreens.head_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Sign in to your account</Text>

            <View style={authScreens.bottom_view}>
                <Text style={[authScreens.bottom_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Don't have an account?</Text>
                <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
                    <Text style={authScreens.ll_txt}> Sign up</Text>
                </TouchableOpacity>
            </View>

            <LoginForm route={route} navigation={navigation} snackbar_toggle={snackbar_toggle} snackbar_msg={snackbar_msg} snackbar_err={snackbar_err} set_snackbar_toggle={set_snackbar_toggle} set_snackbar_msg={set_snackbar_msg} set_snackbar_err={set_snackbar_err} />
                
            <View style={authScreens.fgp_box}>
                <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
                    <Text style={authScreens.fgp_btn_txt}>Forgot password?</Text>
                </TouchableOpacity>
            </View>

            <View style={authScreens.or_box}>
                <Divider width={1} style={authScreens.divider_line1} color={is_darkmode === true ? '#6c6c6c' : '#bcbcbc'} />

                <Text style={[authScreens.or_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Or</Text>

                <Divider width={1} style={authScreens.divider_line2} color={is_darkmode === true ? '#6c6c6c' : '#bcbcbc'} />
            </View>
            
            <View style={{ marginBottom: 40 }}>
                <TouchableOpacity onPress={() => { promptAsync() }} style={[authScreens.auth_button, { borderColor: is_darkmode === true ? '#2a2e39' : '#bcbcbc', backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff' }]}>
                    <View>
                        <Image
                            style={authScreens.auth_icon}
                            allowDownscaling={false}
                            source={require('../../assets/google.png')}
                            contentFit="cover"
                        />
                    </View>

                    <View style={authScreens.auth_btn_txt_view}>
                        <Text style={[authScreens.auth_btn_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Sign in with Google</Text>
                    </View>
                </TouchableOpacity>

                {
                    Platform.OS === 'ios' ?
                        <TouchableOpacity onPress={() => apple_auth(loading_modal, set_loading_modal, navigation, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err)} style={[authScreens.auth_button, { borderColor: is_darkmode === true ? '#2a2e39' : '#bcbcbc', backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff' }]}>
                            <View>
                                <Image
                                    style={[authScreens.auth_icon, { borderRadius: 50 }]}
                                    allowDownscaling={false}
                                    source={require('../../assets/apple.webp')}
                                    contentFit="cover"
                                />
                            </View>

                            <View style={authScreens.auth_btn_txt_view}>
                                <Text style={[authScreens.auth_btn_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Sign in with Apple</Text>
                            </View>
                        </TouchableOpacity>
                    : <></>
                }
            </View>
        </ScrollView>
    );
}