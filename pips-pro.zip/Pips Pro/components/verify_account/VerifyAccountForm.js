import { useState, useCallback } from "react";
import { useFocusEffect } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { OtpInput } from "react-native-otp-entry";
import { View, Text, TouchableOpacity } from "react-native";
import { verify_user_account } from "../../reusable_methods/verify_account/verify_user_account";
import { authScreens } from "../../styles/auth_screens";
import { send_new_verification_code } from "../../reusable_methods/verify_account/send_new_verification_code";
import { LoadingDialog } from "./LoadingDialog";

export function VerifyAccountForm({ route, navigation, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, set_loading_modal, set_type }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [controller, set_controller] = useState(new AbortController()); // Abort controller for canceling pending requests
    const [is_disabled, set_is_disabled] = useState(false); // State of OTP input either enabled or disabled (Default: enabled)
    const [user_details, set_user_details] = useState({ username: '', email: '', verify_account_token: '', user_id: 0 });

    // This hook will be called when the screen is focused
    useFocusEffect(
        useCallback(() => {
            // This hook will be called when the screen is focused
            const get_route_params = () => {
                let route_params = route.params;

                if (route_params && route_params.username && route_params.email && route_params.verify_account_token && route_params.user_id) {
                    set_user_details({ username: route_params.username, email: route_params.email, verify_account_token: route_params.verify_account_token, user_id: route_params.user_id }); // Store user details in the state
                }
            }
    
            get_route_params();

            return () => {
                // This hook will be called when the screen loses focus
                controller.abort();

                setTimeout(() => {
                    set_controller(new AbortController()); // Reset the abort controller to generate a new signal
                    set_snackbar_toggle(false); set_is_disabled(false); set_loading_modal(false);
                }, 400);
            };
        }, [])
    );

    return (
        <View>
            <View style={authScreens.bottom_view}>
                <Text numberOfLines={10} ellipsizeMode="tail" style={[authScreens.bottom_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Hello {user_details.username}, We just sent you a verification code to <Text style={{ fontFamily: 'RobotoBold' }}>"{user_details.email}"</Text>. Paste the code below to verify your account.</Text>
            </View>

            <OtpInput 
                autoFocus={false} 
                disabled={is_disabled}
                focusColor="#f19200"
                textInputProps={{ keyboardAppearance: is_darkmode === true ? 'dark' : 'light' }} 
                numberOfDigits={6} 
                onFilled={(text) => verify_user_account(text, user_details.username, user_details.email, user_details.verify_account_token, set_is_disabled, set_loading_modal, set_type, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, controller, navigation)}
                theme={{
                    containerStyle: { marginTop: 35 },
                    pinCodeTextStyle: { color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoRegular', fontSize: 23 },
                    pinCodeContainerStyle: { borderWidth: 1.5, height: 54.5, borderRadius: 6, borderColor: is_darkmode === true ? '#2a2e39' : '#bcbcbc', backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff' }
                }}
            />

            <View style={[authScreens.bottom_view, { marginTop: 28, justifyContent: 'center' }]}>
                <Text style={[authScreens.bottom_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Didn't receive the code?</Text>
                <TouchableOpacity onPress={() => send_new_verification_code(user_details.user_id, user_details, set_user_details, set_is_disabled, set_loading_modal, set_type, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, controller, navigation)}>
                    <Text style={authScreens.ll_txt}> Request here</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}