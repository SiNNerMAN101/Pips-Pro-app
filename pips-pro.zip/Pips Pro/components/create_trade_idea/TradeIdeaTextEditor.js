import { actions, RichEditor, RichToolbar } from "react-native-pell-rich-editor";
import { View, Pressable } from 'react-native';
import FontFamilyStylesheet from '../../reusable_methods/trade_ideas/stylesheet';
import { handleBold, handleBulletList, handleItalic, handleLink, handleOrderedList, handleStrikeThrough } from '../../reusable_methods/trade_ideas/text_editor_icons';
import { useSelector } from "react-redux";
import { useRef } from "react";

export function TradeIdeaTextEditor({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const richText = useRef();
    const fontFamily = 'Roboto';

    return (
        <View>
            <Pressable onPress={() => richText.current?.dismissKeyboard()}>
                <RichToolbar
                    editor={richText}
                    style={{ backgroundColor: is_darkmode === true ? '#42495b' : '#bcbcbc', borderTopLeftRadius: 6, borderTopRightRadius: 6, }}
                    actions={[ actions.setBold, actions.setItalic, actions.setStrikethrough, actions.insertBulletsList, actions.insertOrderedList, actions.insertLink ]}
                    onPressAddImage={() => richText.current?.insertImage('https://s3.tradingview.com/o/ocoytJe5_mid.webp')}
                    iconMap={{ [actions.setBold]: handleBold, [actions.setItalic]: handleItalic, [actions.setStrikethrough]: handleStrikeThrough, [actions.insertBulletsList]: handleBulletList, [actions.insertOrderedList]: handleOrderedList, [actions.insertLink]: handleLink }}
                />
            </Pressable>

            <View style={{ height: 300, backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', paddingHorizontal: 8, borderColor: is_darkmode === true ? '#2a2e39' : '#bcbcbc', borderBottomLeftRadius: 6, borderBottomRightRadius: 6, borderWidth: 1.5, borderStyle: 'solid' }}>
                <RichEditor
                    editorStyle={{ initialCSSText: `${FontFamilyStylesheet}`, contentCSSText: `font-family: ${fontFamily}`, backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', color: is_darkmode === true ? '#ffffff' : '#000000', placeholderColor: '#999696' }}
                    useContainer={false}
                    placeholder='Please provide a clear, meaningful and detailed description of your analysis and prediction.'
                    style={{ height: 300, borderBottomLeftRadius: 6, borderBottomRightRadius: 6 }}
                    ref={richText}
                    onChange={ descriptionText => {
                        console.log("descriptionText:", descriptionText);
                    }}
                />
            </View>
        </View>
    );    
}