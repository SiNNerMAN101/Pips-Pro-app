import { View, Pressable } from 'react-native';
import { Foundation } from '@expo/vector-icons';
import { useSelector } from 'react-redux';

export function TextEditorToolbar({ handle_toolbar_interaction, selection, setSelection, values, setFieldValue }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    return (
        <View style={{ flexDirection: 'row', justifyContent: 'center', backgroundColor: is_darkmode === true ? '#42495b' : '#bcbcbc', borderTopLeftRadius: 6, borderTopRightRadius: 6, padding: 8 }}>
            <Pressable onPress={() => handle_toolbar_interaction(1, selection, setSelection, values, setFieldValue)}>
                <Foundation name="bold" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
            </Pressable>
            <Pressable onPress={() => handle_toolbar_interaction(2, selection, setSelection, values, setFieldValue)} style={{ marginLeft: 18 }}>
                <Foundation name="italic" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
            </Pressable>
            <Pressable onPress={() => handle_toolbar_interaction(3, selection, setSelection, values, setFieldValue)} style={{ marginLeft: 18 }}>
                <Foundation name="strikethrough" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
            </Pressable>
            <Pressable onPress={() => handle_toolbar_interaction(4, selection, setSelection, values, setFieldValue)} style={{ marginLeft: 18 }}>
                <Foundation name="list-bullet" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
            </Pressable>
            <Pressable onPress={() => handle_toolbar_interaction(5, selection, setSelection, values, setFieldValue)} style={{ marginLeft: 18 }}>
                <Foundation name="list-number" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
            </Pressable>
            <Pressable onPress={() => handle_toolbar_interaction(6, selection, setSelection, values, setFieldValue)} style={{ marginLeft: 18 }}>
                <Foundation name="link" size={24} color={is_darkmode === true ? "#ffffff" : "#000000"} />
            </Pressable>
        </View>
    );    
}