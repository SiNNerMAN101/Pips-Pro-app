import { View, Platform } from "react-native";
import { SearchBar } from '@rneui/themed';
import { useCallback, useEffect, useRef, useState } from "react";
import { ChannelsFlatlist } from "./search_channels_modal/ChannelsFlatlist";
import { useSelector } from 'react-redux';
import { StatusBar } from "expo-status-bar";
import { ChannelFlatlistLoading } from "./search_channels_modal/ChannelFlatlistLoading";
import { handle_search } from "../../reusable_methods/search_channels_modal/handle_search";
import { NoSearchResults } from "./NoSearchResults";
import { useFocusEffect } from "@react-navigation/native";

// Display a modal to search for available channels
export function SearchChannelsModal({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [loading, setLoading] = useState(true);
    const [controller, set_controller] = useState(new AbortController());

    // Create a ref for the TextInput component
    const textInputRef = useRef();

    // Handle search bar text change
    const handleChangeText = (text) => {
        setSearchQuery(text);
    };

    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {

            if (/^\s*$/.test(searchQuery) === false) {
                handle_search(setLoading, setSearchResults, searchQuery, controller);
            } else {
                setLoading(true)
            }
        }, 500); // Adjust the delay as needed (e.g., 500 milliseconds)

        return () => clearTimeout(delayDebounceFn);
    }, [searchQuery]); // Re-run the effect whenever searchQuery changes

    // This hook will be called when the screen is focused
    useFocusEffect(
        useCallback(() => {
            // This hook will be called when the screen is focused
            textInputRef.current.focus();

            return () => {
                // This function will be called when the screen loses focus
                setSearchQuery("");
                controller.abort();
                set_controller(new AbortController());
            };
        }, [])
    );

    return (
        <View style={{ flex: 1, backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' }}>
            <View style={{ flexDirection: 'row', paddingHorizontal: 16 }}>
                <SearchBar
                    ref={textInputRef}
                    inputStyle={{ fontSize: 17, fontFamily: 'RobotoRegular', minHeight: 30, color: is_darkmode === true ? '#ffffff' : '#000000' }}
                    inputContainerStyle={{ height: 30, borderRadius: 30, backgroundColor: is_darkmode === true ? '#2c344a' : '#dcdce1' }}
                    onCancel={() => {
                        navigation.goBack();
                    }}
                    platform="ios"
                    showCancel={true}
                    cancelButtonTitle="Close"
                    cancelButtonProps={{ buttonTextStyle: { fontFamily: 'RobotoRegular', color: '#f19200' } }}
                    searchIcon={Platform.OS === 'ios' ? {name: 'search'} : null} clearIcon={Platform.OS === 'ios' ? {name: 'close-circle'} : null}
                    containerStyle={{ borderRadius: 20, width: '100%', backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' }}
                    lightTheme={true}
                    placeholder="Search"
                    keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                    onChangeText={handleChangeText}
                    value={searchQuery}
                    autoCapitalize={"characters"}
                />
            </View>

            {
                loading === true ?
                    <ChannelFlatlistLoading />
                : loading === false ?
                    <ChannelsFlatlist searchResults={searchResults} navigation={navigation} />
                : loading === 'no_result' ?
                    <NoSearchResults searchQuery={searchQuery} />
                : <></>
            }

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}