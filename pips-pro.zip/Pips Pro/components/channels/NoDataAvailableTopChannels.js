import { View, Text } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';

export function NoDataAvailableTopChannels({  }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    // Refresh to fetch top channels
    /*const handleRefresh = async () => {
        if (top_channels_refresh === false){
            // Set refreshing to true to show the loading indicator
            set_top_channels_refresh(true);

            let auth_token = await SecureStore.getItemAsync('auth_token'); // Get auth token if available

            await refresh_top_channels(auth_token ? auth_token : null, set_top_channels_refresh);
        }
    };*/

    return (
        <ScrollView
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30 }}
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <AntDesign name="inbox" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                <View style={{ alignItems: 'center' }}>
                    <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>No top channels available at this time</Text>
                </View>
            </View>
        </ScrollView>
    );
}