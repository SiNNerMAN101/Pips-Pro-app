import { View, Text, FlatList, TouchableOpacity } from "react-native";
import { watchList } from "../../../styles/watchlist";
import { Avatar } from "@rneui/themed";
import { useSelector } from 'react-redux';
import { LoadChannelProfileImage } from "../LoadChannelProfileImage";

// List containing searched channels
export function ChannelsFlatlist({ searchResults, navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    const go_to_chats = (channel_id, joined, channel_name, channel_type, channel_image, creator_id, channel_uid, type, seen_chats, recent_chat_msg, total_subs) => {
        navigation.goBack();

        setTimeout(() => {
            navigation.navigate('Chat', {
                channel_id: channel_id,
                joined: joined,
                channel_name: channel_name,
                channel_type: channel_type,
                channel_image: channel_image,
                creator_id: creator_id,
                channel_uid: channel_uid,
                type: type,
                seen_chats: seen_chats,
                recent_chat_msg: recent_chat_msg,
                total_subs: total_subs
            });
        }, 300);
    }

    return (
        <FlatList
            style={[watchList.modal_flatlist, { marginTop: 8, backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' }]}
            data={searchResults}
            renderItem={({ item }) => (
                <TouchableOpacity onPress={() => go_to_chats(item.channel_id, item.joined, item.channel_name, item.channel_type, item.channel_image, item.creator_id, item.channel_uid, item.type, item.seen_chats, item.recent_chat_msg, item.total_subs)} style={{ flexDirection: 'row', marginHorizontal: 17, alignItems: 'center', justifyContent: 'space-between', marginVertical: 15, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        { 
                            item.channel_image === null ? 
                                <Avatar
                                    size={43}
                                    rounded
                                    titleStyle={{ color: '#ffffff' }}
                                    title={item.channel_name.charAt(0)}
                                    containerStyle={{ backgroundColor: "#cecece" }}
                                />
                            : <LoadChannelProfileImage img_url={item.channel_image} channel_name={item.channel_name} /> 
                        }

                        <Text style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', fontSize: 15, marginLeft: 9, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.channel_name}</Text> 
                    </View>
                    
                    <View>
                        <View style={{ backgroundColor: '#f19200', paddingVertical: 3, paddingHorizontal: 8, borderRadius: 20 }}>
                            <Text style={{ fontSize: 13, fontFamily: 'RobotoRegular', color: '#ffffff' }}>{item.channel_type === 'public' ? 'public' : 'private'}</Text>
                        </View>
                    </View>
                </TouchableOpacity>
            )}
            keyExtractor={(item) => item.id}
        />
    );
}