import { watchList } from "../../../styles/watchlist";
import { useSelector } from 'react-redux';
import { View, FlatList } from "react-native";
import { Skeleton } from "@rneui/themed";

// A skeleton loader for the search channels modal
export function ChannelFlatlistLoading({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <FlatList
            scrollEnabled={false}
            style={[watchList.modal_flatlist, { marginTop: 8 }]}
            data={Array.from({length: 10}, (_, i) => i + 1)}
            renderItem={({ item }) => (
                <View style={{ flexDirection: 'row', marginVertical: 15, justifyContent: 'space-between', marginLeft: 17, marginRight: 17, marginBottom: 10, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
                    <View style={{ flexDirection: 'row', flex: 1, height: 43, alignItems: 'center' }}>
                        <Skeleton circle animation='wave' width={43} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede' }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={43} />   

                        <Skeleton animation='wave' width={120} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginLeft: 13 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                    </View>
                </View>
            )}
            keyExtractor={(item) => item}
        />
    );
}