import { FlatList } from "react-native";
import { useSelector } from 'react-redux';
import { useMemo } from "react";
import { ChannelItemComp } from "./top_channels/ChannelItemComp";

// A list of top channels that the user can join
export function TopChannels({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const top_channels = useSelector((state) => state.channels.top_channels); // List of top channels that the user has might or may have not joined from the most popular to the least popular
    const ITEM_HEIGHT = 69.5;

    const renderItem = ({ item }) => {
        return (
            <ChannelItemComp navigation={navigation} item={item} />
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [is_darkmode]);

    return (
        <FlatList
            data={top_channels}
            style={{ marginTop: 17, flex: 1 }}
            initialNumToRender={10}
            maxToRenderPerBatch={10}
            windowSize={5}
            getItemLayout={(data, index) => ({
                length: ITEM_HEIGHT,    // Set the height of each item
                offset: ITEM_HEIGHT * index, // Calculate the offset for each item
                index
            })}
            indicatorStyle={is_darkmode === true ? 'white' : 'black'}
            removeClippedSubviews={true}
            renderItem={memoizedRenderItem}
            keyExtractor={(item) => item.id}
        />
    );
}