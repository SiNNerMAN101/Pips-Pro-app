import { View, TouchableOpacity } from "react-native";
import { useSelector } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { useMemo } from "react";
import { channels } from "../../../styles/channels";
import { headerStyles } from "../../../styles/header_styles";

export default function ChannelsHeaderRight({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode);
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // User current logged in state
    const channels_state = useSelector((state) => state.channels.channels_state); // Current state of both my channels and top channels tabs
    const refreshing = useSelector((state) => state.channels.refreshing); // The refreshing state for refreshing the my channels and top channels sections

    // Memoize the styles to avoid recalculating them on each render
    const channels_styles = useMemo(() => channels(is_darkmode), [is_darkmode]);
    const header_styles = useMemo(() => headerStyles(is_darkmode), [is_darkmode]);

    return (
        <View style={header_styles.double_items_header_right}>
            {
                is_user_logged_in === true && channels_state === true && refreshing === false ?
                    <TouchableOpacity onPress={() => navigation.navigate('CreateChannelModal')} style={channels_styles.create_channel_btn}>
                        <Ionicons name="add-outline" size={31} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                : <></>
            }

            <TouchableOpacity onPress={() => navigation.navigate('SearchChannelsModal')}>
                <Ionicons name="search-outline" size={31} color={is_darkmode === true ? '#ffffff' : '#000000'} />
            </TouchableOpacity>
        </View>
    );
}