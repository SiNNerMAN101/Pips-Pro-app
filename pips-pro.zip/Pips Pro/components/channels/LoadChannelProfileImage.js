import { View } from 'react-native';
import { useState } from "react";
import { Avatar } from '@rneui/themed';
import { Image } from 'expo-image';

// Loading placeholder for channels profile image
export function LoadChannelProfileImage({ img_url, channel_name }) {
    const [loading, setLoading] = useState(true);

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => (
        <Avatar
            size={43}
            rounded
            titleStyle={{ color: '#ffffff' }}
            title={channel_name.charAt(0)}
            containerStyle={{ backgroundColor: "#cecece" }}
        /> 
    );

    return (
        <View style={{ width: 43, height: 43 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: 43, height: 43, borderRadius: 50 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={img_url}
                contentFit="cover"
            />
        </View>
    );
}