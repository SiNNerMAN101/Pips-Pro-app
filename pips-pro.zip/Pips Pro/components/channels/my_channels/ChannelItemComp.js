import { View, Text, TouchableOpacity } from "react-native";
import { Avatar } from "@rneui/themed";
import { useSelector } from 'react-redux';
import { LoadChannelProfileImage } from "../LoadChannelProfileImage";
import { useActionSheet } from "@expo/react-native-action-sheet";
import { menu_sheet } from "../../../reusable_methods/channels/menu_sheet";
import { ChannelNameAndRecentChatType } from "./ChannelNameAndRecentChatType";

// The item component for each channel in the my channels flatlist
export function ChannelItemComp({ navigation, item, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, getSocket, set_loading_dialog, set_loading_dialog_title, exit_delete_channel_controller }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const { showActionSheetWithOptions } = useActionSheet();

    // Navigate to the chats screen
    const open_channel_chats = (channel_id, joined, channel_name, channel_type, channel_image, creator_id, channel_uid, type, seen_chats, recent_chat_msg, total_subs) => {
        navigation.navigate('Chat', {
            channel_id: channel_id,
            joined: joined,
            channel_name: channel_name,
            channel_type: channel_type,
            channel_image: channel_image,
            creator_id: creator_id,
            channel_uid: channel_uid,
            type: type,
            seen_chats: seen_chats,
            recent_chat_msg: recent_chat_msg,
            total_subs: total_subs
        });
    }

    return (
        <TouchableOpacity onLongPress={() => menu_sheet(item, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, getSocket, set_loading_dialog, set_loading_dialog_title, exit_delete_channel_controller)} delayLongPress={200} onPress={() => open_channel_chats(item.channel_id, item.joined, item.channel_name, item.channel_type, item.channel_image, item.creator_id, item.channel_uid, item.type, item.seen_chats, item.recent_chat_msg, item.total_subs)} style={{ flexDirection: 'row', marginHorizontal: 17, marginVertical: 8, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
            <View style={{ flexDirection: 'row', alignContent: 'center' }}>
                { 
                    item.channel_image === null || item.channel_image === undefined ? 
                        <Avatar
                            size={43}
                            rounded
                            titleStyle={{ color: '#ffffff' }}
                            title={item.channel_name.charAt(0)}
                            containerStyle={{ backgroundColor: "#cecece" }}
                        />
                    : <LoadChannelProfileImage img_url={item.channel_image} channel_name={item.channel_name} /> 
                }

               <ChannelNameAndRecentChatType item={item} />
            </View>
            
            {
                item.recent_chat_msg.datetime === null ?
                    <></>
                :   <View style={{ flex: 1, justifyContent: 'space-between', alignItems: 'flex-end' }}>
                        <Text style={{ fontSize: 13, fontFamily: 'RobotoRegular', color: '#747474' }}>{item.recent_chat_msg.formatted_date}</Text>
                        { item.seen_chats === false ? <View style={{ width: 12, height: 12, backgroundColor: '#f19200', borderRadius: 100 }}></View> : <></> }
                    </View>
            }
        </TouchableOpacity>
    );
}