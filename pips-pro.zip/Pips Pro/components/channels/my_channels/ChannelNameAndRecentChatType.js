import { View, Text } from "react-native";
import { useSelector } from 'react-redux';
import { FontAwesome } from '@expo/vector-icons';

// The name of the channel and it's recent chat message if available 
export function ChannelNameAndRecentChatType({ item }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <View style={{ justifyContent: 'space-between', height: 43, marginLeft: 9 }}>
            <Text numberOfLines={1} ellipsizeMode="tail" style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', maxWidth: 200, fontSize: 15, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.channel_name}</Text>
            {
                item.type === 'new_channel' ?
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ width: 170, fontFamily: 'RobotoRegular', fontSize: 14, color: is_darkmode === true ? '#ffffff' : '#4c4c4c' }}>No messages yet</Text>
                : item.type === 'empty_channel' ?
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ width: 170, fontFamily: 'RobotoRegular', fontSize: 14, color: is_darkmode === true ? '#ffffff' : '#4c4c4c' }}>No messages yet</Text>
                : item.type === 'msg_deleted' ?
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start' }}>
                        <FontAwesome name="trash" size={13.4} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                        <Text style={{ color: is_darkmode === true ? '#ffffff' : '#000000', marginLeft: 7, fontFamily: 'RobotoRegular', fontSize: 14 }}>Chat deleted</Text>
                    </View>
                : item.type === 'msg_available' ?
                    <>
                        {
                            item.recent_chat_msg.chat_type === 1 ?
                                <Text numberOfLines={1} ellipsizeMode="tail" style={{ width: 170, fontFamily: 'RobotoRegular', fontSize: 14, color: is_darkmode === true ? '#ffffff' : '#4c4c4c' }}>{item.recent_chat_msg.chat}</Text>
                            : item.recent_chat_msg.chat_type === 2 ?
                                <Text numberOfLines={1} ellipsizeMode="tail" style={{ width: 170, fontFamily: 'RobotoRegular', fontSize: 14, color: is_darkmode === true ? '#ffffff' : '#4c4c4c' }}>{item.recent_chat_msg.chat}</Text>
                            : <></>
                        }
                    </>
                : <></>
            }
        </View>
    );
}