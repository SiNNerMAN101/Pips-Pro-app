import { useSelector } from 'react-redux';
import { dropdownMenu } from '../../../styles/dropdown_menu';
import { AntDesign } from '@expo/vector-icons';
import { useMemo } from 'react';

export function RenderRightIcon({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

     // Memoize the styles to avoid recalculating them on each render
     const dropdownmenu_styles = useMemo(() => dropdownMenu(is_darkmode), [is_darkmode]);

    return (
        <AntDesign
            style={dropdownmenu_styles.icon}
            color={is_darkmode === true ? '#ffffff' : '#000000'}
            name="caretdown"
            size={13}
        />
    );
}