import { TextInput, View, Text } from 'react-native';
import { authScreens } from "../../../styles/auth_screens";
import { useRef, useState, useCallback, useMemo } from "react";
import { Formik } from "formik";
import { object, string } from 'yup';
import { useFocusEffect } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { Button } from '@rneui/themed';
import { Dropdown } from 'react-native-element-dropdown';
import { dropdownMenu } from '../../../styles/dropdown_menu';
import { create_channel } from '../../../reusable_methods/channels/create_channel';
import { RenderRightIcon } from './RenderRightIcon';
import { AntDesign } from '@expo/vector-icons';
import { channels } from '../../../styles/channels';

const CreateChannelSchema = object({
    channel_name: string().required('This field is required').test('there-must-be-no-empty-or-white-space', 'This field is required', (val) => {
        var validRegex = /^\s*$/;
        return !val.match(validRegex);
    }).min(5, 'Must be at least five characters minimum').max(30, 'Must not be more than 30 characters'),
    channel_desc: string().required('This field is required').test('there-must-be-no-empty-or-white-space', 'This field is required', (val) => {
        var validRegex = /^\s*$/;
        return !val.match(validRegex);
    }).min(5, 'Must be at least five characters minimum').max(200, 'Must not be more than 200 characters')
})

export function CreateChannelModalForm({ set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [value, setValue] = useState(null);
    const [dropdown_error, set_dropdown_error] = useState(false);
    const [is_loading, set_is_loading] = useState(false); // State of the continue/login button
    const [editable, set_editable] = useState(true); const [disable, set_disable] = useState(false);
    const controller = useRef(new AbortController()); // Abort controller for canceling pending requests

    const data = [
        { label: 'Public', value: '1' },
        { label: 'Private', value: '2' },
    ];

    const formikRef = useRef();

    // Memoize the styles to avoid recalculating them on each render
    const dropdownmenu_styles = useMemo(() => dropdownMenu(is_darkmode), [is_darkmode]);

    // This hook will be called when the screen is focused
    useFocusEffect(
        useCallback(() => {
            // This hook will be called when the screen is focused

            return () => {
                controller.current.abort();
                controller.current = new AbortController();
                // This function will be called when the screen loses focus
                setTimeout(() => {
                    formikRef.current?.resetForm(); // Reset login form
                }, 500);
            };
        }, [])
    );

    let RenderItem = (item) => {
        return (
            <View style={dropdownmenu_styles.item}>
                <Text style={dropdownmenu_styles.textItem}>{item.label}</Text>
                {item.value === value && (
                  <AntDesign
                    style={dropdownmenu_styles.icon}
                    color={is_darkmode === true ? '#ffffff' : '#000000'}
                    name="check"
                    size={20}
                  />
                )}
            </View>
        );
    }

    return (
        <Formik
            innerRef={formikRef}
            initialValues={{ channel_name: '', channel_desc: '' }}
            validationSchema={CreateChannelSchema}
            onSubmit={(values) => create_channel(values.channel_name, values.channel_desc, value, is_loading, set_is_loading, dropdown_error, set_dropdown_error, controller, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, set_editable, set_disable, navigation)}
        >
            {({ handleChange, handleSubmit, values, errors, touched, handleBlur }) => (
                <>
                    <View style={[authScreens.email_or_username_inp_container, { borderColor: (errors.channel_name && touched.channel_name) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc') }, channels(is_darkmode).inp_container ]}>
                        <TextInput
                            style={[authScreens.email_or_username_inp_field, channels(is_darkmode).inp_field]}
                            placeholder="Channel name"
                            editable={editable}
                            placeholderTextColor={'#999696'}
                            keyboardType="default"
                            onBlur={handleBlur('channel_name')} 
                            onChangeText={handleChange('channel_name')}
                        />
                    </View>
                    { (touched.channel_name && errors.channel_name) ? (<Text style={authScreens.errorText}>{errors.channel_name}</Text>) : '' }

                    <TextInput
                        style={[authScreens.channel_desc_inp, { borderColor: (errors.channel_desc && touched.channel_desc) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc') }, channels(is_darkmode).inp_container ]}
                        placeholder="Channel description"
                        multiline={true}
                        numberOfLines={4}
                        editable={editable}
                        placeholderTextColor={'#999696'}
                        keyboardType="default"
                        onBlur={handleBlur('channel_desc')} 
                        onChangeText={handleChange('channel_desc')} 
                    />
                    { (touched.channel_desc && errors.channel_desc) ? (<Text style={authScreens.errorText}>{errors.channel_desc}</Text>) : '' }

                    <Dropdown
                        style={[dropdownmenu_styles.dropdown, { borderColor: (dropdown_error === true) ? 'red' : (is_darkmode === true ? '#2a2e39' : '#bcbcbc') }]}
                        placeholderStyle={dropdownmenu_styles.placeholderStyle}
                        selectedTextStyle={dropdownmenu_styles.selectedTextStyle}
                        iconStyle={dropdownmenu_styles.iconStyle}
                        data={data}
                        activeColor="#f19200"
                        disable={disable}
                        search={false}
                        maxHeight={300}
                        containerStyle={dropdownmenu_styles.menu_list}
                        labelField="label"
                        valueField="value"
                        placeholder="Select channel type"
                        value={value}
                        mode="default"
                        onChange={item => {
                            set_dropdown_error(false);
                            setValue(item.value);
                        }}
                        renderItem={RenderItem}
                        renderRightIcon={RenderRightIcon}
                    />
                    { (dropdown_error === true) ? (<Text style={authScreens.errorText}>This field is required</Text>) : '' }

                    <View style={authScreens.btn_container}>
                        <Button title="Create" loading={is_loading === true ? true : false} titleStyle={authScreens.btn_font} containerStyle={authScreens.btn_width} buttonStyle={authScreens.btn} onPress={handleSubmit} />
                    </View>
                </>
            )}
        </Formik>
    );
}