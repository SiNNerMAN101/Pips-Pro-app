import { View, FlatList } from "react-native";
import { Skeleton } from "@rneui/themed";
import { useSelector } from 'react-redux';

// Loading screen for top channels
export function LoadingTopChannels({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <FlatList
            data={Array.from({length: 10}, (_, i) => i + 1)}
            scrollEnabled={false}
            style={{ marginHorizontal: 17, marginTop: 17, flex: 1 }}
            renderItem={({ item }) => (
                <View style={{ flexDirection: 'row', marginVertical: 15, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
                    <Skeleton circle animation='wave' width={43} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede' }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={43} />   
    
                    <View style={{ justifyContent: 'space-between', height: 43, marginLeft: 9 }}>
                        <Skeleton animation='wave' width={120} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginBottom: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                        <Skeleton animation='wave' width={120} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                    </View>
    
                    <View style={{ flexDirection: 'column', alignItems: 'flex-end', justifyContent: 'space-between', flex: 1, height: 43 }}>
                        <Skeleton animation='wave' width={60} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginBottom: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                        <Skeleton animation='wave' width={60} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginTop: 3 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                    </View>
                </View>
            )}
            keyExtractor={(item) => item}
        />
    );
}