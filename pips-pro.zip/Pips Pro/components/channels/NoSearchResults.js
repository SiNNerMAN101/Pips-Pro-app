import { View, Text } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';

export function NoSearchResults({ searchQuery }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode

    return (
        <ScrollView
            scrollEnabled={false}
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30 }}
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <AntDesign name="inbox" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>No results found for "{searchQuery}"</Text>
            </View>
        </ScrollView>
    );
}