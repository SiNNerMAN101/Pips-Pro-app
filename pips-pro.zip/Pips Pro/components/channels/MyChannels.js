import { View, FlatList, ActivityIndicator } from "react-native";
import { useSelector } from 'react-redux';
import { useMemo, useState } from "react";
import { load_more_channels } from "../../reusable_methods/channels/load_more_channels";
import { ChannelItemComp } from "./my_channels/ChannelItemComp";

// All the channels that the user is currently part of
export function MyChannels({ navigation, fetch_more_channels, set_fetch_more_channels, load_more_channels_controller, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, getSocket, set_loading_dialog, set_loading_dialog_title, exit_delete_channel_controller }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const my_channels = useSelector((state) => state.channels.my_channels); // List of channels that the user has joined
    const [load_comp, set_load_comp] = useState(false); // The state of the loading component
    const ITEM_HEIGHT = 69.5;

    // Try to load more of the users channels as the user reaches the bottom of the flatlist
    const handleReachedBottom = async () => {
        if (load_comp !== 'complete'){
            set_load_comp(true);
            await load_more_channels(load_more_channels_controller, fetch_more_channels, set_fetch_more_channels, set_load_comp)
        }
    };

    const renderItem = ({ item }) => {
        return (
            <ChannelItemComp navigation={navigation} item={item} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} getSocket={getSocket} set_loading_dialog={set_loading_dialog} set_loading_dialog_title={set_loading_dialog_title} exit_delete_channel_controller={exit_delete_channel_controller} />
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [is_darkmode]);

    return (
        <FlatList
            data={my_channels}
            ListFooterComponent={
                load_comp === true ? (
                    <View style={{ padding: 10 }}>
                        <ActivityIndicator size="small" />
                    </View>
                ) : null
            }
            getItemLayout={(data, index) => ({
                length: ITEM_HEIGHT,    // Set the height of each item
                offset: ITEM_HEIGHT * index, // Calculate the offset for each item
                index
            })}
            onEndReached={handleReachedBottom}
            indicatorStyle={is_darkmode === true ? 'white' : 'black'}
            onEndReachedThreshold={0.1} // Adjust threshold as necessary
            scrollEventThrottle={16}
            style={{ marginTop: 17, flex: 1 }}
            initialNumToRender={10}
            maxToRenderPerBatch={10}
            windowSize={5}
            renderItem={memoizedRenderItem}
            keyExtractor={(item) => item.id.toString()}
        />
    );
}