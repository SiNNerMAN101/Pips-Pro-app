import { View, Text } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';
import { Button } from '@rneui/themed';
import { channels } from '../../styles/channels';
import { useMemo } from 'react';
import { authScreens } from '../../styles/auth_screens';

export function NoDataAvailableMyChannels({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // User current logged in state

    // Memoize the styles to avoid recalculating them on each render
    const channels_styles = useMemo(() => channels(is_darkmode), [is_darkmode]);
    
    const go_to_login = () => {
        if (is_user_logged_in === false){
            navigation.navigate('Login');
        }
    }

    return (
        <ScrollView
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30 }}
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <AntDesign name="inbox" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                <View style={{ alignItems: 'center' }}>
                    {
                        is_user_logged_in === true ?
                            <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>You have no channels at this time</Text>
                        :   <>
                                <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>Please login to view all your channels</Text>
                                <Button title="Login" onPress={go_to_login} titleStyle={authScreens.btn_font} containerStyle={channels_styles.btn_width} buttonStyle={channels_styles.btn} />
                            </> 
                    }
                </View>
            </View>
        </ScrollView>
    );
}