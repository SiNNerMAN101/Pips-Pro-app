import { View, Text, TouchableOpacity } from "react-native";
import { Avatar } from "@rneui/themed";
import { useSelector } from 'react-redux';
import { LoadChannelProfileImage } from "../LoadChannelProfileImage";
import { format_number } from "../../../reusable_methods/channels/format_number";

// The item component for each channel in the top channels flatlist
export function ChannelItemComp({ navigation, item }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    // Navigate to the chats screen
    const open_channel_chats = (channel_id, joined, channel_name, channel_type, channel_image, creator_id, channel_uid, type, seen_chats, recent_chat_msg, total_subs) => {
        navigation.navigate('Chat', {
            channel_id: channel_id,
            joined: joined,
            channel_name: channel_name,
            channel_type: channel_type,
            channel_image: channel_image,
            creator_id: creator_id,
            channel_uid: channel_uid,
            type: type,
            seen_chats: seen_chats,
            recent_chat_msg: recent_chat_msg,
            total_subs: total_subs
        });
    }

    return (
        <TouchableOpacity onPress={() => open_channel_chats(item.channel_id, item.joined, item.channel_name, item.channel_type, item.channel_image, item.creator_id, item.channel_uid, item.type, item.seen_chats, item.recent_chat_msg, item.total_subs)} style={{ flexDirection: 'row', marginHorizontal: 17, alignItems: 'center', marginVertical: 8, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
            <View style={{ flexDirection: 'row', alignContent: 'center' }}>
                { 
                    item.channel_image === null || item.channel_image === undefined ? 
                        <Avatar
                            size={43}
                            rounded
                            titleStyle={{ color: '#ffffff' }}
                            title={item.channel_name.charAt(0)}
                            containerStyle={{ backgroundColor: "#cecece" }}
                        />
                    : <LoadChannelProfileImage img_url={item.channel_image} channel_name={item.channel_name} /> 
                }

                <View style={{ justifyContent: 'space-between', height: 43, marginLeft: 9 }}>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', maxWidth: 200, fontSize: 15, color: is_darkmode === true ? '#ffffff' : '#000000' }}>{item.channel_name}</Text>
                    <Text numberOfLines={1} ellipsizeMode="tail" style={{ width: 170, fontFamily: 'RobotoRegular', fontSize: 14, color: is_darkmode === true ? '#ffffff' : '#4c4c4c' }}>{item.total_subs === 0 ? '0 subscribers' : item.total_subs === 1 ? '1 subscriber' : `${format_number(item.total_subs)} subscribers`}</Text>
                </View>
            </View>

            <View style={{ height: '100%', flex: 1, justifyContent: 'space-between', alignItems: 'flex-end' }}>
                <View style={{ backgroundColor: '#f19200', paddingVertical: 3, paddingHorizontal: 8, borderRadius: 20 }}>
                    <Text style={{ fontSize: 13, fontFamily: 'RobotoRegular', color: '#ffffff' }}>{item.channel_type === 'public' ? 'public' : 'private'}</Text>
                </View>
            </View>
        </TouchableOpacity>
    );
}