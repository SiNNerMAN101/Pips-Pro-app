import { View, Platform, TouchableOpacity, Text, KeyboardAvoidingView } from "react-native";
import { useSelector } from 'react-redux';
import { AntDesign, MaterialIcons } from '@expo/vector-icons';
import { ScrollView } from "react-native-gesture-handler";
import { CreateChannelModalForm } from "./create_channel_modal/CreateChannelModalForm";
import { useMemo, useState } from "react";
import { Snackbar } from "react-native-paper";
import { snackBarStyles } from "../../styles/snackbar";

// Display a modal where the user can create a new channel
export function CreateChannelModal({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);

    // Memoize the styles to avoid recalculating them on each render
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);

    return (
        <KeyboardAvoidingView keyboardVerticalOffset={20} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', height: 43, marginTop: 13, paddingHorizontal: 16 }}>
                <View style={{ width: 31.0, height: 31.0 }}></View>
                <Text style={{ color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontWeight: 'bold', fontSize: 18 }}>Create channel</Text>
                <TouchableOpacity onPress={() => navigation.goBack()}><AntDesign name="closecircleo" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity>
            </View>

            <ScrollView style={{ flex: 1 }}>
                <View style={{ paddingHorizontal: 16, marginTop: 76 }}>
                    <CreateChannelModalForm set_snackbar_toggle={set_snackbar_toggle} set_snackbar_msg={set_snackbar_msg} set_snackbar_err={set_snackbar_err} navigation={navigation} />
                </View>
            </ScrollView>

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>
        </KeyboardAvoidingView>
    );
}