import { View, Text, TouchableOpacity, Platform } from "react-native";
import { useSelector } from 'react-redux';
import { watchList } from "../../styles/watchlist";
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { authScreens } from "../../styles/auth_screens";

export function Header({ navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties

    return (
        <View style={[watchList.header_bar, { borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd' }]}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={[authScreens.go_back_btn, { marginLeft: 17, position: 'relative', left: Platform.OS === 'ios' ? -4 : 0, width: 69.0, height: 31.5 }]}>
                {
                    Platform.OS === 'ios' ?
                        <>
                            <Ionicons name="chevron-back-outline" size={31} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                            <Text style={[authScreens.go_back_btn_txt, { color: is_darkmode === true ? "#ffffff" : "#000000" }]}>Back</Text>
                        </>
                    : <MaterialIcons name="arrow-back" size={31} color={is_darkmode === true ? "#ffffff" : "#000000"} />
                }
            </TouchableOpacity>

            <TouchableOpacity><Text numberOfLines={1} ellipsizeMode="tail" style={{ fontFamily: 'RobotoBold', color: is_darkmode === true ? '#ffffff' : '#000000', fontWeight: 'bold', fontSize: 18, maxWidth: 155 }}>{channel_properties['channel_name']}</Text></TouchableOpacity>

            <TouchableOpacity style={{ width: 69.0, height: 31.5, marginRight: 17, alignItems: 'flex-end' }}>
                <Ionicons name="settings-outline" size={31} color={is_darkmode === true ? '#ffffff' : '#000000'} />
            </TouchableOpacity>
        </View>
    );
};