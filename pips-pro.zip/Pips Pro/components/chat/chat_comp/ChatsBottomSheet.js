import { View, Text } from 'react-native';
import { authScreens } from "../../../styles/auth_screens";
import { useSelector } from 'react-redux';
import BottomSheet, { BottomSheetView } from "@gorhom/bottom-sheet";
import { Avatar, Button } from '@rneui/themed';
import { LoadChannelProfileImage } from "../../../components/channels/LoadChannelProfileImage";
import { useState } from 'react';
import { user_join_channel } from '../../../reusable_methods/chat/join_channel';

export function ChatBottomSheet({ bottomSheetRef, navigation, controller, flatListRef, connectSocket, getSocket, handleSheetChanges, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // State of the app if user is logged in or not
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties
    const [join_channel_loading, set_join_channel_loading] = useState(false);

    let join_channel = async () => {
        if (is_user_logged_in === true){
            await user_join_channel(join_channel_loading, controller, flatListRef, connectSocket, getSocket, set_join_channel_loading, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err);
        } else {
            navigation.navigate('Login'); // Navigate the user to the login screen
        }
    }

    return (
        <BottomSheet
            ref={bottomSheetRef}
            index={0}
            snapPoints={['30%', '50%']}
            onChange={handleSheetChanges}
            handleIndicatorStyle={{ backgroundColor: is_darkmode === true ? '#ffffff' : '#000000' }}
            enableHandlePanningGesture={false}
            enableContentPanningGesture={false}
            backgroundStyle={{ backgroundColor: is_darkmode === true ? '#131722' : '#ffffff', shadowOffset: { width: 0, height: -2 }, shadowOpacity: 0.25, shadowRadius: 3.84, elevation: 5, }}
        >
            <BottomSheetView style={{ flex: 1 }}>
                <BottomSheetView style={{ margin: 17 }}>
                    <BottomSheetView style={{ flexDirection: 'row', alignItems: 'center' }}>
                        { 
                            channel_properties.channel_image === null || channel_properties.channel_image === undefined ? 
                                <Avatar
                                    size={43}
                                    rounded
                                    titleStyle={{ color: '#ffffff' }}
                                    title={channel_properties.channel_name.charAt(0)}
                                    containerStyle={{ backgroundColor: "#cecece" }}
                                />
                            : <LoadChannelProfileImage img_url={channel_properties.channel_image} channel_name={channel_properties.channel_name} /> 
                        }
                        <View>
                            <Text style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', color: is_darkmode === true ? '#ffffff' : '#000000', fontSize: 18, marginLeft: 13, marginBottom: 1.5 }}>{channel_properties.channel_name}</Text>
                            <Text style={{ fontWeight: 'bold', fontFamily: 'RobotoBold', color: is_darkmode === true ? '#ffffff' : '#000000', fontSize: 16, marginLeft: 13, marginTop: 1.5 }}>{channel_properties.total_subs === 0 ? '0 Subscribers' : channel_properties.total_subs === 1 ? '1 Subscriber' : `${channel_properties.total_subs} Subscribers`}</Text>
                        </View>
                    </BottomSheetView>

                    <View style={authScreens.btn_container}>
                        <Button loading={join_channel_loading} onPress={join_channel} title={is_user_logged_in === true ? "Join Channel" : "Login To Join"} titleStyle={authScreens.btn_font} containerStyle={{ width: '100%' }} buttonStyle={authScreens.btn} />
                    </View>
                </BottomSheetView>
            </BottomSheetView>
        </BottomSheet>
    );
};