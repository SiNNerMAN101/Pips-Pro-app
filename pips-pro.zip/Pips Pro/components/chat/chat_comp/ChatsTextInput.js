import { Ionicons } from '@expo/vector-icons';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { TextInput, View, TouchableOpacity } from 'react-native';
import { set_send_msg_btn_state } from '../../../state/chat';
import { detect_typing } from '../../../reusable_methods/chat/detect_typing';
import { send_chat } from '../../../reusable_methods/chat/send_chat';

export function ChatsTextInput({ getSocket }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [text, onChangeText] = useState('');
    const send_msg_btn_state = useSelector((state) => state.chat.send_msg_btn_state); // Send message btn visibility
    const dispatch = useDispatch();

    useEffect(() => {
        const exec = async () => {
            try {
                await detect_typing(text);
            } catch (err) {
                dispatch(set_send_msg_btn_state({ value: false }));
            }
        };
        exec();
    }, [text]);

    return (
        <View style={{ backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', padding: 0, paddingBottom: 0, flexDirection: 'row', alignItems: 'center', borderTopColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd', borderTopWidth: 0.5 }}>
            <TouchableOpacity style={{ margin: 12, marginRight: 10, marginLeft: 17 }}>
                <Ionicons name="image-outline" size={28} color={is_darkmode === true ? '#ffffff' : '#000000'} />
            </TouchableOpacity>
            
            <TextInput
                style={{ minHeight: 40, fontFamily: 'RobotoRegular', maxHeight: 92.5, margin: 12, textAlign: 'left', paddingVertical: 0, paddingTop: 8, paddingBottom: 8, alignItems: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', marginRight: send_msg_btn_state === false ? 17 : 2, marginLeft: 2, flex: 1, borderWidth: 1.5, fontSize: 16, borderColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd', borderRadius: 20, padding: 10 }}
                onChangeText={onChangeText}
                value={text}
                multiline
                placeholder="Message"
                placeholderTextColor={is_darkmode === true ? '#5b5b5b' : '#6f6f6f' }
                keyboardType="default"
                keyboardAppearance={is_darkmode === true ? 'dark' : 'light'}
                textAlignVertical="center"
                maxLength={65536}
            />

            {
                send_msg_btn_state === true ?
                    <TouchableOpacity onPress={() => send_chat(getSocket, text, onChangeText, 1)} style={{ margin: 12, marginRight: 17, marginLeft: 10 }}>
                        <Ionicons name="send-outline" size={28} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                : <></>
            }
        </View>
    );
};