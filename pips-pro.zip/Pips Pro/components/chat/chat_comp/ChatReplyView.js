import React, { useMemo } from 'react';
import { useSelector } from 'react-redux';
import { chat_bubble } from '../../../styles/chat_styles/chat_bubble';
import { LoadChatImageReplyType2 } from '../LoadChatImageReplyType2';
import { View, Text } from 'react-native';
import Feather from '@expo/vector-icons/Feather';

export function ChatReplyView({ message }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const user_details = useSelector((state) => state.login_state.user_details); // User details
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties
    const chat_bubble_styles = useMemo(() => chat_bubble(message, is_darkmode, user_details, channel_properties), [message, is_darkmode, user_details, channel_properties]); // Memoize styles using useMemo

    return (
        <>
            { /* For handling cases where there is a reply to a chat */ }
            {
                message.reply_available === true ?
                    <>
                        {
                            // Check if the chat being replied to exists or has been deleted
                            message.reply_data.chat_type !== null ?
                                <View style={[{ borderLeftColor: message.reply_data.color_code }, chat_bubble_styles.reply_view]}>
                                    <View style={chat_bubble_styles.inner_reply_view}>
                                        <Text style={[{ color: message.reply_data.color_code }, chat_bubble_styles.reply_username]}>{user_details.user_id === message.reply_data.user_id ? 'You' : message.reply_data.username}</Text>
                                        {
                                            message.reply_data.chat_type === 1 ? // Plain text chat
                                                <Text numberOfLines={1} style={chat_bubble_styles.reply_chat}>{message.reply_data.chat}</Text>
                                            : message.reply_data.chat_type === 2 ? // Trade idea chat
                                                <LoadChatImageReplyType2 img_url={message.reply_data.chat_image} />
                                            : <></>
                                        }
                                    </View>
                                </View>
                            :   <View style={[{ borderLeftColor: '#fffff' }, chat_bubble_styles.reply_view]}>
                                    <View style={chat_bubble_styles.reply_view_for_deleted_chat}>
                                        <Feather name="trash-2" size={17} color={is_darkmode === true ? '#b9b9b9' : '#747474'} />
                                        <Text numberOfLines={1} style={chat_bubble_styles.reply_chat2}>Deleted</Text>
                                    </View>
                                </View>
                        }
                    </>
                : <></>
            }
        </>
    );
};