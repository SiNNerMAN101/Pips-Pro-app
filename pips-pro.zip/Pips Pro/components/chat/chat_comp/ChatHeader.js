import React, { useMemo } from 'react';
import { LoadChatProfileImage } from '../LoadChatProfileImage';
import { Avatar } from '@rneui/themed';
import { useSelector } from 'react-redux';
import { chat_bubble } from '../../../styles/chat_styles/chat_bubble';

export function ChatHeader({ message }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const user_details = useSelector((state) => state.login_state.user_details); // User details
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties

    const chat_bubble_styles = useMemo(() => chat_bubble(message, is_darkmode, user_details, channel_properties), [message, is_darkmode, user_details, channel_properties]); // Memoize styles using useMemo

    return (
        <>
            { 
                message.profile_image === null ? 
                    <Avatar
                        size={43}
                        rounded
                        titleStyle={chat_bubble_styles.avatar_title}
                        title={message.username.charAt(0)}
                        containerStyle={chat_bubble_styles.user_avatar}
                    />
                : <LoadChatProfileImage img_url={message.profile_image} channel_name={message.username} color_code={message.color_code} /> 
            }
        </>
    );
};