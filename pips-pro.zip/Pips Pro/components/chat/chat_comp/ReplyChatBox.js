import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useDispatch, useSelector } from 'react-redux';
import { LoadChatImageReplyType } from '../LoadChatImageReplyType';
import { modify_reply_data } from '../../../state/chat';

export function ReplyChatBox({ }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const user_details = useSelector((state) => state.login_state.user_details); // User details
    const reply_data = useSelector((state) => state.chat.reply_data); // The data properties for the reply
    const dispatch = useDispatch();

    // Close the reply chat box
    const close_reply_chat_box = () => {
        let data = { chat: '', chat_id: 0, chat_type: 1, color_code: '#FFFFFF', user_id: 0, username: '' };
        dispatch(modify_reply_data({ data: data, value: false, id: 0 }));
    }

    return (
        <View style={{ flexDirection: 'row', height: 62, borderLeftColor: reply_data.color_code, borderLeftWidth: 3, borderTopColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd', borderTopWidth: 0.5 }}>
            <View style={{ flex: 1, justifyContent: 'space-between', flexDirection: 'row', paddingLeft: 0, paddingRight: 10, padding: 6 }}>
                <View style={{ paddingLeft: 10, justifyContent: 'space-around' }}>
                    <Text style={{ color: reply_data.color_code, fontFamily: 'RobotoBold', fontSize: 15.3, marginBottom: 2 }}>{reply_data.user_id === user_details.user_id ? 'You' : reply_data.username}</Text>
                    
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 3 }}>
                        {
                            reply_data.chat_type === 1 ? // Plain text chat
                                <Text numberOfLines={1} style={{ color: '#ffffff', fontFamily: 'RobotoRegular', color: is_darkmode === true ? '#ffffff' : '#000000', fontSize: 15 }}>{reply_data.chat}</Text>
                            : reply_data.chat_type === 2 ? // Trade idea chat
                                <>
                                    <FontAwesome name="camera" size={18} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                                    <Text style={{ color: is_darkmode === true ? '#ffffff' : '#000000', marginLeft: 7, fontFamily: 'RobotoRegular', fontSize: 15.3 }}>Trade Idea</Text>
                                </>
                            : <></>
                        }
                    </View>
                </View>

                {
                    reply_data.chat_type === 1 ?
                        <></>
                    : reply_data.chat_type === 2 ?
                        <LoadChatImageReplyType img_url={reply_data.chat_image} />
                    : <></>
                }
            </View>
            <TouchableOpacity onPress={close_reply_chat_box} style={{ justifyContent: 'center', paddingRight: 10 }}>
                <Ionicons name="close-circle-outline" size={28} color={is_darkmode === true ? '#ffffff' : '#000000'} />
            </TouchableOpacity>
        </View>
    );
};