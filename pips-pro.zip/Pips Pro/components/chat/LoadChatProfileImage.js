import { View } from 'react-native';
import { useState } from "react";
import { Avatar } from '@rneui/themed';
import { Image } from 'expo-image';

// Loading placeholder for the profile images for each chat
export function LoadChatProfileImage({ img_url, username, color_code }) {
    const [loading, setLoading] = useState(true);

    const onLoadEnd = () => {
        setLoading(false);
    };

    const LoadingImagePlaceholder = () => (
        <Avatar
            size={43}
            rounded
            titleStyle={{ color: '#ffffff' }}
            title={username.charAt(0)}
            containerStyle={{ backgroundColor: color_code }}
        /> 
    );

    return (
        <View style={{ width: 43, height: 43 }}>
            {loading && <LoadingImagePlaceholder />}
            <Image
                onLoad={onLoadEnd}
                style={[
                    { width: 43, height: 43, borderRadius: 50 },
                    loading && { position: 'absolute' }, // Hide image while loading
                ]}
                source={img_url}
                contentFit="cover"
            />
        </View>
    );
}