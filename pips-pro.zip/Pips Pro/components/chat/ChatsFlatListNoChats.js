import { View, Text, ScrollView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { AntDesign } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';
import { update_channel_chats_seen_state } from '../../state/channels';
import { set_in_chats_screen } from '../../state/chat';

export function ChatsFlatListNoChats({  }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties state
    const dispatch = useDispatch();

    useFocusEffect(
        useCallback(() => {
            dispatch(update_channel_chats_seen_state({ channel_id: channel_properties.channel_id })); // Mark the chats for this channel as seen by the user
            dispatch(set_in_chats_screen({ value: true }));

            return () => {

            }
        }, [])
    )

    return (
        <ScrollView
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30, backgroundColor: is_darkmode === true ? '#131722' : '#f1f1f1' }}
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <AntDesign name="inbox" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />   
                <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>No chats here yet</Text>
            </View>
        </ScrollView>
    );
}