import { Image } from 'expo-image';

// Loading placeholder for chat type 2 and chat type 3 chat images
export function LoadChatImageType({ img_url }) {
    const blurhash = '|rF?hV%2WCj[ayj[a|j[az_NaeWBj@ayfRayfQfQM{M|azj[azf6fQfQfQIpWXofj[ayj[j[fQayWCoeoeaya}j[ayfQa{oLj?j[WVj[ayayj[fQoff7azayj[ayj[j[ayofayayayj[fQj[ayayj[ayfjj[j[ayjuayj[';

    return (
        <Image
            placeholder={{ blurhash }}
            style={{ width: 50, height: '100%', borderRadius: 8 }}
            source={img_url}
            contentFit="cover"
        />
    );
}