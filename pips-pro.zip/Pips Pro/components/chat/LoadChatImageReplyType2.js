import { Image } from 'expo-image';

// Loading placeholder for chat type 2 and chat type 3 chat images
export function LoadChatImageReplyType2({ img_url }) {
    const blurhash = '|rF?hV%2WCj[ayj[a|j[az_NaeWBj@ayfRayfQfQM{M|azj[azf6fQfQfQIpWXofj[ayj[j[fQayWCoeoeaya}j[ayfQa{oLj?j[WVj[ayayj[fQoff7azayj[ayj[j[ayofayayayj[fQj[ayayj[ayfjj[j[ayjuayj[';

    return (
        <Image
            placeholder={{ blurhash }}
            style={{ width: '100%', marginTop: 8, height: 150, borderRadius: 8 }}
            source={img_url}
            contentFit="cover"
        />
    );
}