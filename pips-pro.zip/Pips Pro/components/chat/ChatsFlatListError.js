import { View, Text, ScrollView, RefreshControl } from 'react-native';
import { useSelector } from 'react-redux';
import { MaterialIcons } from '@expo/vector-icons';
import { useCallback } from 'react';
import { refresh_chats } from '../../reusable_methods/chat/refresh_chats';

export function ChatsFlatListError({ chat_state, refreshing, setRefreshing, refresh_controller, connectSocket, flatListRef }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    // Listen to pull to refresh event
    const onRefresh = useCallback(async () => {
        await refresh_chats(refresh_controller, setRefreshing, connectSocket, flatListRef);
    }, []);

    return (
        <ScrollView
            contentContainerStyle={{ justifyContent: 'center', alignItems: 'center' }}
            style={{ flex: 1, padding: 20, paddingVertical: 30, backgroundColor: is_darkmode === true ? '#131722' : '#f1f1f1' }}
            refreshControl={
                <RefreshControl
                    tintColor={is_darkmode ? '#ffffff' : '#000000'} // color of the spinner
                    colors={['#000000']} // Android-specific spinner color
                    refreshing={refreshing}
                    onRefresh={onRefresh}
                />
            }
        >
            <View style={{ flexDirection: 'column', marginTop: 20, alignItems: 'center' }}>
                <MaterialIcons name="report-gmailerrorred" size={105} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                {
                    chat_state === false ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>An error just occured</Text>
                    : chat_state === 'channel_unavailable' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>This channel is no longer available</Text>
                    : chat_state === 'join_private_channel' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>This is a private channel. Join to see chats</Text>
                    : chat_state === 'no_access_to_private_channel' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>Login to access this private channel</Text>
                    : chat_state === 'initial_payment_incomplete' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>You will gain access to the chats once your payment has been verified</Text>
                    : chat_state === 'non_channel_member' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>You are no longer a member of this channel</Text>
                    : chat_state === 'subscription_pending' ?
                        <Text style={{ marginTop: 15, textAlign: 'center', color: is_darkmode === true ? '#ffffff' : '#000000', fontFamily: 'RobotoBold', fontSize: 18.5 }}>Your subscription to this channel is yet to be renewed, please do so</Text>
                    : <></>
                }
            </View>
        </ScrollView>
    );
}