import React, { useCallback, useMemo, useState } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { useSelector } from 'react-redux';
import { chat_bubble } from '../../styles/chat_styles/chat_bubble';
import { LoadChatImageUpload } from './LoadChatImageUpload';
import { ChatHeader } from './chat_comp/ChatHeader';
import { ChatReplyView } from './chat_comp/ChatReplyView';
import { menu_sheet } from '../../reusable_methods/chat/menu_sheet';
import { useActionSheet } from '@expo/react-native-action-sheet';
import { Feather } from '@expo/vector-icons';
import { Text } from 'react-native-paper';

export function ChatBubble({ message, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const user_details = useSelector((state) => state.login_state.user_details); // User details
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties
    const { showActionSheetWithOptions } = useActionSheet();
    const [textShown, setTextShown] = useState(false); // To show the remaining Text
    const [lengthMore, setLengthMore] = useState(false); // To show the "Read more & Less Line"

    // To toggle the show text or hide it
    const toggleNumberOfLines = () => {
        setTextShown(!textShown);
    }

    const onTextLayout = useCallback(e =>{
        setLengthMore(e.nativeEvent.lines.length >= 4); // To check the text is more than 4 lines or not
        // console.log(e.nativeEvent);
    },[]);

    const chat_bubble_styles = useMemo(() => chat_bubble(message, is_darkmode, user_details, channel_properties), [message, is_darkmode, user_details, channel_properties]); // Memoize styles using useMemo    

    return (
        <TouchableOpacity onLongPress={() => menu_sheet(message, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket)} delayLongPress={200} style={chat_bubble_styles.touch_bubble}>
            <ChatHeader message={message} />

            <View style={chat_bubble_styles.user_data}>
                <Text style={chat_bubble_styles.username}>{user_details.user_id === message.user_id ? 'You' : message.username}</Text>
                
                {
                    channel_properties['creator_id'] === message.user_id ?
                        <Text style={chat_bubble_styles.admin_txt}>Admin</Text>
                    : <></>
                }

                { /* For handling cases where there is a reply to a chat */ }
                <ChatReplyView message={message} />
                
                { /* Type of chat Eg: 1 => Plain text chat and 2 => Trade idea chat */ }
                {
                    message.chat_type === 1 ? 
                        <View style={chat_bubble_styles.chat_view}>
                            <Text onTextLayout={onTextLayout} numberOfLines={textShown ? undefined : 4} style={chat_bubble_styles.chat_txt}>{message.chat}</Text>
                        </View>
                    : message.chat_type === 2 ?
                        <View style={[chat_bubble_styles.chat_view, chat_bubble_styles.img_container]}>
                            <LoadChatImageUpload img_url={message.chat_image} />
                            <Text onTextLayout={onTextLayout} numberOfLines={textShown ? undefined : 4} style={[chat_bubble_styles.chat_txt, chat_bubble_styles.text_under_image]}>{message.chat}</Text>
                        </View>
                    : <></>
                }

                {
                    lengthMore ? 
                        <TouchableOpacity onPress={toggleNumberOfLines}>
                            <Text style={chat_bubble_styles.more_txt_button}>
                                {textShown ? 'Read less' : 'Read more'}
                            </Text>
                        </TouchableOpacity>
                    : null
                }
            </View>

            <View style={chat_bubble_styles.time_view}>
                <Text style={chat_bubble_styles.chat_datetime}>{message.formatted_date}</Text>
                <>
                    {
                        message.user_id === user_details.user_id ?
                            <>
                                {
                                    message.sent_msg === true ?
                                        <Feather style={chat_bubble_styles.clock_ticker} name="check-circle" size={17} color={is_darkmode === true ? '#b9b9b9' : '#747474'} />
                                    : <Feather style={chat_bubble_styles.clock_ticker} name="clock" size={17} color={is_darkmode === true ? '#b9b9b9' : '#747474'} />
                                }
                            </>
                        : <></>
                    }
                </>
            </View>
        </TouchableOpacity>
    );
};