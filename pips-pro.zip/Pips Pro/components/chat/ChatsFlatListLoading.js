import { Skeleton } from '@rneui/themed';
import { View, FlatList } from 'react-native';
import { useSelector } from 'react-redux';

export function ChatsFlatListLoading({  }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    return (
        <FlatList 
            scrollEnabled={false}
            style={{ backgroundColor: is_darkmode === true ? '#131722' : '#f1f1f1', padding: 20, flex: 1 }}
            showsHorizontalScrollIndicator={false}
            inverted={true}
            initialNumToRender={1}
            maxToRenderPerBatch={1}
            windowSize={1}
            data={Array.from({length: 10}, (_, i) => i + 1)}
            renderItem={({ item }) => (
                <View style={{ padding: 16, flex: 1, marginHorizontal: 14, paddingHorizontal: 0, flexDirection: 'row', alignItems: 'flex-start', marginVertical: 0, borderRadius: 10 }}>
                    <Skeleton animation='wave' width={43} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', borderRadius: 6 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={43} />   

                    <View style={{ flex: 1, marginLeft: 14.5 }}>
                        <Skeleton animation='wave' width='50%' style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginLeft: 13 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={14.5} />
                        <Skeleton animation='wave' width='80%' style={{ marginTop: 13.5, backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginLeft: 13 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                        <Skeleton animation='wave' width='76%' style={{ marginTop: 5, backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginLeft: 13 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                        <Skeleton animation='wave' width='68%' style={{ marginTop: 5, backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginLeft: 13 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={13} />
                    </View>

                    <View style={{ marginLeft: 5 }}>
                        <Skeleton animation='wave' width={40} style={{ backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', marginLeft: 13 }} skeletonStyle={{ backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' }} height={10} />
                    </View>
                </View>
            )}
        />
    );
}