import { KeyboardAvoidingView, Platform } from 'react-native';
import { useSelector } from 'react-redux';
import { ChatBottomSheet } from './chat_comp/ChatsBottomSheet';
import { ChatsTextInput } from './chat_comp/ChatsTextInput';
import { ReplyChatBox } from './chat_comp/ReplyChatBox';

export function BottomComponents({ navigation, controller, flatListRef, connectSocket, getSocket, bottomSheetRef, handleSheetChanges, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err }) {
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties
    const chat_state = useSelector((state) => state.chat.chat_state); // Chat state
    const reply_chat = useSelector((state) => state.chat.reply_chat); // Toggle the visibility of the reply chat box

    return (
        <>
            {
                chat_state === true || chat_state === 'no_chats' ?
                    <>
                        {
                            channel_properties.joined === true ?
                                <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 93 : 0}>
                                    {
                                        reply_chat === true ?
                                            <ReplyChatBox />
                                        : <></>
                                    }
                                    <ChatsTextInput getSocket={getSocket} />
                                </KeyboardAvoidingView>
                            :   <ChatBottomSheet bottomSheetRef={bottomSheetRef} navigation={navigation} controller={controller} flatListRef={flatListRef} connectSocket={connectSocket} getSocket={getSocket} handleSheetChanges={handleSheetChanges} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} />
                        }
                    </>
                : <></>
            }
        </>
    );
}