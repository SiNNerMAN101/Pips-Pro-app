import React, { useCallback, useMemo, useState } from 'react';
import { View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ChatBubble } from './ChatBubble';
import { ActivityIndicator } from 'react-native';
import { load_more_chats } from '../../reusable_methods/chat/load_more_chats';
import { FlashList } from "@shopify/flash-list";
import { useFocusEffect } from '@react-navigation/native';
import { update_channel_chats_seen_state } from '../../state/channels';
import { set_in_chats_screen } from '../../state/chat';

export function ChatsFlatList({ flatListRef, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket, fetch_recent_chats, set_fetch_recent_chats, load_recent_chats_controller, handleScroll, handleScrollEnd }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const messages = useSelector((state) => state.chat.messages); // Messages/Chats
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties state
    const [load_comp, set_load_comp] = useState(false); // The state of the loading component
    const dispatch = useDispatch();

    useFocusEffect(
        useCallback(() => {
            dispatch(update_channel_chats_seen_state({ channel_id: channel_properties.channel_id })); // Mark the chats for this channel as seen by the user
            dispatch(set_in_chats_screen({ value: true }));

            return () => {

            }
        }, [])
    )

    // Try to load more recent/older chats as the user reached the top of the flatlist
    const handleReachedTop = async () => {
        if (load_comp !== 'complete'){
            set_load_comp(true);
            await load_more_chats(load_recent_chats_controller, fetch_recent_chats, set_fetch_recent_chats, set_load_comp)
        }
    };

    const MemoizedChatBubble = React.memo(ChatBubble);

    const renderItem = ({ item }) => {
        return (
            <MemoizedChatBubble message={item} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} set_delete_chat_loading_dialog={set_delete_chat_loading_dialog} delete_chat_controller={delete_chat_controller} getSocket={getSocket} />
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [is_darkmode]);

    return (
        <>
            <View style={{ flex: 1, backgroundColor: is_darkmode === true ? '#131722' : '#f1f1f1' }}>
                <FlashList
                    ref={flatListRef}
                    ListFooterComponent={
                        load_comp === true ? (
                            <View style={{ padding: 10 }}>
                                <ActivityIndicator size="small" />
                            </View>
                        ) : null
                    }
                    showsHorizontalScrollIndicator={false}
                    indicatorStyle={is_darkmode === true ? 'white' : 'black'}
                    onEndReached={handleReachedTop}
                    onEndReachedThreshold={0.5} // Adjust threshold as necessary
                    data={messages}
                    estimatedItemSize={130}
                    inverted={true}
                    onScroll={handleScroll}
                    onScrollEndDrag={handleScrollEnd}
                    onMomentumScrollEnd={handleScrollEnd}
                    scrollEventThrottle={16}
                    keyExtractor={(item) => item.id.toString()}
                    renderItem={memoizedRenderItem}
                />
            </View>
        </>
    );
}