import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useSelector } from 'react-redux';
import { postContentStyles } from "../../styles/community/post_content_styles";
import { useMemo } from "react";
import { LoadTradeIdeaImage } from "../user_profile/LoadTradeIdeaImage";
import { MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import { Avatar } from "@rneui/themed";
import { UserProfileImageLoad } from "../menu/UserProfileImageLoad";
import HTMLView from 'react-native-htmlview';
import { htmlViewStyles } from "../../styles/community/html_view_styles";
import { Image } from "expo-image";
import EmojiMenu from "./EmojiMenu";

export default function PostContent({ navigation, item, index }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const user_details = useSelector((state) => state.login_state.user_details); // User current account details

    // Memoize the styles to avoid recalculating them on each render
    const post_content_styles = useMemo(() => postContentStyles(is_darkmode), [is_darkmode]);
    const html_view_styles = useMemo(() => htmlViewStyles(is_darkmode), [is_darkmode]);

    return (
        <View style={post_content_styles.post_item}>
            <View>
                <View style={post_content_styles.post_header}>
                    { 
                        item.profile_image === null || item.profile_image === undefined ? 
                            <Avatar
                                size={44}
                                rounded
                                titleStyle={{ color: '#ffffff' }}
                                title={item.fullname.charAt(0)}
                                containerStyle={{ backgroundColor: user_details.color_code, borderRadius: 100 }}
                            />
                        : <UserProfileImageLoad img_url={item.profile_image} user_name={item.fullname} color_code={item.color_code} size={44} /> 
                    }

                    <View style={post_content_styles.post_header_info_view}>
                        <View style={post_content_styles.post_header_info}>
                            <Text style={post_content_styles.post_header_fullname}>{item.fullname}</Text>
                            <MaterialIcons name="verified" style={{ marginLeft: 4.5 }} size={16} color="#f19220" />
                            <Text style={post_content_styles.post_header_dot_seperator}>·</Text>
                            <Text style={post_content_styles.post_header_timestamp}>{item.timestamp}</Text>
                        </View>

                        <Text style={post_content_styles.post_header_username}>@{item.username}</Text>
                    </View>
                </View>
            </View>

            <HTMLView
                value={item.post_desc}
                stylesheet={html_view_styles}
            />

            {
                item.attachments.length > 0 ?
                    <View style={{ marginTop: 13 }}>
                        {
                            item.attachments[0].media_type === 'image' ?
                                <LoadTradeIdeaImage img_url={item.attachments[0].url} />
                            : <></>
                        }
                    </View>
                : null
            }

            {
                item.reactions.length > 0 ?
                    <ScrollView showsHorizontalScrollIndicator={false} style={post_content_styles.interactive_icons_view} horizontal={true}>
                        {item.reactions.map((reaction, index) => (
                            <TouchableOpacity style={[post_content_styles.interactive_icon_btn, { marginLeft: index > 0 ? 8 : 0 }]} key={index}>
                                <Image
                                    style={{ width: 23, height: 23 }}
                                    source={reaction['reaction_id'] === 1 ? require('../../assets/community/posts/interactive_icons/heart.png') : reaction['reaction_id'] === 2 ? require('../../assets/community/posts/interactive_icons/heat.png') : reaction['reaction_id'] === 3 ? require('../../assets/community/posts/interactive_icons/trend-up.png') : reaction['reaction_id'] === 4 ? require('../../assets/community/posts/interactive_icons/trend-down.png') : reaction['reaction_id'] === 5 ? require('../../assets/community/posts/interactive_icons/thumbs-up.png') : null}
                                    contentFit="cover"
                                    allowDownscaling={false}
                                    transition={1000}
                                />
                                <Text style={post_content_styles.interactive_icon_total}>{reaction.total}</Text>
                            </TouchableOpacity>
                        ))}
                    </ScrollView>
                : null
            }

            <View style={post_content_styles.post_data}>
                <TouchableOpacity style={post_content_styles.post_interaction_btn}>
                    <MaterialCommunityIcons name="eye-outline" size={22} color={is_darkmode === true ? "#71767b" : "#000000"} />
                    <Text style={post_content_styles.interaction_values}>{item.total_views}</Text>
                </TouchableOpacity>

                <TouchableOpacity style={post_content_styles.post_interaction_btn}>
                    <MaterialCommunityIcons name="comment-text-outline" size={22} color={is_darkmode === true ? "#71767b" : "#000000"} />
                    <Text style={post_content_styles.interaction_values}>{item.total_comments}</Text>
                </TouchableOpacity>

                <TouchableOpacity style={post_content_styles.post_interaction_btn}>
                    <MaterialCommunityIcons name="repeat" size={22} color={is_darkmode === true ? "#71767b" : "#000000"} />
                    <Text style={post_content_styles.interaction_values}>{item.total_reposts}</Text>
                </TouchableOpacity>

                <EmojiMenu item={item} index={index} />

                <TouchableOpacity style={post_content_styles.post_interaction_btn}>
                    <MaterialCommunityIcons name="dots-horizontal" size={22} color={is_darkmode === true ? "#71767b" : "#000000"} />
                </TouchableOpacity>
            </View>
        </View>
    );
}