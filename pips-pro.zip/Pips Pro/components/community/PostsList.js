import { FlatList } from "react-native";
import { useSelector } from 'react-redux';
import { useMemo } from "react";
import PostContent from "./PostContent";

export default function PostsList({ navigation, section }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const for_you_section = useSelector((state) => state.community.for_you_section); // The list of posts recommended for the user
    const following_section = useSelector((state) => state.community.following_section); // The list of posts from other users that the user is following
    const stock_section = useSelector((state) => state.community.stock_section); // The list of posts that are based off of anything stock
    const forex_section = useSelector((state) => state.community.forex_section); // The list of posts that are based off of anything forex
    const crypto_section = useSelector((state) => state.community.crypto_section); // The list of posts that are based off of anything crypto

    const renderItem = ({ item, index }) => {
        return (
            <PostContent navigation={navigation} item={item} index={index} />
        );
    };

    // Memoize the renderItem function to avoid re-creating it on each render
    const memoizedRenderItem = useMemo(() => renderItem, [is_darkmode]);

    return (
        <FlatList
            data={section === 1 ? for_you_section : section === 2 ? following_section : section === 3 ? stock_section : section === 4 ? forex_section : crypto_section}
            showsVerticalScrollIndicator={false}
            style={{ flex: 1, paddingTop: 20 }}
            initialNumToRender={10}
            maxToRenderPerBatch={10}
            windowSize={5}
            renderItem={memoizedRenderItem}
            keyExtractor={(item) => item.id.toString()}
        />
    );
}