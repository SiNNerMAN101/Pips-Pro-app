// SimpleMenu.js
import { Pressable, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React, { useMemo, useRef, useState } from "react";
import { Menu, MenuOption, MenuOptions, MenuProvider, MenuTrigger } from "react-native-popup-menu";
import { MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import { postContentStyles } from "../../styles/community/post_content_styles";
import { useSelector } from "react-redux";
import { Image } from "expo-image";

const EmojiMenu = ({ item, index }) => {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const [opended, set_opended] = useState(false);

    const closeMenu = () => {
        console.log(index)
        set_opended(true);
    };

    // Memoize the styles to avoid recalculating them on each render
    const post_content_styles = useMemo(() => postContentStyles(is_darkmode), [is_darkmode]);

    return (
        <Menu onBackdropPress={() => set_opended(false)} opened={opended}>
            <MenuTrigger onPress={() => console.log('pressed!')} onAlternativeAction={() => closeMenu()}>
                <View style={post_content_styles.post_interaction_btn}>
                    <MaterialCommunityIcons name="emoticon-happy-outline" size={22} color={is_darkmode === true ? "#71767b" : "#000000"} />
                    <Text style={post_content_styles.interaction_values}>{item.total_reactions}</Text>
                </View>
            </MenuTrigger>
            <MenuOptions 
                customStyles={{
                    optionsContainer: {
                        backgroundColor: '#2a2929',
                        marginTop: -60,
                        flex: 1,
                        height: 50,
                        borderRadius: 10,
                        justifyContent: 'center',
                        alignItems: 'center',
                        // iOS shadow properties
                        shadowColor: '#000',
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                        shadowOpacity: 0.25,
                        shadowRadius: 4,
                        // Android elevation
                        elevation: 5,
                    },
                }}
            >
                <View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Image
                            style={{ width: 25, height: 25 }}
                            source={require('../../assets/community/posts/interactive_icons/heart.png')}
                            contentFit="cover"
                            allowDownscaling={false}
                            transition={1000}
                        />
                        <Image
                            style={{ width: 25, marginLeft: 13, height: 25 }}
                            source={require('../../assets/community/posts/interactive_icons/heat.png')}
                            contentFit="cover"
                            allowDownscaling={false}
                            transition={1000}
                        />
                        <Image
                            style={{ width: 25, marginLeft: 13, height: 25 }}
                            source={require('../../assets/community/posts/interactive_icons/trend-up.png')}
                            contentFit="cover"
                            allowDownscaling={false}
                            transition={1000}
                        />
                        <Image
                            style={{ width: 25, marginLeft: 13, height: 25 }}
                            source={require('../../assets/community/posts/interactive_icons/trend-down.png')}
                            contentFit="cover"
                            allowDownscaling={false}
                            transition={1000}
                        />
                        <Image
                            style={{ width: 25, marginLeft: 13, height: 25 }}
                            source={require('../../assets/community/posts/interactive_icons/thumbs-up.png')}
                            contentFit="cover"
                            allowDownscaling={false}
                            transition={1000}
                        />
                    </View>
                </View>
            </MenuOptions>
        </Menu>
    );
};

export default EmojiMenu;

const styles = StyleSheet.create({
    
});