// Format the datetime stamp from each news article
export const format_datetime = (timestamp, source)  => {
    // Convert Unix timestamp to milliseconds
    const milliseconds = timestamp * 1000;

    // Create a new Date object
    const date = new Date(milliseconds);

    // Months array
    const months = [
        "January", "February", "March",
        "April", "May", "June", "July",
        "August", "September", "October",
        "November", "December"
    ];

    // Get hours and minutes
    const hours = ("0" + date.getHours()).slice(-2);
    const minutes = ("0" + date.getMinutes()).slice(-2);

    // Get month and day
    const month = months[date.getMonth()];
    const day = date.getDate();

    // Get current year
    const currentYear = new Date().getFullYear();
    
    // Check if the year is the current year
    const year = date.getFullYear() === currentYear ? '' : `, ${date.getFullYear()}`;

    // Format the date string
    const dateString = `${hours}:${minutes} · ${month} ${day}${year} · ${source}`;

    return dateString;
};