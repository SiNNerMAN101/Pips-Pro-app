import { store } from '../../store/store';
import { backend_api } from '../backend_api';
import { set_news_state } from '../../state/news';

// Fetch the latest market news
export const fetch_latest_news = async (news, set_news, controller, set_refreshing) => {
  await fetch(`${backend_api()}/api/user/fetch-latest-news`, {
    method: "GET",
    signal: controller.signal,
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then((res) => {
    return res.json();
  })
  .then(async (response) => {
    if (response.res_code === 404){
      set_news([]);
      store.dispatch(set_news_state({ value: false }));
      set_refreshing(false);
    } else if (response.res_code === 200){
      set_news(response.result);
      store.dispatch(set_news_state({ value: true }));
      set_refreshing(false);
    } else {
      set_news([]);
      store.dispatch(set_news_state({ value: false }));
      set_refreshing(false);
    }
  })
  .catch((err) => {
    if (err.name !== 'AbortError'){
      set_news([]);
      store.dispatch(set_news_state({ value: false }));
      set_refreshing(false);
    }
  })
};