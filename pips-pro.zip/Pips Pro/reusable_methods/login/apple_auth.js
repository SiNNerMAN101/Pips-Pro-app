import * as AppleAuthentication from 'expo-apple-authentication';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';
import { set_accessToken, set_logged_in, set_user_details } from '../../state/loginState';
import { set_all_watchlists_state, set_watchlist_state } from '../../state/watchListState';
import { reset_channels_state } from '../../state/channels';
import { reset_chat_data } from '../../state/chat';

// Authenticate the user using apple auth
export const apple_auth = async (loading_modal, set_loading_modal, navigation, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    try {
        const credential = await AppleAuthentication.signInAsync({
          requestedScopes: [
            AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
            AppleAuthentication.AppleAuthenticationScope.EMAIL,
          ],
        });

        set_loading_modal(true);
        
        let identityToken = credential.identityToken;

        set_snackbar_toggle(false);
        set_snackbar_err(false);
        set_snackbar_msg('');

        // Make request to the backend to authenticate the user
        await fetch(`${backend_api()}/api/user/apple-auth`, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                identityToken: identityToken
            })
        })
        .then((res) => {
            return res.json();
        })
        .then(async (response) => {
            if (response.res_code === 455){
                set_loading_modal(false);
                set_snackbar_msg(response.err_msg);
                set_snackbar_err(true);
                set_snackbar_toggle(true);
            } else if (response.res_code === 401 || response.res_code === 500){
                set_loading_modal(false);
                set_snackbar_msg('An error occured, please try again later');
                set_snackbar_err(true);
                set_snackbar_toggle(true);
            } else if (response.res_code === 200){
                await SecureStore.setItemAsync('auth_token', response.accessToken); // Store access token in secure store

                try {
                    const user_details = JSON.stringify(response.result);
                    await AsyncStorage.setItem('user_details', user_details); // Store the users details with async storage
                } catch (e) {
                    // saving error
                }

                // Store the users details in the redux store state
                store.dispatch(set_user_details({ details: response.result }));
                store.dispatch(set_accessToken({ token: response.accessToken }));
                store.dispatch(set_logged_in({ value: true }));
                store.dispatch(set_all_watchlists_state({ value: 'loading' }));
                store.dispatch(set_watchlist_state({ value: 'loading' }));
                store.dispatch(reset_channels_state({}));
                store.dispatch(reset_chat_data({}));
                navigation.navigate('WatchList');
            } else if (response.res_code === 250){
                // Navigate to the verify account screen where the user can input the verification code that they received in order to verify their account
                navigation.navigate('VerifyAccount', {
                    username: response.result.username,
                    email: response.result.email,
                    verify_account_token: response.accessToken,
                    user_id: response.result.user_id
                });
            }
        })
        .catch((err) => {
            set_loading_modal(false);
            if (err.name !== 'AbortError') {
                set_snackbar_msg('An error occured, please try again later');
                set_snackbar_err(true);
                set_snackbar_toggle(true);
            }
        })
    } catch (e) {
        set_loading_modal(false);
        set_snackbar_msg('');
        set_snackbar_err(false);
        set_snackbar_toggle(false);
    }
};