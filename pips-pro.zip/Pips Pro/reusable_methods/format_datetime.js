import { DateTime } from 'luxon';

// Format date and time
export const format_datetime = (utcString) => {
    // Parse the UTC string into a Luxon DateTime object
    const utcDateTime = DateTime.fromISO(utcString, { zone: 'utc' });

    // Get the current timezone
    const currentTimeZone = DateTime.now().zoneName;

    // Convert the DateTime object to the user's timezone
    const userDateTime = utcDateTime.setZone(currentTimeZone);

    // Get the current DateTime
    const currentDateTime = DateTime.local();

    // Calculate the difference between userDateTime and currentDateTime
    const diff = currentDateTime.diff(userDateTime, ['years', 'months', 'weeks', 'days', 'hours', 'minutes', 'seconds']);

    // Round up the difference to the nearest whole number
    const years = Math.ceil(diff.years || 0);
    const months = Math.ceil(diff.months || 0);
    const weeks = Math.ceil(diff.weeks || 0);
    const days = Math.ceil(diff.days || 0);
    const hours = Math.ceil(diff.hours || 0);
    const minutes = Math.ceil(diff.minutes || 0);
    const seconds = Math.ceil(diff.seconds || 0);

    // Format the difference into a relative time string
    if (years > 1) {
        return `${years} years ago`;
    } else if (years === 1) {
        return '1 year ago';
    } else if (months > 1) {
        return `${months} months ago`;
    } else if (months === 1) {
        return '1 month ago';
    } else if (weeks > 1) {
        return `${weeks} weeks ago`;
    } else if (weeks === 1) {
        return '1 week ago';
    } else if (days > 1) {
        return `${days} days ago`;
    } else if (days === 1) {
        return '1 day ago';
    } else if (hours > 1) {
        return `${hours} hours ago`;
    } else if (hours === 1) {
        return '1 hour ago';
    } else if (minutes > 1) {
        return `${minutes} mins ago`;
    } else if (minutes === 1) {
        return '1 min ago';
    } else if (seconds > 1) {
        return `${seconds} sec ago`;
    } else {
        return 'just now';
    }
};