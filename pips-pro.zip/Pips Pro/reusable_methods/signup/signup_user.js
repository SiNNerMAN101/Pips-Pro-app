import { backend_api } from '../backend_api';

// Register the user
export const signup_user = async (email, username, password, navigation, snackbar_toggle, snackbar_err, snackbar_msg, is_loading, set_is_loading, controller, set_controller, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
  set_snackbar_toggle(false);

  if (is_loading === false){
    set_is_loading(true);

    // Make request to the backend to authenticate the user
    await fetch(`${backend_api()}/api/user/signup`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        username: username,
        email: email,
        password: password
      })
    })
    .then((res) => {
      return res.json();
    })
    .then(async (response) => {
      set_is_loading(false);
      if (response.res_code === 455){
        set_snackbar_msg(response.err_msg);
        set_snackbar_err(true);
        set_snackbar_toggle(true);
      } else if (response.res_code === 401 || response.res_code === 500){
        set_snackbar_msg('An error occured, please try again later');
        set_snackbar_err(true);
        set_snackbar_toggle(true);
      } else if (response.res_code === 200){
        // Navigate to the verify account screen where the user can input the verification code that they received in order to verify their account
        navigation.navigate('VerifyAccount', {
          username: response.result.username,
          email: response.result.email,
          verify_account_token: response.accessToken,
          user_id: response.result.user_id
        });
      } else {
        set_snackbar_msg('An error occured, please try again later');
        set_snackbar_err(true);
        set_snackbar_toggle(true);
      }
    })
    .catch((err) => {
      set_is_loading(false);
      if (err.name !== 'AbortError') {
        set_snackbar_msg('An error occured, please try again later');
        set_snackbar_err(true);
        set_snackbar_toggle(true);
      }
    })
  }
};