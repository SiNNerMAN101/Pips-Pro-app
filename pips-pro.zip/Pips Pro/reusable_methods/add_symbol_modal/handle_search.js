import { store } from '../../store/store';
import { backend_api } from '../backend_api';

// Handle a situation where by the user types into the search bar in the add symbol modal
export const handle_search = async (setLoading, setSearchResults, searchQuery, accessToken, controller) => {
    setLoading(true);

    // Make request to the backend to search for symbols based on the users search term
    await fetch(`${backend_api()}/api/user/search-symbols`, {
        method: "POST",
        signal: controller.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${accessToken}`
        } : { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            symbol: searchQuery
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        if (response.res_code === 455 || response.res_code === 401 || response.res_code === 500 || response.res_code === 404){
            setLoading(true);
        } else if (response.res_code === 200){
            setSearchResults(response.result);
            setLoading(false);
        } else {
            setLoading(true);
        }
    })
    .catch((err) => {
        setLoading(true);
    })
};