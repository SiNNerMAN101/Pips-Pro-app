import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { set_channels_state, set_my_channels, set_refreshing, set_top_channels } from "../../state/channels";

// Refresh all the users channels and top channels
export const refresh_channels = async (refresh_controller, connectSocket, disconnectSocket) => {
    store.dispatch(set_refreshing({ value: true })); // Enable refresh spinner animation
    disconnectSocket(); // Disconnect the user from the websockets server

    // Make request to the backend to fetch all the users watchlists
    await fetch(`${backend_api()}/api/user/get-channels`, {
        method: "POST",
        signal: refresh_controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        } : { 'Content-Type': 'application/json' }
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        refresh_controller.current = new AbortController();

        store.dispatch(set_refreshing({ value: false })); // Disable refresh spinner animation

        if (response.res_code === 401 || response.res_code === 500 || response.res_code === 456){
            store.dispatch(set_channels_state({ value: false }));
        } else if (response.res_code === 200){
            let my_channels_array = response.result.my_channels; // Users channels
            let top_channels_array = response.result.top_channels; // Top channels

            store.dispatch(set_my_channels({ data: my_channels_array }));
            store.dispatch(set_top_channels({ data: top_channels_array }));

            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_channels_state({ value: true }));

                connectSocket(store.getState().login_state.accessToken); // Connect user to the websockets server
            } else {
                store.dispatch(set_channels_state({ value: 'not_logged_in' }));
            }
        } else {
            store.dispatch(set_channels_state({ value: false }));
        }
    })
    .catch((err) => {
        refresh_controller.current = new AbortController();

        store.dispatch(set_refreshing({ value: false })); // Disable refresh spinner animation

        if (err.name !== 'AbortError') {
            store.dispatch(set_channels_state({ value: false }));
        }
    })
};