import { remove_channel } from '../../state/channels';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';

// Exit the user from a particular channel that the user is currently a member of
export const exit_channel = async (channel, controller, getSocket, set_loading_dialog, set_loading_dialog_title, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    set_loading_dialog(true);
    set_loading_dialog_title('Exiting channel...');

    // Make request to the backend to exit the user from a particular channel that the user is currently a member of
    await fetch(`${backend_api()}/api/user/exit-channel`, {
        method: "POST",
        signal: controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        } : { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            channel_id: channel['channel_id']
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        set_loading_dialog(false);
        set_loading_dialog_title('Exiting channel...');

        if (response.res_code === 200){
            store.dispatch(remove_channel({ channel_id: response.result.channel_id, state: 'exit_channel' }));
            getSocket().emit('remove_user_from_channel_room', { channel_id: response.result.channel_id });
            set_snackbar_msg('Channel exited successfully');
            set_snackbar_err(false);
            set_snackbar_toggle(true);
        } else if (response.res_code === 401 || response.res_code === 455 || response.res_code === 500){
            set_snackbar_msg('An error just occured');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        } else if (response.res_code === 537){
            set_snackbar_msg('You have already being removed from this channel');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        } else if (response.res_code === 404){
            store.dispatch(remove_channel({ channel_id: channel['channel_id'], state: 'delete_channel' }));
            set_snackbar_msg('This channel is no longer available');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        } else {
            set_snackbar_msg('An error just occured');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        }
    })
    .catch((err) => {
        set_loading_dialog(false);
        set_loading_dialog_title('Exiting channel...');

        if (err.name !== 'AbortError') {
            set_snackbar_msg('An error just occured');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        }
    })
};