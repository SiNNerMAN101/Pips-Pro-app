import { store } from '../../store/store';
import { backend_api } from '../backend_api';
import { add_new_channel, set_channels_state, set_my_channels_state, set_new_channel_created, update_my_channels } from '../../state/channels';

// Create a new channel
export const create_channel = async (channel_name, channel_desc, channel_type, is_loading, set_is_loading, dropdown_error, set_dropdown_error, controller, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, set_editable, set_disable, navigation) => {
    if (channel_type === '1' || channel_type === '2'){
        if (is_loading === false){
            set_snackbar_err(false); set_snackbar_msg(''); set_snackbar_toggle(false);

            set_is_loading(true);
            set_disable(true);
            set_editable(false);

            let channel_name_x = channel_name.split('"').join('').replace(/^[ ]+|[ ]+$/g, '').trim();
            let channel_desc_x = channel_desc.split('"').join('').replace(/^[ ]+|[ ]+$/g, '').trim();
    
            // Make request to the backend to create a new channel
            await fetch(`${backend_api()}/api/user/create-new-channel`, {
                method: "POST",
                signal: controller.current.signal,
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization": `Bearer ${store.getState().login_state.accessToken}`
                },
                body: JSON.stringify({
                    channel_name: channel_name_x, 
                    channel_desc: channel_desc_x, 
                    channel_type: parseInt(channel_type)
                })
            })
            .then((res) => {
                return res.json();
            })
            .then(async (response) => {  
                set_is_loading(false);
                if (response.res_code === 455){
                    set_snackbar_msg(response.err_msg);
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                    set_disable(false);
                    set_editable(true);
                } else if (response.res_code === 401 || response.res_code === 500){
                    set_snackbar_msg('An error occured, please try again later');
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                    set_disable(false);
                    set_editable(true);
                } else if (response.res_code === 200){
                    store.dispatch(add_new_channel({ new_channel: response.result }));
                    store.dispatch(set_new_channel_created({ value: true }));
                    navigation.goBack();
                    set_snackbar_err(false); set_snackbar_msg(''); set_snackbar_toggle(false);
                    setTimeout(() => {
                        navigation.navigate('Chat', {
                            channel_id: response.result.channel_id,
                            joined: response.result.joined,
                            channel_name: response.result.channel_name,
                            channel_type: response.result.channel_type,
                            channel_image: response.result.channel_image,
                            creator_id: response.result.creator_id,
                            channel_uid: response.result.channel_uid,
                            type: response.result.type,
                            seen_chats: response.result.seen_chats,
                            recent_chat_msg: response.result.recent_chat_msg,
                            total_subs: response.result.total_subs
                        });
                    }, 300);
                }
            })
            .catch((err) => {
                if (err.name !== 'AbortError'){
                    set_is_loading(false);
                    set_snackbar_msg('An error occured, please try again later');
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                    set_disable(false);
                    set_editable(true);
                }
            })
        }
    } else {
        set_dropdown_error(true);
    }
};