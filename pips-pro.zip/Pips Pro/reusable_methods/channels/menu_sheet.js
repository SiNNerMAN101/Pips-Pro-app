import { store } from "../../store/store";
import { type_one } from "./menu_sheet_types/type_one";
import { type_two } from "./menu_sheet_types/type_two";

// The menu sheet
export const menu_sheet = (channel, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, getSocket, set_loading_dialog, set_loading_dialog_title, exit_channel_controller) => {
    if (store.getState().login_state.logged_in === true){
        let user_id = store.getState().login_state.user_details.user_id; // The users ID
            
        if (channel['creator_id'] === user_id){ // Check if the user is the creator of this particular channel 
            type_one(channel, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, getSocket, set_loading_dialog, set_loading_dialog_title, exit_channel_controller);
        } else {
            type_two(channel, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, getSocket, set_loading_dialog, set_loading_dialog_title, exit_channel_controller);
        }  
    }
};