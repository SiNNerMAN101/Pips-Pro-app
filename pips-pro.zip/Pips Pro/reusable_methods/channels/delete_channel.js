import { remove_channel } from '../../state/channels';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';

// Delete a particular channel that the user created
export const delete_channel = async (channel, controller, getSocket, set_loading_dialog, set_loading_dialog_title, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    set_loading_dialog(true);
    set_loading_dialog_title('Deleting channel...');

    // Make request to the backend to delete a particular channel that the user created
    await fetch(`${backend_api()}/api/user/delete-channel`, {
        method: "POST",
        signal: controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        } : { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            channel_id: channel['channel_id']
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        set_loading_dialog(false);
        set_loading_dialog_title('Deleting channel...');

        if (response.res_code === 200){
            store.dispatch(remove_channel({ channel_id: response.result.channel_id, state: 'delete_channel' }));
            getSocket().emit('remove_all_users_from_channel_room', { channel_id: response.result.channel_id });
            set_snackbar_msg('Channel deleted successfully');
            set_snackbar_err(false);
            set_snackbar_toggle(true);
        } else if (response.res_code === 401 || response.res_code === 455 || response.res_code === 500){
            set_snackbar_msg('An error just occured');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        } else if (response.res_code === 537){
            set_snackbar_msg('You cannot delete this channel');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        } else if (response.res_code === 404){
            set_snackbar_msg('This channel is no longer available');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        } else {
            set_snackbar_msg('An error just occured');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        }
    })
    .catch((err) => {
        set_loading_dialog(false);
        set_loading_dialog_title('Deleting channel...');

        if (err.name !== 'AbortError') {
            set_snackbar_msg('An error just occured');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        }
    })
};