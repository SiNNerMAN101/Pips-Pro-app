import { DateTime } from 'luxon';
import { set_channels_state, set_my_channels, set_my_channels_page, set_top_channels } from '../../state/channels';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';

// Get my channels and top channels
export const get_channels = async (connectSocket, getSocket, disconnectSocket, accessToken, controller) => {
    // Make request to the backend to get the users channels and top channels
    await fetch(`${backend_api()}/api/user/get-channels`, {
        method: "POST",
        signal: controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        } : { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            timezone: DateTime.now().zoneName
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        if (response.res_code === 401 || response.res_code === 500 || response.res_code === 456){
            store.dispatch(set_channels_state({ value: false }));
        } else if (response.res_code === 200){
            let my_channels_array = response.result.my_channels; // Users channels
            let top_channels_array = response.result.top_channels; // Top channels

            store.dispatch(set_my_channels({ data: my_channels_array }));
            store.dispatch(set_top_channels({ data: top_channels_array }));
            store.dispatch(set_my_channels_page({ value: response.result.my_channels_page }));

            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_channels_state({ value: true }));
                disconnectSocket(); // Disconnect from the websockets server if already connected
                connectSocket(accessToken); // Establish a new connection to the websockets server
            } else {
                store.dispatch(set_channels_state({ value: 'not_logged_in' }));
            }
        } else {
            store.dispatch(set_channels_state({ value: false }));
        }
    })
    .catch((err) => {
        console.log(err)
        if (err.name !== 'AbortError') {
            store.dispatch(set_channels_state({ value: false }));
        }
    })
};