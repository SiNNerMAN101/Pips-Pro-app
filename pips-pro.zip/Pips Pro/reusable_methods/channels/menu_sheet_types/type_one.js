import { store } from "../../../store/store";
import {ActionSheetIOS, Platform} from 'react-native';
import * as Haptics from 'expo-haptics';
import { delete_channel } from "../delete_channel";

// The menu sheet type one (These options will be displayed if the user is the creator of the channel)
export const type_one = (channel, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, getSocket, set_loading_dialog, set_loading_dialog_title, exit_channel_controller) => {
    // Trigger haptic feedback
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (Platform.OS === 'android'){
        const options = ['Delete channel', 'Cancel'];
        const destructiveButtonIndex = 1;
        const cancelButtonIndex = 1;
        const userInterfaceStyle = store.getState().login_state.darkmode === true ? "dark" : "light";
    
        showActionSheetWithOptions({
            options,
            cancelButtonIndex,
            destructiveButtonIndex,
            userInterfaceStyle
        }, async (selectedIndex) => {
          switch (selectedIndex) {
            case 0:
                // Delete
                await delete_channel(channel, exit_channel_controller, getSocket, set_loading_dialog, set_loading_dialog_title, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err);
                break;
            case destructiveButtonIndex:
                // Canceled
        }}); 
    } else if (Platform.OS === 'ios'){
        ActionSheetIOS.showActionSheetWithOptions(
            {
                options: ['Delete channel', 'Cancel'],
                destructiveButtonIndex: 1,
                cancelButtonIndex: 1,
                userInterfaceStyle: store.getState().login_state.darkmode === true ? "dark" : "light"
            },
            async buttonIndex => {
                if (buttonIndex === 0) {
                    // Delete
                    await delete_channel(channel, exit_channel_controller, getSocket, set_loading_dialog, set_loading_dialog_title, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err);
                } else if (buttonIndex === 1) {
                    // Cancel
                }
            },
        )
    }
};