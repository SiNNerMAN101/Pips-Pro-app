import { DateTime } from 'luxon';
import { set_page } from '../../state/chat';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';
import { load_more_user_channels, set_my_channels_page } from '../../state/channels';

// Load more of the users channels as the user scrolls to the bottom of the flatlist
export const load_more_channels = async (controller, fetch_more_channels, set_fetch_more_channels, set_load_comp) => {
    if (fetch_more_channels === true){
        set_fetch_more_channels(false);

        // Make request to the backend to load more of the users channels as the user scrolls to the bottom of the flatlist
        await fetch(`${backend_api()}/api/user/load-more-channels`, {
            method: "POST",
            signal: controller.current.signal,
            headers: store.getState().login_state.logged_in === true ? {
                'Content-Type': 'application/json',
                "Authorization": `Bearer ${store.getState().login_state.accessToken}`
            } : { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                timezone: DateTime.now().zoneName,
                page: store.getState().channels.my_channels_page
            })
        })
        .then((res) => {
            return res.json();
        })
        .then(async (response) => {
            if (response.res_code === 401 || response.res_code === 500 || response.res_code === 456){
                set_load_comp(true); // Keep displaying the loader
                set_fetch_more_channels(true); // Allow the user to continue fetching more channels
            } else if (response.res_code === 230){
                set_load_comp('complete'); // Disable the loader because there are no more channels to be fetched
                set_fetch_more_channels(false); // Don't allow the user to continue fetching more channels
            } else if (response.res_code === 200){
                set_load_comp(false); // Disable the loader
                set_fetch_more_channels(true); // Allow the user to continue fetching more channels

                store.dispatch(load_more_user_channels({ channels: response.result.my_channels })); // Display the channels that have been fetched
                store.dispatch(set_my_channels_page({ value: response.result.my_channels_page }));
            } else {
                set_load_comp(true); // Keep displaying the loader
                set_fetch_more_channels(true); // Allow the user to continue fetching more channels
            }
        })
        .catch((err) => {
            set_load_comp(true); // Keep displaying the loader
            set_fetch_more_channels(true); // Allow the user to continue fetching more channels
        })
    } else {
        set_load_comp(false);
    }
};