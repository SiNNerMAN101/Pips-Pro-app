import io from 'socket.io-client';
import { websocket_api } from '../websocket_api';
import { store } from '../../store/store';
import { deleted_chat_channel_update, mark_chats_as_seen_for_a_channel, update_a_channel_in_my_channels } from '../../state/channels';
import { update_deleted_chat } from '../../state/chat';

let socket;

export const connectSocket = (auth_token) => {
    if (!socket) {
        socket = io(websocket_api(2), {
            extraHeaders: {
                Authorization: `Bearer ${auth_token}`
            }
        })

        // Emit an event after the connection is established
        socket.on('connect', () => {
            // Trigger websocket server to start sending in market data
            socket.emit('connect_to_channels');
        });

        /* 
            When a chat is deleted from any channel that the user is a part of, 
            update the my channels list by displaying to the user that the recent chat for that channel has just been deleted
        */
        socket.on('chat_deleted', (data) => {
            store.dispatch(deleted_chat_channel_update({ chat_to_delete: data, logged_in: store.getState().login_state.logged_in }));
            store.dispatch(update_deleted_chat({ chat_to_delete: data }));
        });

        // Receive updates for every channel that the user has joined
        socket.on('channel_update', (data) => {
            store.dispatch(update_a_channel_in_my_channels({ data: data, in_chats_screen: store.getState().chat.in_chats_screen, channel_id: store.getState().chat.channel_properties.channel_id }));
        });
    }
};

export const getSocket = () => { return socket };

export const disconnectSocket = () => {
    if (socket) {
        socket.disconnect();
        socket = null;
    }
};
