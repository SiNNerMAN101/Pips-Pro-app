import { store } from '../../store/store';
import { backend_api } from '../backend_api';

// Handle a situation where by the user types into the search bar in the search channels modal
export const handle_search = async (setLoading, setSearchResults, searchQuery, controller) => {
    setLoading(true);

    // Make request to the backend to search for channels based on the users search term
    await fetch(`${backend_api()}/api/user/search-channels`, {
        method: "POST",
        signal: controller.signal,
        headers: {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        },
        body: JSON.stringify({
            search: searchQuery
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        if (response.res_code === 455 || response.res_code === 401 || response.res_code === 500){
            setSearchResults([]);
            setLoading(true);
        } else if (response.res_code === 305){
            setSearchResults([]);
            setLoading('no_result');
        } else if (response.res_code === 200){
            setSearchResults(response.result.search);
            setLoading(false);
        } else {
            setSearchResults([]);
            setLoading(true);
        }
    })
    .catch((err) => {
        setSearchResults([]);
        setLoading(true);
    })
};