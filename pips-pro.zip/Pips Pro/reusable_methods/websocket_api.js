// Websocket API url
export const websocket_api = (id) => {
    if (id === 1){ // For fetching watchlist symbols
        return 'ws://172.20.10.14:3000/watchlist';
    } else if (id === 2){ // For handling channels
        return 'ws://172.20.10.14:3000/channels';
    }
};