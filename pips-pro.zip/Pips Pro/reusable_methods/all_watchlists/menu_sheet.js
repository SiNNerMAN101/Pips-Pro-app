import * as Haptics from 'expo-haptics';
import {ActionSheetIOS, Platform} from 'react-native';
import { delete_watchlist } from './delete_watchlist';

// Display a menu sheet for both android ans ios
export const menu_sheet = async (showActionSheetWithOptions, is_darkmode, navigation, active_watchlist_id, current_watchlist_id, watchlist_name, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, loading_modal, set_loading_modal, delete_watchlist_controller) => {
  // Trigger haptic feedback
  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

  if (Platform.OS === 'android'){
    const options = ['Rename', 'Delete', 'Cancel'];
    const destructiveButtonIndex = 2;
    const cancelButtonIndex = 3;
    const userInterfaceStyle = is_darkmode === true ? "dark" : "light";

    showActionSheetWithOptions({
      options,
      cancelButtonIndex,
      destructiveButtonIndex,
      userInterfaceStyle
    }, (selectedIndex) => {
      switch (selectedIndex) {
        case 0:
          // Rename
          navigation.navigate('RenameWatchlistModal', {
            current_watchlist_id: current_watchlist_id,
            watchlist_name: watchlist_name
          });
          break;
        case 1:
          // Delete
          break;
        case destructiveButtonIndex:
          // Canceled
    }}); 
  } else if (Platform.OS === 'ios'){
    ActionSheetIOS.showActionSheetWithOptions(
      {
        options: ['Rename', 'Delete', 'Cancel'],
        destructiveButtonIndex: 2,
        cancelButtonIndex: 3,
        userInterfaceStyle: is_darkmode === true ? "dark" : "light"
      },
      async buttonIndex => {
        if (buttonIndex === 0) {
          // rename action
          navigation.navigate('RenameWatchlistModal', {
            current_watchlist_id: current_watchlist_id,
            watchlist_name: watchlist_name
          });
        } else if (buttonIndex === 1) {
          // delete action
          await delete_watchlist(delete_watchlist_controller, current_watchlist_id, loading_modal, set_loading_modal, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err);
        } else if (buttonIndex === 2) {
          // cancel action
        }
      },
    )
  }
};