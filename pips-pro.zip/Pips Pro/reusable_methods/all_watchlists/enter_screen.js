import { store } from "../../store/store";
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SplashScreen from 'expo-splash-screen';
import { set_accessToken, set_darkmode, set_logged_in, set_user_details } from "../../state/loginState";
import { fetch_all_watchlists } from "./fetch_all_watchlists";
import { set_all_watchlists_state } from "../../state/watchListState";

// This method runs when the user enters the all watchlists screen
export const enter_screen = async (controller) => {
    // Check if the user is logged in or not
    if (store.getState().login_state.logged_in === true){
        if (store.getState().watch_list_state.all_watchlists_state === 'loading' || store.getState().watch_list_state.all_watchlists_state === 'no_access' || store.getState().watch_list_state.all_watchlists_state === 'error'){
            store.dispatch(set_all_watchlists_state({ value: 'loading' }));
            await fetch_all_watchlists(store.getState().login_state.accessToken, controller); // Fetch all the users watchlists
        }
    } else {
        const auth_token = await SecureStore.getItemAsync('auth_token'); // Get auth token if available
        let is_user_details_stored = false;
        let user_details_data = { 
            username: '',
            email: '',
            user_id: null,
            profile_image: null,
            color_code: '#FFFFFF',
            premium_account: false
        }

        try {
            const user_details = await AsyncStorage.getItem('user_details');

            if (user_details !== null) {
                is_user_details_stored = true;
                user_details_data = JSON.parse(user_details);
            } else {
                is_user_details_stored = false;    
            }
        } catch (e) {
            // error reading value
            is_user_details_stored = false;
        }

        /*
            Handle darkmode
        */
        try {
            const darkmode = await AsyncStorage.getItem('darkmode');

            if (darkmode !== null) {
                let parsed_json = JSON.parse(darkmode);
                if (parsed_json.value === true || parsed_json.value === false){
                    store.dispatch(set_darkmode({ value: parsed_json.value }));
                } else {
                    await AsyncStorage.setItem('darkmode', JSON.stringify({ value: false }));
                    store.dispatch(set_darkmode({ value: false }));
                }
            } else {
                await AsyncStorage.setItem('darkmode', JSON.stringify({ value: false }));
                store.dispatch(set_darkmode({ value: false }));  
            }
        } catch (e) {
            // error reading value
            store.dispatch(set_darkmode({ value: false }));  
        }

        // Check if auth token and user details are stored locally on the user device
        if (auth_token && is_user_details_stored === true){
            store.dispatch(set_accessToken({ token: auth_token }));
            store.dispatch(set_user_details({ details: user_details_data }));
            store.dispatch(set_logged_in({ value: true }));

            setTimeout(async () => {
                await SplashScreen.hideAsync(); // Hide the splash screen once it is determined that the user is not logged in
            }, 800);

            await fetch_all_watchlists(auth_token, controller); // Fetch all the users watchlists
        } else {
            setTimeout(async () => {
                await SplashScreen.hideAsync(); // Hide the splash screen once it is determined that the user is not logged in
            }, 800);

            await fetch_all_watchlists(auth_token, controller); // Fetch all the users watchlists
        }
    }
};