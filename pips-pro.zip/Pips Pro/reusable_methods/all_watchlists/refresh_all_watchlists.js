import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { set_all_watchlists, set_all_watchlists_state } from "../../state/watchListState";

// Refresh all the users watchlists
export const refresh_all_watchlists = async (refresh_controller, setRefreshing) => {
    setRefreshing(true); // Enable refresh spinner animation

    // Make request to the backend to fetch all the users watchlists
    await fetch(`${backend_api()}/api/user/fetch-all-watchlists`, {
        method: "POST",
        signal: refresh_controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        } : { 'Content-Type': 'application/json' }
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        refresh_controller.current = new AbortController();

        setRefreshing(false); // Disable refresh spinner animation

        if (response.res_code === 401 || response.res_code === 500){
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: 'error' }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        } else if (response.res_code === 356){
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: false }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        } else if (response.res_code === 200){
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists({ data: response.result }));
                store.dispatch(set_all_watchlists_state({ value: true }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        } else {
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: 'error' }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        }
    })
    .catch((err) => {
        refresh_controller.current = new AbortController();

        setRefreshing(false); // Disable refresh spinner animation

        if (err.name !== 'AbortError') {
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: 'error' }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        }
    })
};