import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { delete_user_watchlist, set_watchlist_state } from "../../state/watchListState";

// Delete a particular watchlist
export const delete_watchlist = async (controller, current_watchlist_id, loading_modal, set_loading_modal, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    set_loading_modal(true);
        
    // Make request to the backend to delete a particular watchlist
    await fetch(`${backend_api()}/api/user/delete-watchlist`, {
        method: "POST",
        signal: controller.current.signal,
        headers: {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        },
        body: JSON.stringify({
            watchlist_id: current_watchlist_id
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        set_loading_modal(false);

        if (response.res_code === 401 || response.res_code === 500 || response.res_code === 455){
            set_snackbar_toggle(true);
            set_snackbar_err(true);
            set_snackbar_msg('An error occured, please try again later');
        } else if (response.res_code === 435){
            set_snackbar_toggle(true);
            set_snackbar_err(true);
            set_snackbar_msg(response.err_msg);
        } else if (response.res_code === 200){
            store.dispatch(delete_user_watchlist({ current_watchlist_id: response.result.watchlist_id }));
            store.dispatch(set_watchlist_state({ value: 'loading' }));
            set_snackbar_toggle(true);
            set_snackbar_err(false);
            set_snackbar_msg('Watchlist has been deleted');
        } else {
            set_snackbar_toggle(true);
            set_snackbar_err(true);
            set_snackbar_msg('An error occured, please try again later');
        }
    })
    .catch((err) => {
        set_loading_modal(false);
        
        if (err.name !== 'AbortError') {
            set_snackbar_toggle(true);
            set_snackbar_err(true);
            set_snackbar_msg('An error occured, please try again later');
        }
    })
};