import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { update_all_watchlists } from "../../state/watchListState";

// Create a new watchlist for the user
export const create_watchlist = async (controller, watchlist, navigation, loading, set_loading, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    set_snackbar_toggle(false);

    if (loading === false){
        set_loading(true);

        // Make request to the backend to create a new watchlist for the user
        await fetch(`${backend_api()}/api/user/create-watchlist`, {
            method: "POST",
            signal: controller.current.signal,
            headers: {
                'Content-Type': 'application/json',
                "Authorization": `Bearer ${store.getState().login_state.accessToken}`
            },
            body: JSON.stringify({
                watchlist: watchlist
            })
        })
        .then((res) => {
            return res.json();
        })
        .then(async (response) => {
            set_loading(false);

            if (response.res_code === 401 || response.res_code === 500 || response.res_code === 455){
                set_snackbar_toggle(true);
                set_snackbar_err(true);
                set_snackbar_msg('An error occured, please try again later');
            } else if (response.res_code === 435){
                set_snackbar_toggle(true);
                set_snackbar_err(true);
                set_snackbar_msg(response.err_msg);
            } else if (response.res_code === 200){
                store.dispatch(update_all_watchlists({ data: response.result }));
                set_snackbar_toggle(true);
                set_snackbar_err(false);
                set_snackbar_msg('Watchlist has been created');
            } else {
                set_snackbar_toggle(true);
                set_snackbar_err(true);
                set_snackbar_msg('An error occured, please try again later');
            }
        })
        .catch((err) => {
            set_loading(false);

            if (err.name !== 'AbortError') {
                set_snackbar_toggle(true);
                set_snackbar_err(true);
                set_snackbar_msg('An error occured, please try again later');
            }
        })
    }
};