import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { set_all_watchlists, set_all_watchlists_state } from "../../state/watchListState";

// Fetch all the users watchlists
export const fetch_all_watchlists = async (accessToken, controller) => {
    // Make request to the backend to fetch all the users watchlists
    await fetch(`${backend_api()}/api/user/fetch-all-watchlists`, {
        method: "POST",
        signal: controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${accessToken}`
        } : { 'Content-Type': 'application/json' }
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        if (response.res_code === 401 || response.res_code === 500){
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: 'error' }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        } else if (response.res_code === 356){
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: false }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        } else if (response.res_code === 200){
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists({ data: response.result }));
                store.dispatch(set_all_watchlists_state({ value: true }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        } else {
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: 'error' }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        }
    })
    .catch((err) => {
        if (err.name !== 'AbortError') {
            if (store.getState().login_state.logged_in === true){
                store.dispatch(set_all_watchlists_state({ value: 'error' }));
            } else {
                store.dispatch(set_all_watchlists_state({ value: 'no_access' }));
            }
        }
    })
};