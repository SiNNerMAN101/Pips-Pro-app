import AsyncStorage from '@react-native-async-storage/async-storage';
import { store } from '../../../store/store';
import { select_active_watchlist } from '../../../state/watchListState';

// Display the selected watchlist to the user
export const view_action = async (navigation, current_watchlist_id) => {
    store.dispatch(select_active_watchlist({ current_watchlist_id: current_watchlist_id }));

    navigation.navigate('WatchList');

    try {
        await AsyncStorage.setItem('active_watchlist_id', JSON.stringify({ value: current_watchlist_id }));
    } catch (e) {
        // error reading value
    }
};