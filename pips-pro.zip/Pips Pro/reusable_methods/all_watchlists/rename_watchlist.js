import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { rename_user_watchlist, set_watchlist_state } from "../../state/watchListState";

// Rename a particular watchlist
export const rename_watchlist = async (controller, watchlist_name_state, set_watchlist_name_state, current_watchlist_id, watchlist_name, new_watchlist_name, navigation, loading, set_loading, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    set_snackbar_toggle(false);

    if (loading === false){
        if (watchlist_name_state !== new_watchlist_name){
            set_loading(true);
        
            // Make request to the backend to rename a particular watchlist
            await fetch(`${backend_api()}/api/user/rename-watchlist`, {
                method: "POST",
                signal: controller.current.signal,
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization": `Bearer ${store.getState().login_state.accessToken}`
                },
                body: JSON.stringify({
                    watchlist_id: current_watchlist_id,
                    watchlist_name: new_watchlist_name
                })
            })
            .then((res) => {
                return res.json();
            })
            .then(async (response) => {
                set_loading(false);

                if (response.res_code === 401 || response.res_code === 500 || response.res_code === 455){
                    set_snackbar_toggle(true);
                    set_snackbar_err(true);
                    set_snackbar_msg('An error occured, please try again later');
                } else if (response.res_code === 435){
                    set_snackbar_toggle(true);
                    set_snackbar_err(true);
                    set_snackbar_msg(response.err_msg);
                } else if (response.res_code === 200){
                    store.dispatch(rename_user_watchlist({ current_watchlist_id: response.result.watchlist_id, new_watchlist_name: response.result.watchlist_name }));
                    store.dispatch(set_watchlist_state({ value: 'loading' }));
                    set_snackbar_toggle(true);
                    set_snackbar_err(false);
                    set_snackbar_msg('Watchlist has been renamed');
                    set_watchlist_name_state(new_watchlist_name);
                } else {
                    set_snackbar_toggle(true);
                    set_snackbar_err(true);
                    set_snackbar_msg('An error occured, please try again later');
                }
            })
            .catch((err) => {
                set_loading(false);
                
                if (err.name !== 'AbortError') {
                    set_snackbar_toggle(true);
                    set_snackbar_err(true);
                    set_snackbar_msg('An error occured, please try again later');
                }
            })
        }
    }
};