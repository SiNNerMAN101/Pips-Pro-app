import { Foundation } from '@expo/vector-icons';

/* 
    This file will handle all the icons of the rich text editor toolbar
*/

export const handleBold = ({tintColor}) => <Foundation name="bold" size={24} color={tintColor} />

export const handleItalic = ({tintColor}) => <Foundation name="italic" size={24} color={tintColor} />

export const handleStrikeThrough = ({tintColor}) => <Foundation name="strikethrough" size={24} color={tintColor} />

export const handleBulletList = ({tintColor}) => <Foundation name="list-bullet" size={24} color={tintColor} />

export const handleOrderedList = ({tintColor}) => <Foundation name="list-number" size={24} color={tintColor} />

export const handleLink = ({tintColor}) => <Foundation name="link" size={24} color={tintColor} />