// This method is called when the user interacts with the tags from the text editors toolbar
export const handle_toolbar_interaction = (tag, selection, setSelection, values, setFieldValue) => {
    /*
        NOTE: The tag parameter above refers to the tag name from the
        toolbar of the editor that the user selected.

        Toolbar tag names include:
        [1] => Bold tag
        [2] => Italic tag
        [3] => Strike through tag
        [4] => Bullet list tag
        [5] => Ordered(numeric) list tag
        [6] => Link tag 
    */

    // Check if the cursor is between the specified startTag and endTag, accounting for spaces
    const isCursorInsideTag = (startTag, endTag) => {
        const startTagIndex = values.body.indexOf(startTag);
        const endTagIndex = values.body.indexOf(endTag);

        if (startTagIndex !== -1 && endTagIndex !== -1) {
            // Extract content between [start_tag] and [/end_tag]
            const contentBetweenTags = values.body.substring(startTagIndex + startTag.length, endTagIndex);

            // Remove any leading or trailing spaces/newlines
            const trimmedContent = contentBetweenTags.trim();

            // Check if the cursor is between the [start_tag]...[/end_tag] after trimming spaces
            return (
                selection.start > startTagIndex + startTag.length &&
                selection.end < endTagIndex &&
                trimmedContent.length > 0 // Ensure there's actual content between the tags
            );
        }
        return false;
    };

    const { start, end } = selection; // Get the text selection/highlighting positions from the start of the selection to the end of the selection from the editor
    
    // Check if there is any selected text from the editor
    if (start !== end){
        if (tag === 1){ // Bold tag
            // Get the selected text from the editor
            const selectedText = values.body.slice(start, end);
            
            // Wrap the selected text with the tag that the user picked from the toolbar
            const newText = values.body.slice(0, start) + `[b]${selectedText}[/b]` + values.body.slice(end);

            setFieldValue('body', newText); // Update the contents of the editor
        } else if (tag === 2){ // Italic tag
            // Get the selected text from the editor
            const selectedText = values.body.slice(start, end);
            
            // Wrap the selected text with the tag that the user picked from the toolbar
            const newText = values.body.slice(0, start) + `[i]${selectedText}[/i]` + values.body.slice(end);

            setFieldValue('body', newText); // Update the contents of the editor
        } else if (tag === 3){ // Strike through tag
            // Get the selected text from the editor
            const selectedText = values.body.slice(start, end);
            
            // Wrap the selected text with the tag that the user picked from the toolbar
            const newText = values.body.slice(0, start) + `[s]${selectedText}[/s]` + values.body.slice(end);

            setFieldValue('body', newText); // Update the contents of the editor
        } else if (tag === 4){ // Bullet list tag
            // Get the selected text from the editor
            const selectedText = values.body.slice(start, end);
            
            // Wrap the selected text with the tag that the user picked from the toolbar
            const newText = values.body.slice(0, start) + `[list-1]\n[item]${selectedText}[/item]\n[/list-1]` + values.body.slice(end);

            setFieldValue('body', newText); // Update the contents of the editor
        } else if (tag === 5){ // Ordered list tag
            // Get the selected text from the editor
            const selectedText = values.body.slice(start, end);
            
            // Wrap the selected text with the tag that the user picked from the toolbar
            const newText = values.body.slice(0, start) + `[list-2]\n[item]${selectedText}[/item]\n[/list-2]` + values.body.slice(end);

            setFieldValue('body', newText); // Update the contents of the editor
        } else if (tag === 6){ // Link tag
            // Get the selected text from the editor
            const selectedText = values.body.slice(start, end);
            
            // Wrap the selected text with the tag that the user picked from the toolbar
            const newText = values.body.slice(0, start) + `[link url="${selectedText}"]` + values.body.slice(end);

            setFieldValue('body', newText); // Update the contents of the editor
        }
    } else { // There was no selection
        /* 
            Since the user did not select any text at the time of the user clicking any of the tags on the toolbar,
            go ahead and place the selected tag in the position where the user was in the editor  
        */
        
        if (tag === 1){ // Bold tag
            // Get text segments from the editor
            const beforeText = values.body.slice(0, start);
            const afterText = values.body.slice(end);
            let newText = `[b][/b]`; // This is the tag to be placed in that position of the editor

            // Create new text by inserting newText at the selected range
            const updatedText = `${beforeText}${newText}${afterText}`;
            
            // Update the contents of the editor
            setFieldValue('body', updatedText);

            // Optionally, set the cursor position after the inserted text
            setSelection({
                start: start + newText.length,
                end: start + newText.length
            });
        } else if (tag === 2){ // Italic tag
            // Get text segments from the editor
            const beforeText = values.body.slice(0, start);
            const afterText = values.body.slice(end);
            let newText = `[i][/i]`; // This is the tag to be placed in that position of the editor

            // Create new text by inserting newText at the selected range
            const updatedText = `${beforeText}${newText}${afterText}`;
            
            // Update the contents of the editor
            setFieldValue('body', updatedText);

            // Optionally, set the cursor position after the inserted text
            setSelection({
                start: start + newText.length,
                end: start + newText.length
            });
        } else if (tag === 3){ // Strike through tag
            // Get text segments from the editor
            const beforeText = values.body.slice(0, start);
            const afterText = values.body.slice(end);
            let newText = `[s][/s]`; // This is the tag to be placed in that position of the editor

            // Create new text by inserting newText at the selected range
            const updatedText = `${beforeText}${newText}${afterText}`;
            
            // Update the contents of the editor
            setFieldValue('body', updatedText);

            // Optionally, set the cursor position after the inserted text
            setSelection({
                start: start + newText.length,
                end: start + newText.length
            });
        } else if (tag === 4){ // Bullet list tag
            let newText = ``;

            if (isCursorInsideTag('[list-1]', '[/list-1]') === true || isCursorInsideTag('[list-2]', '[/list-2]') === true){
                newText = `[item][/item]`; // This is the tag to be placed in that position of the editor
            } else {
                newText = `[list-1]\n[item][/item]\n[/list-1]`; // This is the tag to be placed in that position of the editor
            }

            // Get text segments from the editor
            const beforeText = values.body.slice(0, start);
            const afterText = values.body.slice(end);

            // Create new text by inserting newText at the selected range
            const updatedText = `${beforeText}${newText}${afterText}`;
            
            // Update the contents of the editor
            setFieldValue('body', updatedText);

            // Optionally, set the cursor position after the inserted text
            setSelection({
                start: start + newText.length,
                end: start + newText.length
            });
        } else if (tag === 5){ // Ordered list tag
            let newText = ``;

            if (isCursorInsideTag('[list-2]', '[/list-2]') === true || isCursorInsideTag('[list-1]', '[/list-1]') === true){
                newText = `[item][/item]`; // This is the tag to be placed in that position of the editor
            } else {
                newText = `[list-2]\n[item][/item]\n[/list-2]`; // This is the tag to be placed in that position of the editor
            }

            // Get text segments from the editor
            const beforeText = values.body.slice(0, start);
            const afterText = values.body.slice(end);

            // Create new text by inserting newText at the selected range
            const updatedText = `${beforeText}${newText}${afterText}`;
            
            // Update the contents of the editor
            setFieldValue('body', updatedText);

            // Optionally, set the cursor position after the inserted text
            setSelection({
                start: start + newText.length,
                end: start + newText.length
            });
        } else if (tag === 6){ // Link tag
            // Get text segments from the editor
            const beforeText = values.body.slice(0, start);
            const afterText = values.body.slice(end);
            let newText = `[link url=""]`; // This is the tag to be placed in that position of the editor

            // Create new text by inserting newText at the selected range
            const updatedText = `${beforeText}${newText}${afterText}`;
            
            // Update the contents of the editor
            setFieldValue('body', updatedText);

            // Optionally, set the cursor position after the inserted text
            setSelection({
                start: start + newText.length,
                end: start + newText.length
            });
        }
    };
};