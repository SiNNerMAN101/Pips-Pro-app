import { render_overview_widget } from "./render_overview_widget";

// Get the change value and the change percent value for each symbol and format them properly
export const modifyOverviewWidget = (onRefreshWidget, data, is_darkmode) => {
    if (data.type === 'symbol_change'){
        onRefreshWidget('');

        setTimeout(() => {
            onRefreshWidget(render_overview_widget(data.value, is_darkmode));
        }, 30);
    }
};