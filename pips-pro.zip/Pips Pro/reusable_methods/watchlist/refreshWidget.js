// Refresh the overview widget
export const refreshWidget = (overview_widget, onRefreshWidget, is_darkmode) => {
    let recent_widget_data = overview_widget;

    onRefreshWidget(`
        <!DOCTYPE html>
        <html style="height: 100%;" lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
                <title>Overview Widget</title>
            </head>
            <body style="height: 100%; margin: 0;">
                <div style="position: absolute; top: 0; left: 0; width: 600px; height: 100%; background-color: ${is_darkmode === true ? '#131722' : 'rgba(255, 255, 255, 1)'};">
                    <p style="color: ${is_darkmode === true ? '#ffffff' : '#000000'};">Loading Now...</p>
                </div>
            </body>
        </html>
    `);

    setTimeout(() => {
        onRefreshWidget(recent_widget_data);
    }, 30);
};