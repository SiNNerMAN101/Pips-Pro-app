// Get the change value and the change percent value for each symbol and format them properly
export const conv_changes = (change, change_percent) => {
    if (typeof change === 'string' && typeof change_percent === 'string') {
        let type = null;

        if (change.charAt(0) === '-') {
            type = 'negative';
        } else if (change.charAt(0) === '+'){
            type = 'positive';
        } else {
            type = 'default';
        }

        return { data: `${change + '%'}  ${(type === 'positive') ? '+' : ''}${change_percent}`, type: type };
    } else {
        return { data: '-- : --', type: 'default' };
    }
};