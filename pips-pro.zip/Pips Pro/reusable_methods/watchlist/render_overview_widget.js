// Render the overview widget
export const render_overview_widget = (symbol, is_darkmode) => {
    return `
        <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
                <title>Overview Widget</title>
            </head>
            <body style="margin: 0;">
                <script>
                    window.addEventListener('load', function() {
                        // Code to execute when all page resources are loaded
                        document.querySelector("#fullscreen").style.display = 'none';
                    });
                </script>

                <!-- TradingView Widget BEGIN -->
                <div class="tradingview-widget-container">
                    <div class="tradingview-widget-container__widget">
                        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: background-color: ${is_darkmode === true ? '#131722' : 'rgba(255, 255, 255, 1)'};">
                            <p style="color: ${is_darkmode === true ? '#ffffff' : '#000000'};">Loading Now...</p>
                        </div>
                    </div>
                    <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-symbol-overview.js" async>
                    {
                        "symbols": [
                            [ "${symbol}" ]
                        ],
                        "chartOnly": false,
                        "width": "100%",
                        "height": 600,
                        "locale": "en",
                        "colorTheme": "${is_darkmode === true ? 'dark' : 'light'}",
                        "autosize": true,
                        "showVolume": false,
                        "showMA": false,
                        "hideDateRanges": false,
                        "hideMarketStatus": false,
                        "hideSymbolLogo": false,
                        "scalePosition": "right",
                        "scaleMode": "Normal",
                        "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
                        "fontSize": "10",
                        "noTimeScale": false,
                        "valuesTracking": "1",
                        "changeMode": "price-and-percent",
                        "chartType": "area",
                        "maLineColor": "#2962FF",
                        "maLineWidth": 1,
                        "maLength": 9,
                        "gridLineColor": "rgba(255, 255, 255, 0.06)",
                        "backgroundColor": "${is_darkmode === true ? '#131722' : 'rgba(255, 255, 255, 1)'}",
                        "widgetFontColor": "${is_darkmode === true ? 'rgba(255, 255, 255, 1)' : 'rgba(0, 0, 0, 1)'}",
                        "lineWidth": 2,
                        "lineType": 0,
                        "dateRanges": [
                            "1d|1",
                            "1m|30",
                            "3m|60",
                            "12m|1D",
                            "60m|1W",
                            "all|1M"
                        ]
                    }
                    </script>
                </div>
                <!-- TradingView Widget END -->

                <div id="fullscreen" style="position: absolute; top: 0; left: 0; width: 100%; height: 600px; background-color: ${is_darkmode === true ? '#131722' : 'rgba(255, 255, 255, 1)'};">
                    <p style="color: ${is_darkmode === true ? '#ffffff' : '#000000'};">Loading Now...</p>
                </div>
            </body>
        </html>
    `;
};