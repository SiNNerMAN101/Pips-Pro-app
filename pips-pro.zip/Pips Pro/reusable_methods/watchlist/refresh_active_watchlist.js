import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { set_active_watchlist, set_active_watchlist_name, set_all_watchlists_state, set_watchlist_state } from "../../state/watchListState";

// Fetch the users active watchlist
export const refresh_active_watchlist = async (refresh_controller, setRefreshing) => {
    setRefreshing(true); // Enable refresh spinner animation

    // Make request to the backend to fetch the users active watchlist
    await fetch(`${backend_api()}/api/user/fetch-active-watchlist`, {
        method: "POST",
        signal: refresh_controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        } : { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            active_watchlist_id: store.getState().watch_list_state.active_watchlist_id
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        refresh_controller.current = new AbortController();

        setRefreshing(false); // Disable refresh spinner animation

        if (response.res_code === 401 || response.res_code === 500){
            store.dispatch(set_watchlist_state({ value: 'error' }));
        } else if (response.res_code === 276){
            store.dispatch(set_active_watchlist_name({ value: response.result.watchlist_name }));
            store.dispatch(set_watchlist_state({ value: false }));
        } else if (response.res_code === 315){
            store.dispatch(set_watchlist_state({ value: 'deleted' }));
            store.dispatch(set_all_watchlists_state({ value: 'loading' }));
        } else if (response.res_code === 339){
            store.dispatch(set_watchlist_state({ value: 'no_watchlist' }));
        } else if (response.res_code === 200){
            store.dispatch(set_active_watchlist_name({ value: response.result.watchlist_name }));
            store.dispatch(set_active_watchlist({ data: response.result.watchlist }));
            store.dispatch(set_watchlist_state({ value: true }));
        } else {
            store.dispatch(set_watchlist_state({ value: 'error' }));
        }
    })
    .catch((err) => {
        refresh_controller.current = new AbortController();

        setRefreshing(false); // Disable refresh spinner animation

        if (err.name !== 'AbortError') {
            store.dispatch(set_watchlist_state({ value: 'error' }));
        }
    })
};