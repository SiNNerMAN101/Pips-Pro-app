// Check if a decimal value has one or more numbers before the point
export const hasOneDigitBeforeDecimal = (price) => {
    // Convert the number to a string
    var priceString = price.toString();
    
    // Split the string by the decimal point
    var parts = priceString.split('.');
    
    // Check if there is only one part before the decimal point and its length is 1
    if (parts.length === 2 && parts[0].length === 1){
        return price;
    } else {
        return (Math.round(parseFloat(price) * 100) / 100).toFixed(2);
    }
};