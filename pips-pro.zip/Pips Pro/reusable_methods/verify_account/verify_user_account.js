import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { set_accessToken, set_logged_in, set_user_details } from '../../state/loginState';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';
import { set_all_watchlists_state, set_watchlist_state } from '../../state/watchListState';
import { reset_channels_state } from '../../state/channels';

// Verify the users account
export const verify_user_account = async (verification_code, username, email, verify_account_token, set_is_disabled, set_loading_modal, set_type, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, controller, navigation) => {
  set_is_disabled(true);
  set_snackbar_toggle(false);

  set_type(1);
  set_loading_modal(true);

  // Make request to the backend to verify the users account
  await fetch(`${backend_api()}/api/user/verify-account`, {
    method: "POST",
    signal: controller.signal,
    headers: {
      'Content-Type': 'application/json',
      "Authorization": `Bearer ${verify_account_token}`
    },
    body: JSON.stringify({
      verification_code: verification_code
    })
  })
  .then((res) => {
    return res.json();
  })
  .then(async (response) => {
    if (response.res_code === 455){
      set_snackbar_msg(response.err_msg);
      set_snackbar_err(true);
      set_snackbar_toggle(true);
      set_is_disabled(false);
      set_loading_modal(false);
    } else if (response.res_code === 401 || response.res_code === 500){
      set_snackbar_msg('An error occured, please try again later');
      set_snackbar_err(true);
      set_snackbar_toggle(true);
      set_is_disabled(false);
      set_loading_modal(false);
    } else if (response.res_code === 200){
      await SecureStore.setItemAsync('auth_token', response.accessToken); // Store access token in secure store

      try {
        const user_details = JSON.stringify(response.result);
        await AsyncStorage.setItem('user_details', user_details); // Store the users details with async storage
      } catch (e) {
        // saving error
      }

      // Store the users details in the redux store state
      store.dispatch(set_user_details({ details: response.result }));
      store.dispatch(set_accessToken({ token: response.accessToken }));
      store.dispatch(set_logged_in({ value: true }));
      store.dispatch(set_all_watchlists_state({ value: 'loading' }));
      store.dispatch(set_watchlist_state({ value: 'loading' }));
      store.dispatch(reset_channels_state({}));
      navigation.navigate('WatchList');
    }
  })
  .catch((err) => {
    if (err.name !== 'AbortError'){
      set_snackbar_msg('An error occured, please try again later');
      set_snackbar_err(true);
      set_snackbar_toggle(true);
      set_is_disabled(false);
      set_loading_modal(false);
    }
  })
};