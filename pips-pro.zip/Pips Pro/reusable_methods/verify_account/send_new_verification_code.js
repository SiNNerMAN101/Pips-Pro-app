import { backend_api } from '../backend_api';

// Send new verification code to the users email
export const send_new_verification_code = async (user_id, user_details, set_user_details, set_is_disabled, set_loading_modal, set_type, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, controller, navigation) => {
    set_is_disabled(true);
    set_snackbar_toggle(false);

    set_type(2);
    set_loading_modal(true);

    // Make request to the backend to generate and send a new verification code to the user
    await fetch(`${backend_api()}/api/user/resend-verification-code`, {
        method: "POST",
        signal: controller.signal,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            user_id: user_id
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        if (response.res_code === 455){
            set_snackbar_msg(response.err_msg);
            set_snackbar_err(true);
            set_snackbar_toggle(true);
            set_is_disabled(false);
            set_loading_modal(false);
        } else if (response.res_code === 401 || response.res_code === 500){
            set_snackbar_msg('An error occured, please try again later');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
            set_is_disabled(false);
            set_loading_modal(false);
        } else if (response.res_code === 200){
            set_user_details({ username: response.result.username, email: response.result.email, verify_account_token: response.accessToken, user_id: response.result.user_id }); // Store new user details in the state
            set_snackbar_msg('A new verification code has been sent to your email');
            set_snackbar_err(false);
            set_snackbar_toggle(true);
            set_is_disabled(false);
            set_loading_modal(false);
        }
    })
    .catch((err) => {
        if (err.name !== 'AbortError'){
            set_snackbar_msg('An error occured, please try again later');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
            set_is_disabled(false);
            set_loading_modal(false);
        }
    })
};