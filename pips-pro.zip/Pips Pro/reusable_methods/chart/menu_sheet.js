import { store } from "../../store/store";
import { type_one } from "./menu_sheet_types/type_one";
import { type_two } from "./menu_sheet_types/type_two";
import { type_three } from "./menu_sheet_types/type_three";
import { type_four } from "./menu_sheet_types/type_four";
import { type_five } from "./menu_sheet_types/type_five";
import { type_six } from "./menu_sheet_types/type_six";

// The menu sheet
export const menu_sheet = (chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket) => {
    if (store.getState().login_state.logged_in === true){
        if (store.getState().chat.channel_properties.joined === true){
            let user_id = store.getState().login_state.user_details.user_id; // The users ID
            
            if (chat['sent_msg'] === true){ // If the chat is already sent and stored on the server
                if (chat['chat_type'] === 1){ // Plain text chat
                    if (store.getState().chat.channel_properties.creator_id === user_id){ // Check if the user is the creator of the channel
                        type_one(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket);
                    } else {
                        if (chat['user_id'] === user_id){ // Check if the user was the one that created the chat
                            type_one(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket);
                        } else {
                            type_five(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller);
                        }
                    }
                } else if (chat['chat_type'] === 2){ // Trade idea chat
                    if (store.getState().chat.channel_properties.creator_id === user_id){ // Check if the user is the creator of the channel
                        type_two(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket);
                    } else {
                        if (chat['user_id'] === user_id){ // Check if the user was the one that created the chat
                            type_two(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket);
                        } else {
                            type_six(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller);
                        }
                    }
                }
            } else { // If the chat is yet to be sent and stored on the server
                if (chat['chat_type'] === 1){ // Plain text chat
                    type_three(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket);
                } else if (chat['chat_type'] === 2){ // Trade idea chat
                    type_four(chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller);
                }
            }
        }   
    }
};