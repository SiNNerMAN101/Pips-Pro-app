// Render the trading view technical analysis chart
export const render_technical_analysis_chart = (hide_side_toolbar, is_darkmode) => {
    return `
        <!DOCTYPE html>
        <html style="height: 100%;" lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
                <title>Technical Analysis Chart With Trading View</title>
                <style>
                    html, body { height: 100% }
                </style>
            </head>
            <body style="height: 100%; margin: 0;">
                <script>
                    window.addEventListener('load', function() {
                        // Code to execute when all page resources are loaded
                        document.querySelector("#fullscreen").style.display = 'none';
                    });
                </script>

                <!-- TradingView Widget BEGIN -->
                <div class="tradingview-widget-container" style="height:100%;width:100%">
                    <div class="tradingview-widget-container__widget" style="height:calc(100% - 32px);width:100%">
                        <div style="position: absolute; top: 0; left: 0; display: flex; justify-content: center; align-items: center; overflow: hidden; width: 100%; height: 100%; background-color: ${is_darkmode === true ? '#131722' : 'rgba(255, 255, 255, 1)'};">
                            <p style="color: ${is_darkmode === true ? '#ffffff' : '#000000'}; font-size: 26px; font-family: 'sans-serif'">Loading Chart...</p>
                        </div>
                    </div>

                    <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
                        {
                            "autosize": true,
                            "symbol": "AAPL",
                            "interval": "1",
                            "timezone": "Etc/UTC",
                            "theme": "${is_darkmode === true ? 'dark' : 'light'}",
                            "style": "1",
                            "locale": "en",
                            "enable_publishing": false,
                            "backgroundColor": "${is_darkmode === true ? 'rgba(0, 0, 0, 1)' : 'rgba(255, 255, 255, 1)'}",
                            "allow_symbol_change": true,
                            "hide_side_toolbar": ${hide_side_toolbar},
                            "save_image": false,
                            "calendar": false,
                            "support_host": "https://www.tradingview.com"
                        }
                    </script>
                </div>

                <!-- TradingView Widget END -->
                <div id="fullscreen" style="position: absolute; top: 0; left: 0; display: flex; justify-content: center; align-items: center; overflow: hidden; width: 100%; height: 100%; background-color: ${is_darkmode === true ? '#131722' : 'rgba(255, 255, 255, 1)'};">
                    <p style="color: ${is_darkmode === true ? '#ffffff' : '#000000'}; font-size: 26px; font-family: 'sans-serif'">Loading Chart...</p>
                </div>
            </body>
        </html>
    `;
};