import { backend_api } from '../backend_api';

// Send confirmation code to the user 
export const send_confirmation_code = async (email, navigation, snackbar_toggle, snackbar_err, snackbar_msg, is_loading, set_is_loading, controller, set_controller, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    if (is_loading === false){
        set_is_loading(true);
        set_snackbar_toggle(false);

        // Make request to the backend to send a confirmation code to the users provided email that they can use to reset their password
        await fetch(`${backend_api()}/api/user/send-confirmation-code`, {
            method: "POST",
            signal: controller.signal,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email
            })
        })
        .then((res) => {
            return res.json();
        })
        .then((response) => {
            set_is_loading(false);
            if (response.res_code === 455){
                set_snackbar_msg(response.err_msg);
                set_snackbar_err(true);
                set_snackbar_toggle(true);
            } else if (response.res_code === 401 || response.res_code === 500){
                set_snackbar_msg('An error occured, please try again later');
                set_snackbar_err(true);
                set_snackbar_toggle(true);
            } else if (response.res_code === 200){
                navigation.navigate('VerifyConfirmationCode', {
                    username: response.result.username,
                    email: response.result.email,
                    confirmation_code_token: response.accessToken,
                    user_id: response.result.user_id
                });
            }
        })
        .catch((err) => {
            set_is_loading(false);
            set_snackbar_msg('An error occured, please try again later');
            set_snackbar_err(true);
            set_snackbar_toggle(true);
        })
    }
};