import { backend_api } from '../backend_api';

// Verify confirmation code
export const verify_confirmation_code = async (confirmation_code, confirmation_code_token, set_is_disabled, set_loading_modal, set_type, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err, controller, navigation) => {
  set_is_disabled(true);
  set_snackbar_toggle(false);

  set_type(1);
  set_loading_modal(true);

  // Verify confirmation code
  await fetch(`${backend_api()}/api/user/verify-confirmation-code`, {
    method: "POST",
    signal: controller.signal,
    headers: {
      'Content-Type': 'application/json',
      "Authorization": `Bearer ${confirmation_code_token}`
    },
    body: JSON.stringify({
      confirmation_code: confirmation_code
    })
  })
  .then((res) => {
    return res.json();
  })
  .then(async (response) => {
    if (response.res_code === 455){
      set_snackbar_msg(response.err_msg);
      set_snackbar_err(true);
      set_snackbar_toggle(true);
      set_is_disabled(false);
      set_loading_modal(false);
    } else if (response.res_code === 401 || response.res_code === 500){
      set_snackbar_msg('An error occured, please try again later');
      set_snackbar_err(true);
      set_snackbar_toggle(true);
      set_is_disabled(false);
      set_loading_modal(false);
    } else if (response.res_code === 200){
      // Navigate to the reset password screen where the user can now reset their password
      navigation.navigate('ResetPassword', {
        user_id: response.result.user_id,
        confirmation_code: response.result.confirmation_code
      });
    }
  })
  .catch((err) => {
    if (err.name !== 'AbortError'){
      set_snackbar_msg('An error occured, please try again later');
      set_snackbar_err(true);
      set_snackbar_toggle(true);
      set_is_disabled(false);
      set_loading_modal(false);
    }
  })
};