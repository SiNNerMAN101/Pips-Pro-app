import { store } from '../../store/store';
import { set_reset_password } from '../../state/loginState';
import { backend_api } from '../backend_api';

// Reset the users password
export const reset_user_password = async (new_password, user_id, confirmation_code, navigation, is_loading, set_is_loading, controller, set_controller, snackbar_toggle, snackbar_msg, snackbar_err, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
  if (is_loading === false){
    set_is_loading(true);
    set_snackbar_toggle(false);

    // Make request to the backend to reset the users password
    await fetch(`${backend_api()}/api/user/reset-password`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        user_id: user_id,
        confirmation_code: confirmation_code,
        new_password: new_password
      })
    })
    .then((res) => {
      return res.json();
    })
    .then(async (response) => {
      set_is_loading(false);
      if (response.res_code === 455){
        set_snackbar_msg(response.err_msg);
        set_snackbar_err(true);
        set_snackbar_toggle(true);
      } else if (response.res_code === 401 || response.res_code === 500){
        set_snackbar_msg('An error occured, please try again later');
        set_snackbar_err(true);
        set_snackbar_toggle(true);
      } else if (response.res_code === 200){
        store.dispatch(set_reset_password({ value: true }));

        // Navigate to the login screen
        navigation.navigate('Login');
      }
    })
    .catch((err) => {
      set_is_loading(false);
      set_err_text('An error occured, please try again later');
      set_is_err(true);
    })
  }
};