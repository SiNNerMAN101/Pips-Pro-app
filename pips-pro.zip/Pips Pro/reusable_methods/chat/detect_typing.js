import { object, string } from 'yup';
import { store } from '../../store/store';
import { set_send_msg_btn_state } from '../../state/chat';

// Detect when the user is typing into the chat text input field
export const detect_typing = async (msg) => {
    // Yup Validation Object
    const yupObject = object().shape({
        msg: string().required('This field is required').test('there-must-be-no-empty-or-white-space', 'This field is required', (val) => {
            var validRegex = /^\s*$/;
            return !val.match(validRegex);
        }).min(1, 'Must be at least one character minimum').max(65536, 'max_error')
    });

    let check_validation = { value: null, error: [] }; // A variable to store the validation results after the validation process is complete

    // Validate the request parameter values using the Yup Object above
    const validate = async () => {
        try {
            await yupObject.validate({ msg: msg });
            check_validation.value = true;
        } catch (error) {
            check_validation.value = false;
            check_validation.error = error;
        }
    }

    try {
        await validate(); // Run the validate function above

        // Check if the validation was successful
        if (check_validation.value === true){ 
            store.dispatch(set_send_msg_btn_state({ value: true }));
        } else if (check_validation.value === false){
            store.dispatch(set_send_msg_btn_state({ value: false }));
        }
    } catch (error) {
        store.dispatch(set_send_msg_btn_state({ value: false }));
    }
};