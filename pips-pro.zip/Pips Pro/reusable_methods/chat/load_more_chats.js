import { load_more_recent_chats, set_page } from '../../state/chat';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';

// Load more recent/older chats as the user scrolls to the top of the flatlist
export const load_more_chats = async (controller, fetch_recent_chats, set_fetch_recent_chats, set_load_comp) => {
    if (fetch_recent_chats === true){
        set_fetch_recent_chats(false);

        // Make request to the backend to load more recent/older chats
        await fetch(`${backend_api()}/api/user/get-recent-chats`, {
            method: "POST",
            signal: controller.current.signal,
            headers: store.getState().login_state.logged_in === true ? {
                'Content-Type': 'application/json',
                "Authorization": `Bearer ${store.getState().login_state.accessToken}`
            } : { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                channel_id: store.getState().chat.channel_properties.channel_id,
                page: store.getState().chat.page
            })
        })
        .then((res) => {
            return res.json();
        })
        .then(async (response) => {
            if (response.res_code === 401 || response.res_code === 500 || response.res_code === 455 || response.res_code === 450){
                set_load_comp(true); // Keep displaying the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
            } else if (response.res_code === 525){
                set_load_comp(true); // Keep displaying the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
            } else if (response.res_code === 537){
                set_load_comp(true); // Keep displaying the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
            } else if (response.res_code === 583){
                set_load_comp(true); // Keep displaying the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
            } else if (response.res_code === 385){
                set_load_comp(true); // Keep displaying the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
            } else if (response.res_code === 265){
                set_load_comp(true); // Keep displaying the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
            } else if (response.res_code === 230){
                set_load_comp('complete'); // Disable the loader because there are no more recent chats to be fetched
                set_fetch_recent_chats(false); // Don't allow the user to continue fetching recent chats
            } else if (response.res_code === 200){
                set_load_comp(false); // Disable the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats

                store.dispatch(load_more_recent_chats({ chats: response.result.chats })); // Display the recent chats that have been fetched
                store.dispatch(set_page({ value: response.result.page }));
            } else {
                set_load_comp(true); // Keep displaying the loader
                set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
            }
        })
        .catch((err) => {
            set_load_comp(true); // Keep displaying the loader
            set_fetch_recent_chats(true); // Allow the user to continue fetching recent chats
        })
    } else {
        set_load_comp(false);
    }
};