import { set_reply_chat, set_reply_to_chat_id, update_messages } from "../../state/chat";
import { store } from "../../store/store";
import ShortUniqueId from "short-unique-id";

// Send chat messages
export const send_chat = async (getSocket, msg, onChangeText, chat_type) => {
    let reply_chat = store.getState().chat.reply_chat; // Reply chat state property
    let reply_to_chat_id = store.getState().chat.reply_to_chat_id; // The ID of the chat that is being replied to
    let channel_properties = store.getState().chat.channel_properties; // The channel properties

    if (chat_type === 1){ // Text based chat
        let trimmed_msg = msg.trim();
        const { randomUUID } = new ShortUniqueId({ length: 16 }); // Generate a random UUID for the users chat
        let chat_uuid = randomUUID(); // Random UUID for the chat
        let new_utc_date_string = new Date().toISOString();

        try {
            let new_chat = { chat_id: null, user_id: store.getState().login_state.user_details.user_id, channel_id: store.getState().chat.channel_properties.channel_id, chat: trimmed_msg, chat_type: 1, reply_available: reply_chat, reply_data: { user_id: store.getState().chat.reply_data.user_id, username: store.getState().chat.reply_data.username, color_code: store.getState().chat.reply_data.color_code, channel_id: store.getState().chat.channel_properties.channel_id, chat: store.getState().chat.reply_data.chat, chat_type: store.getState().chat.reply_data.chat_type }, username: store.getState().login_state.user_details.username, profile_image: store.getState().login_state.user_details.profile_image, color_code: store.getState().login_state.user_details.color_code, uuid: chat_uuid, sent_msg: false, createdAt: new_utc_date_string };
            store.dispatch(update_messages({ data: new_chat }));
            getSocket().emit('send_message', { chat_type: 1, uuid: chat_uuid, channel_id: channel_properties.channel_id, reply_to_chat: reply_chat, chat_text: trimmed_msg, reply_to_chat_id: reply_to_chat_id });
            store.dispatch(set_reply_chat({ value: false }));
            store.dispatch(set_reply_to_chat_id({ value: 0 }));
            onChangeText('');
        } catch (error) {
            // Error sending chat
        }
    } else if (chat_type === 2){ // Trade idea chat
        // Nothing here yet
    }
};