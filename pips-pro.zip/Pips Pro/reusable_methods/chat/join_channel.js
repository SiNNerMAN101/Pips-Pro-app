import { add_new_channel, set_new_channel_created } from '../../state/channels';
import { add_user_to_channel } from '../../state/chat';
import { store } from '../../store/store';
import { backend_api } from '../backend_api';

// Add the user to the channel
export const user_join_channel = async (join_channel_loading, controller, flatListRef, connectSocket, getSocket, set_join_channel_loading, set_snackbar_toggle, set_snackbar_msg, set_snackbar_err) => {
    if (join_channel_loading === true){
        // Do nothing
    } else {
        if (store.getState().chat.channel_properties.channel_type === 'public'){
            set_join_channel_loading(true);
            
            // Make request to the backend to join a user to an existing channel
            await fetch(`${backend_api()}/api/user/join-channel`, {
                method: "POST",
                signal: controller.current.signal,
                headers: store.getState().login_state.logged_in === true ? {
                    'Content-Type': 'application/json',
                    "Authorization": `Bearer ${store.getState().login_state.accessToken}`
                } : { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    channel_id: store.getState().chat.channel_properties.channel_id,
                    page: store.getState().chat.page
                })
            })
            .then((res) => {
                return res.json();
            })
            .then(async (response) => {
                set_join_channel_loading(false);

                if (response.res_code === 200){
                    store.dispatch(add_new_channel({ new_channel: response.result }));
                    store.dispatch(set_new_channel_created({ value: true }));
                    store.dispatch(add_user_to_channel({}));
                } else if (response.res_code === 401 || response.res_code === 500){
                    set_snackbar_msg('An error just occured');
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                } else if (response.res_code === 404 || response.res_code === 435){
                    set_snackbar_msg(response.err_msg);
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                } else {
                    set_snackbar_msg('An error just occured');
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                }
            })
            .catch((err) => {
                set_join_channel_loading(false);

                if (err.name !== 'AbortError') {
                    set_snackbar_msg('An error just occured');
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                }
            })
        } else if (store.getState().chat.channel_properties.channel_type === 'private'){
            
        }
    }
};