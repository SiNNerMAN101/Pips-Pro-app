import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { set_chat_state, set_messages, set_page } from "../../state/chat";

// Get the recent chats for the channel
export const refresh_chats = async (refresh_controller, setRefreshing, connectSocket, flatListRef) => {
    setRefreshing(true); // Enable refresh spinner animation

    // Make request to the backend to get the recent chats for the channel
    await fetch(`${backend_api()}/api/user/get-recent-chats`, {
        method: "POST",
        signal: refresh_controller.current.signal,
        headers: store.getState().login_state.logged_in === true ? {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        } : { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            channel_id: store.getState().chat.channel_properties.channel_id,
            page: store.getState().chat.page
        })
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        refresh_controller.current = new AbortController();

        setRefreshing(false); // Disable refresh spinner animation

        if (response.res_code === 401 || response.res_code === 500 || response.res_code === 455 || response.res_code === 450){
            store.dispatch(set_chat_state({ value: false }));
        } else if (response.res_code === 525){
            store.dispatch(set_chat_state({ value: 'channel_unavailable' }));
        } else if (response.res_code === 537){
            store.dispatch(set_chat_state({ value: 'join_private_channel' }));
        } else if (response.res_code === 583){
            store.dispatch(set_chat_state({ value: 'no_access_to_private_channel' }));
        } else if (response.res_code === 385){
            store.dispatch(set_chat_state({ value: 'initial_payment_incomplete' }));
        } else if (response.res_code === 265){
            store.dispatch(set_chat_state({ value: 'subscription_pending' }));
        } else if (response.res_code === 230){
            store.dispatch(set_chat_state({ value: 'no_chats' }));
            connectSocket(store.getState().chat.channel_properties.channel_id, flatListRef);
        } else if (response.res_code === 200){
            store.dispatch(set_messages({ data: response.result.chats }));
            store.dispatch(set_page({ value: response.result.page }));
            store.dispatch(set_chat_state({ value: true }));
            connectSocket(store.getState().chat.channel_properties.channel_id, flatListRef);
        } else {
            store.dispatch(set_chat_state({ value: false }));
        }
    })
    .catch((err) => {
        refresh_controller.current = new AbortController();

        setRefreshing(false); // Disable refresh spinner animation

        if (err.name !== 'AbortError') {
            store.dispatch(set_chat_state({ value: false }));
        }
    })
};