import { store } from "../../store/store";
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SplashScreen from 'expo-splash-screen';
import { set_accessToken, set_darkmode, set_logged_in, set_user_details } from "../../state/loginState";
import { set_active_watchlist_id } from "../../state/watchListState";
import { get_recent_chats } from "./get_recent_chats";

// Run this method when the user enters the chat screen
export const enter_screen = async (connectSocket, getSocket, controller, colorScheme, flatListRef) => {
    /*
        Handle darkmode
    */
    try {
        const darkmode = await AsyncStorage.getItem('darkmode');

        if (darkmode !== null) {
            let parsed_json = JSON.parse(darkmode);
            if (parsed_json.value === true || parsed_json.value === false){
                store.dispatch(set_darkmode({ value: parsed_json.value }));
            } else {
                if (colorScheme === 'dark'){
                    await AsyncStorage.setItem('darkmode', JSON.stringify({ value: true }));
                    store.dispatch(set_darkmode({ value: true }));
                } else {
                    await AsyncStorage.setItem('darkmode', JSON.stringify({ value: false }));
                    store.dispatch(set_darkmode({ value: false }));
                } 
            }
        } else {
            if (colorScheme === 'dark'){
                await AsyncStorage.setItem('darkmode', JSON.stringify({ value: true }));
                store.dispatch(set_darkmode({ value: true }));
            } else {
                await AsyncStorage.setItem('darkmode', JSON.stringify({ value: false }));
                store.dispatch(set_darkmode({ value: false }));
            } 
        }
    } catch (e) {
        // error reading value
        store.dispatch(set_darkmode({ value: true }));  
    }

    // Check if the user is logged in or not
    if (store.getState().login_state.logged_in === true){
        await get_recent_chats(connectSocket, getSocket, store.getState().login_state.accessToken, controller, flatListRef); // Get users channels
    } else {
        const auth_token = await SecureStore.getItemAsync('auth_token'); // Get auth token if available
        let is_user_details_stored = false;
        let user_details_data = { 
            username: '',
            email: '',
            user_id: null,
            profile_image: null,
            color_code: '#FFFFFF',
            premium_account: false
        }

        try {
            const user_details = await AsyncStorage.getItem('user_details');

            if (user_details !== null) {
                is_user_details_stored = true;
                user_details_data = JSON.parse(user_details);
            } else {
                is_user_details_stored = false;    
            }
        } catch (e) {
            // error reading value
            is_user_details_stored = false;
        }

        try {
            const active_watchlist_id = await AsyncStorage.getItem('active_watchlist_id');
    
            if (active_watchlist_id !== null) {
                let parsed_json = JSON.parse(active_watchlist_id);
                store.dispatch(set_active_watchlist_id({ value: parsed_json.value }));
            } else {
                await AsyncStorage.setItem('active_watchlist_id', JSON.stringify({ value: store.getState().watch_list_state.active_watchlist_id }));
            }
        } catch (e) {
            // error reading value
        }

        // Check if auth token and user details are stored locally on the user device
        if (auth_token && is_user_details_stored === true){
            store.dispatch(set_accessToken({ token: auth_token }));
            store.dispatch(set_user_details({ details: user_details_data }));
            store.dispatch(set_logged_in({ value: true }));

            setTimeout(async () => {
                await SplashScreen.hideAsync(); // Hide the splash screen once it is determined that the user is not logged in
            }, 800);

            await get_recent_chats(connectSocket, getSocket, auth_token, controller, flatListRef); // Get users channels
        } else {
            setTimeout(async () => {
                await SplashScreen.hideAsync(); // Hide the splash screen once it is determined that the user is not logged in
            }, 800);

            await get_recent_chats(connectSocket, getSocket, store.getState().login_state.accessToken, controller, flatListRef); // Get users channels
        }
    }
};