import { store } from "../../../store/store";
import {ActionSheetIOS, Platform} from 'react-native';
import * as Haptics from 'expo-haptics';

// The menu sheet type six
export const type_six = (chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller) => {
    // Trigger haptic feedback
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (Platform.OS === 'android'){
        const options = ['Reply', 'Cancel'];
        const destructiveButtonIndex = 1;
        const cancelButtonIndex = 1;
        const userInterfaceStyle = store.getState().login_state.darkmode === true ? "dark" : "light";
    
        showActionSheetWithOptions({
            options,
            cancelButtonIndex,
            destructiveButtonIndex,
            userInterfaceStyle
        }, (selectedIndex) => {
          switch (selectedIndex) {
            case 0:
                // Reply
                break;
            case destructiveButtonIndex:
              // Canceled
        }}); 
    } else if (Platform.OS === 'ios'){
        ActionSheetIOS.showActionSheetWithOptions(
            {
                options: ['Reply', 'Cancel'],
                destructiveButtonIndex: 1,
                cancelButtonIndex: 1,
                userInterfaceStyle: store.getState().login_state.darkmode === true ? "dark" : "light"
            },
            async buttonIndex => {
                if (buttonIndex === 0) {
                    // Reply
                } else if (buttonIndex === 2) {
                    // Cancel
                }
            },
        )
    }
};