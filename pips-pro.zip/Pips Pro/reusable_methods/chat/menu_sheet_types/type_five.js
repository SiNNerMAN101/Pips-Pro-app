import { store } from "../../../store/store";
import {ActionSheetIOS, Platform} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { modify_reply_data } from "../../../state/chat";
import * as Haptics from 'expo-haptics';

// The menu sheet type five
export const type_five = (chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller) => {
    // Trigger haptic feedback
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (Platform.OS === 'android'){
        const options = ['Copy', 'Reply', 'Cancel'];
        const destructiveButtonIndex = 2;
        const cancelButtonIndex = 2;
        const userInterfaceStyle = store.getState().login_state.darkmode === true ? "dark" : "light";
    
        showActionSheetWithOptions({
            options,
            cancelButtonIndex,
            destructiveButtonIndex,
            userInterfaceStyle
        }, (selectedIndex) => {
          switch (selectedIndex) {
            case 0:
                // Copy
                let copy_to_clipboard = async () => {
                    await Clipboard.setStringAsync(chat['chat']);
                    set_snackbar_msg('Chat copied');
                    set_snackbar_err(false);
                    set_snackbar_toggle(true);
                }

                copy_to_clipboard();
                break;
            case 1:
                // Reply
                let data = { chat: chat['chat'], chat_id: chat['chat_id'], chat_type: chat['chat_type'], color_code: chat['color_code'], user_id: chat['user_id'], username: chat['username'] };
                store.dispatch(modify_reply_data({ data: data, value: true, id: chat['chat_id'] }));
                break;
            case destructiveButtonIndex:
              // Canceled
        }}); 
    } else if (Platform.OS === 'ios'){
        ActionSheetIOS.showActionSheetWithOptions(
            {
                options: ['Copy', 'Reply', 'Cancel'],
                destructiveButtonIndex: 2,
                cancelButtonIndex: 2,
                userInterfaceStyle: store.getState().login_state.darkmode === true ? "dark" : "light"
            },
            async buttonIndex => {
                if (buttonIndex === 0) {
                    // Copy
                    await Clipboard.setStringAsync(chat['chat']);
                    set_snackbar_msg('Chat copied');
                    set_snackbar_err(false);
                    set_snackbar_toggle(true);
                } else if (buttonIndex === 1) {
                    // Reply
                    let data = { chat: chat['chat'], chat_id: chat['chat_id'], chat_type: chat['chat_type'], color_code: chat['color_code'], user_id: chat['user_id'], username: chat['username'] };
                    store.dispatch(modify_reply_data({ data: data, value: true, id: chat['chat_id'] }));
                } else if (buttonIndex === 2) {
                    // Cancel
                }
            },
        )
    }
};