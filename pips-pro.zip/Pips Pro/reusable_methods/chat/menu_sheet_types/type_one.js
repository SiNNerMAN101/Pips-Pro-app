import { store } from "../../../store/store";
import {ActionSheetIOS, Platform} from 'react-native';
import { delete_chat, modify_reply_data, set_reply_chat, set_reply_to_chat_id } from "../../../state/chat";
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import { deleted_chat_channel_update } from "../../../state/channels";

// The menu sheet type one
export const type_one = (chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket) => {
    // Trigger haptic feedback
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (Platform.OS === 'android'){
        const options = ['Reply', 'Copy', 'Delete', 'Cancel'];
        const destructiveButtonIndex = 3;
        const cancelButtonIndex = 3;
        const userInterfaceStyle = store.getState().login_state.darkmode === true ? "dark" : "light";
    
        showActionSheetWithOptions({
            options,
            cancelButtonIndex,
            destructiveButtonIndex,
            userInterfaceStyle
        }, (selectedIndex) => {
          switch (selectedIndex) {
            case 0:
                // Reply
                let data = { chat: chat['chat'], chat_id: chat['chat_id'], chat_type: chat['chat_type'], color_code: chat['color_code'], user_id: chat['user_id'], username: chat['username'] };
                store.dispatch(modify_reply_data({ data: data, value: true, id: chat['chat_id'] }));
                break;
            case 1:
                // Copy
                let copy_to_clipboard = async () => {
                    await Clipboard.setStringAsync(chat['chat']);
                    set_snackbar_msg('Chat copied');
                    set_snackbar_err(false);
                    set_snackbar_toggle(true);
                }

                copy_to_clipboard();
                break;
            case 2:
                // Delete
                store.dispatch(delete_chat({ value: chat['id'] }));
                store.dispatch(deleted_chat_channel_update({ chat_to_delete: chat, logged_in: store.getState().login_state.logged_in }));
                getSocket().emit('delete_chat', { chat_id: chat['chat_id'], channel_id: chat['channel_id'] });
                store.dispatch(set_reply_chat({ value: false }));
                store.dispatch(set_reply_to_chat_id({ value: 0 }));
                set_snackbar_msg('Chat deleted');
                set_snackbar_err(false);
                set_snackbar_toggle(true);
                break;
            case destructiveButtonIndex:
              // Canceled
        }}); 
    } else if (Platform.OS === 'ios'){
        ActionSheetIOS.showActionSheetWithOptions(
            {
                options: ['Reply', 'Copy', 'Delete', 'Cancel'],
                destructiveButtonIndex: 3,
                cancelButtonIndex: 3,
                userInterfaceStyle: store.getState().login_state.darkmode === true ? "dark" : "light"
            },
            async buttonIndex => {
                if (buttonIndex === 0) {
                    // Reply
                    let data = { chat: chat['chat'], chat_id: chat['chat_id'], chat_type: chat['chat_type'], color_code: chat['color_code'], user_id: chat['user_id'], username: chat['username'] };
                    store.dispatch(modify_reply_data({ data: data, value: true, id: chat['chat_id'] }));
                } else if (buttonIndex === 1) {
                    // Copy
                    await Clipboard.setStringAsync(chat['chat']);
                    set_snackbar_msg('Chat copied');
                    set_snackbar_err(false);
                    set_snackbar_toggle(true);
                } else if (buttonIndex === 2) {
                    // Delete
                    store.dispatch(delete_chat({ value: chat['id'] }));
                    store.dispatch(deleted_chat_channel_update({ chat_to_delete: chat, logged_in: store.getState().login_state.logged_in }));
                    getSocket().emit('delete_chat', { chat_id: chat['chat_id'], channel_id: chat['channel_id'] });
                    store.dispatch(set_reply_chat({ value: false }));
                    store.dispatch(set_reply_to_chat_id({ value: 0 }));
                    set_snackbar_msg('Chat deleted');
                    set_snackbar_err(false);
                    set_snackbar_toggle(true);
                } else if (buttonIndex === 3) {
                    // Cancel
                }
            },
        )
    }
};