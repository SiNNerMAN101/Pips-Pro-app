import { store } from "../../../store/store";
import {ActionSheetIOS, Platform} from 'react-native';
import * as Haptics from 'expo-haptics';
import { delete_chat, set_reply_chat, set_reply_to_chat_id } from "../../../state/chat";
import { deleted_chat_channel_update } from "../../../state/channels";

// The menu sheet type two
export const type_two = (chat, showActionSheetWithOptions, snackbar_toggle, set_snackbar_toggle, snackbar_msg, set_snackbar_msg, snackbar_err, set_snackbar_err, set_delete_chat_loading_dialog, delete_chat_controller, getSocket) => {
    // Trigger haptic feedback
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (Platform.OS === 'android'){
        const options = ['Reply', 'Delete', 'Cancel'];
        const destructiveButtonIndex = 2;
        const cancelButtonIndex = 2;
        const userInterfaceStyle = store.getState().login_state.darkmode === true ? "dark" : "light";
    
        showActionSheetWithOptions({
            options,
            cancelButtonIndex,
            destructiveButtonIndex,
            userInterfaceStyle
        }, (selectedIndex) => {
          switch (selectedIndex) {
            case 0:
                // Reply
                break;
            case 1:
                // Delete
                store.dispatch(delete_chat({ value: chat['id'] }));
                store.dispatch(deleted_chat_channel_update({ chat_to_delete: chat, logged_in: store.getState().login_state.logged_in }));
                getSocket().emit('delete_chat', { chat_id: chat['chat_id'], channel_id: chat['channel_id'] });
                store.dispatch(set_reply_chat({ value: false }));
                store.dispatch(set_reply_to_chat_id({ value: 0 }));
                set_snackbar_msg('Chat deleted');
                set_snackbar_err(false);
                set_snackbar_toggle(true);
                break;
            case destructiveButtonIndex:
              // Canceled
        }}); 
    } else if (Platform.OS === 'ios'){
        ActionSheetIOS.showActionSheetWithOptions(
            {
                options: ['Reply', 'Delete', 'Cancel'],
                destructiveButtonIndex: 2,
                cancelButtonIndex: 2,
                userInterfaceStyle: store.getState().login_state.darkmode === true ? "dark" : "light"
            },
            async buttonIndex => {
                if (buttonIndex === 0) {
                    // Reply
                } else if (buttonIndex === 1) {
                    // Delete
                    store.dispatch(delete_chat({ value: chat['id'] }));
                    store.dispatch(deleted_chat_channel_update({ chat_to_delete: chat, logged_in: store.getState().login_state.logged_in }));
                    getSocket().emit('delete_chat', { chat_id: chat['chat_id'], channel_id: chat['channel_id'] });
                    store.dispatch(set_reply_chat({ value: false }));
                    store.dispatch(set_reply_to_chat_id({ value: 0 }));
                    set_snackbar_msg('Chat deleted');
                    set_snackbar_err(false);
                    set_snackbar_toggle(true);
                } else if (buttonIndex === 2) {
                    // Cancel
                }
            },
        )
    }
};