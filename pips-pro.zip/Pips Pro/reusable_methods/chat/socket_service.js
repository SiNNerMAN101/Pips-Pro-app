import io from 'socket.io-client';
import { websocket_api } from '../websocket_api';
import { store } from '../../store/store';
import { new_chat_received, set_chat_state, set_new_chat_notif_sound, set_no_of_new_chats_at_the_moment, set_no_of_new_chats_for_fab, update_deleted_chat, update_my_message } from '../../state/chat';
import { Audio } from 'expo-av';
import { deleted_chat_channel_update, remove_channel } from '../../state/channels';

let socket;

export const connectSocket = (channel_id, flatListRef) => {
    if (!socket) {
        socket = io(websocket_api(2), {
            extraHeaders: {
                Authorization: `Bearer ${store.getState().login_state.accessToken}`
            }
        })

        // Detect when the connection is established
        socket.on('connect', () => {
            // Get user's timezone offset
            const getUserTimezoneOffset = () => {
                return new Date().getTimezoneOffset();
            };

            const offset = getUserTimezoneOffset();

            // Trigger websocket server to connect user to the room created for the particular channel to start receiving chats 
            socket.emit('connect_to_channel', { channel_id: channel_id, time_offset: offset });
            socket.emit('mark_chats_as_read', { channel_id: channel_id }); // Mark all the chats for a channel as read for a user when they have viewed the chats
        });

        // Detect when the socket connection is disconnected
        socket.on('disconnect', () => {
            //set_can_send_message(false);
        });

        /* 
            When a chat is deleted from any channel that the user is a part of, 
            update the my channels list by displaying to the user that the recent chat for that channel has just been deleted
        */
        socket.on('chat_deleted', (data) => {
            store.dispatch(deleted_chat_channel_update({ chat_to_delete: data, logged_in: store.getState().login_state.logged_in }));
            store.dispatch(update_deleted_chat({ chat_to_delete: data }));
        });

        // Check if the user is not logged in
        socket.on('user_not_logged_in', (data) => {
            // nothing
        });

        // Check for errors when sending messages
        socket.on('send_msg_error', (data) => {
            if (data['error'] === 'channel_deleted'){ // This error is logged if the current channel has been deleted by it's creator or is just unavailable at the moment
                store.dispatch(remove_channel({ channel_id: data['channel_id'], state: 'delete_channel' }));
                store.dispatch(set_chat_state({ value: 'channel_unavailable' }));
                disconnectSocket();
            } else if (data['error'] === 'non_channel_member'){ // This error is logged if the user is no longer a member of the current channel
                store.dispatch(remove_channel({ channel_id: data['channel_id'], state: 'non_channel_member' }));
                store.dispatch(set_chat_state({ value: 'non_channel_member' }));
                disconnectSocket();
            }
        });

        // Receive new messages sent to the channel by other users
        socket.on('new_msg', async (data) => {
            socket.emit('mark_chats_as_read', { channel_id: data['channel_id'] }); // Mark all the chats for a channel as read for a user when they have viewed the chats
            store.dispatch(new_chat_received({ data: data }));
            store.dispatch(set_chat_state({ value: true }));
            store.dispatch(set_no_of_new_chats_for_fab({ value: store.getState().chat.no_of_new_chats_for_fab + 1 }));

            // If the user is at the bottom of the chats, then apply the scrolling animation for the new chat
            if (store.getState().chat.scrolled_away_from_bottom !== true){
                flatListRef.current?.scrollToOffset({ offset: 90, animated: true });
                setTimeout(() => {
                    flatListRef.current?.scrollToOffset({ animated: true, offset: 0 });
                }, 150);
            }

            // Check if the no of new chats at the moment is up to 5 or more
            if (store.getState().chat.no_of_new_chats_at_the_moment >= 5){
                // Play the notification sound to show that new messages are available
                try {
                    const { sound } = await Audio.Sound.createAsync(require('../../assets/sounds/msg_received_notif.mp3'));
                    await sound.playAsync(); // Play chat received audio
                } catch (error) {}
                store.dispatch(set_no_of_new_chats_at_the_moment({ value: 0 }));
            } else {
                // Since the new chats at the moment isn't up to 5 or more, increment the value
                store.dispatch(set_no_of_new_chats_at_the_moment({ value: store.getState().chat.no_of_new_chats_at_the_moment + 1 }));
            }
        });

        /*
            When the user sends a chat, we first create a dummy chat to display to the user while the actual chat is sent to the sockets server for proccessing.
            When the chat has been processed on the server successfully, we then replace the dummy chat with the proccessed chat data that is returned from the sockets server.
        */
        socket.on('new_msg_from_me', async (data) => {
            store.dispatch(update_my_message({ data: data }));
            store.dispatch(set_chat_state({ value: true }));
            flatListRef.current?.scrollToOffset({ animated: true, offset: 0 });

            try {
                const { sound } = await Audio.Sound.createAsync(require('../../assets/sounds/msg_sent_notif.mp3'));
                await sound.playAsync(); // Play chat sent audio
            } catch (error) {}
        });
    }
};

export const getSocket = () => { return socket };

export const disconnectSocket = () => {
    if (socket) {
        socket.disconnect();
        socket = null;
    }
};