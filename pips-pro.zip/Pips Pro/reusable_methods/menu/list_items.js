// A list of all items in the menu screen
export const list_items = () => {
    return [
        {
          item_name: 'Sign in',
          icon_name: 'user',
          icon_category: 'feather'
        },
        {
          item_name: 'Dark mode',
          icon_name: 'moon',
          icon_category: 'feather'
        },
        {
          item_name: 'News',
          icon_name: 'newspaper-outline',
          icon_category: 'ionicons'
        },
        {
          item_name: 'Rate us',
          icon_name: 'message-star-outline',
          icon_category: 'materialcommunityicons'
        },
        {
          item_name: 'About',
          icon_name: 'info-outline',
          icon_category: 'materialicons'
        },
        {
          item_name: 'Sign out',
          icon_name: 'logout',
          icon_category: 'materialicons'
        }
    ];
};