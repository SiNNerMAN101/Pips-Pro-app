// Handle click events from the items list in the menu
export const handle_item_click = async (item_name, navigation) => {
  if (item_name === 'Sign in'){
    navigation.navigate('Login'); // Navigate to the sign in screen
  } else if (item_name === 'News'){
    navigation.navigate('News'); // Navigate to the news screen
  } else if (item_name === 'Sign out'){
    navigation.navigate('LogoutModal');
  }
};