import { store } from "../../store/store";
import { backend_api } from "../backend_api";
import { reset_data } from "../../state/loginState";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from 'expo-secure-store';
import { reset_channels_state } from "../../state/channels";
import { set_active_watchlist_id, set_all_watchlists_state, set_watchlist_state } from "../../state/watchListState";
import { reset_chat_data } from "../../state/chat";

// Log the user out of the app
export const logout = async (navigation) => {
    // Make request to the backend to log the user out of the app
    await fetch(`${backend_api()}/api/user/logout`, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${store.getState().login_state.accessToken}`
        }
    })
    .then((res) => {
        return res.json();
    })
    .then(async (response) => {
        await SecureStore.deleteItemAsync('auth_token'); // Remove the user auth token from secure storage

        try {
            await AsyncStorage.removeItem('user_details'); // Remove the users details from async storage
            await AsyncStorage.removeItem('active_watchlist_id'); // Remove the active watchlist ID
        } catch (e) {
            // saving error
        }

        store.dispatch(reset_data({}));
        store.dispatch(set_all_watchlists_state({ value: 'loading' }));
        store.dispatch(set_watchlist_state({ value: 'loading' }));
        store.dispatch(set_active_watchlist_id({ value: null }));
        store.dispatch(reset_channels_state({}));
        navigation.navigate('WatchList');
    })
    .catch(async (err) => {
        await SecureStore.deleteItemAsync('auth_token'); // Remove the user auth token from secure storage

        try {
            await AsyncStorage.removeItem('user_details'); // Remove the users details from async storage
            await AsyncStorage.removeItem('active_watchlist_id'); // Remove the active watchlist ID
        } catch (e) {
            // saving error
        }

        store.dispatch(reset_data({}));
        store.dispatch(reset_chat_data({}));
        store.dispatch(set_all_watchlists_state({ value: 'loading' }));
        store.dispatch(set_watchlist_state({ value: 'loading' }));
        store.dispatch(set_active_watchlist_id({ value: null }));
        store.dispatch(reset_channels_state({}));
        navigation.navigate('WatchList');
    })
};