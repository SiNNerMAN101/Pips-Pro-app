# Pips Pro

Lightweight trading analysis app. TradingView power without the bloat.

## Why Pips Pro?

TradingView set the standard for charting. Pips Pro keeps the essentials—real-time data, clean charts, smart alerts—and drops the complexity.

| TradingView | Pips Pro |
|-------------|----------|
| Heavy, desktop-first | Fast, mobile-native |
| Pine Script required | Natural language alerts |
| All assets, all features | Forex & crypto focused |

## Features

- *Instant charts* – Load in under 1s on slow connections
- *Smart watchlists* – Auto-sort by volatility, volume, pip moves
- *Text alerts* – "Alert me when EUR/USD breaks 1.0850"
- *Session overlays* – London, NY, Tokyo on one chart
- *Risk tools* – Built-in pip calc & position sizing

## Stack

React Native | WebSocket | Canvas | Node.js

## Roadmap

- Broker API integration
- Drawing tools (Fib, Gann)
- Desktop web version

---

Built by traders. Not affiliated with TradingView.