import { useDispatch, useSelector } from 'react-redux';
import WatchList from '../screens/watchlist';
import Chart from '../screens/chart';
import Channels from '../screens/channels';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import Menu from '../screens/menu';
import { Platform, Text, TouchableOpacity } from 'react-native';
import { bottomTabBarStyles } from '../styles/bottom_tab_bar';
import { useCallback, useMemo, useRef, useState } from 'react';
import ChannelsHeaderRight from '../components/channels/header/ChannelsHeaderRight';
import { headerStyles } from '../styles/header_styles';
import { watchList } from '../styles/watchlist';
import { Image } from 'expo-image';
import * as ScreenOrientation from 'expo-screen-orientation';
import { MenuBottomSheet } from '../components/chart/MenuBottomSheet';
import { set_btm_sheet_index, set_enable_btm_sheet } from '../state/chart';
import Community from '../screens/community';
import News from '../screens/news';

const Tab = createBottomTabNavigator();

export default function Tabs() {
    const is_darkmode = useSelector((state) => state.login_state.darkmode);
    const watchlist_state = useSelector((state) => state.watch_list_state.watchlist_state); // Current watchlist state
    const [orientation, setOrientation] = useState(1);
    const dispatch = useDispatch();
    const user_details = useSelector((state) => state.login_state.user_details); // User current account details
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // User current logged in state

    // Set up an event listener to track orientation changes
    ScreenOrientation.addOrientationChangeListener((event) => {
        setOrientation(event.orientationInfo.orientation);
    });

    // Memoize the styles to avoid recalculating them on each render
    const bottom_tabbar_styles = useMemo(() => bottomTabBarStyles(Platform, is_darkmode, orientation), [Platform, is_darkmode, orientation]);
    const header_styles = useMemo(() => headerStyles(is_darkmode), [is_darkmode]);

    // Bottomsheet ref
    const bottomSheetRef = useRef(null);

    // Handle changes in the bottomsheet
    const handleSheetChanges = useCallback((index) => {
        if (index === -1){ // When the bottom sheet closes
            dispatch(set_enable_btm_sheet({ value: false }));
            dispatch(set_btm_sheet_index({ value: -1 }));
        }
    }, []);

    return (
        <>
            <Tab.Navigator initialRouteName="WatchList" screenOptions={{ headerShown: false, tabBarShowLabel: true, tabBarHideOnKeyboard: true, contentStyle: bottom_tabbar_styles.tabbar_container, tabBarStyle: bottom_tabbar_styles.tab_bar_style }}>
                <Tab.Screen name="WatchList" options={({ navigation }) => ({ headerShown: true, headerTitleAlign: 'center', headerLeft: () => (
                    <TouchableOpacity onPress={() => navigation.navigate('AllWatchLists')} style={watchList.left_btn}>
                        <Ionicons name="list-outline" size={31} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ), headerRight: () => (
                    <TouchableOpacity disabled={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? true : false} onPress={() => navigation.navigate('AddSymbolModal')} style={watchList.right_btn}>
                        <Ionicons name="add-outline" size={31} color={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? '#5a5a5a' : is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ), headerStyle: header_styles.header_appearance, headerShadowVisible: false, headerTitle: () => (
                    <TouchableOpacity> 
                        {/* <Text style={[watchList.header_title, { color: is_darkmode === true ? '#ffffff' : '#000000' }]}>{active_watchlist_name}</Text> */}
                        <Image
                            style={watchList.logo}
                            source={require('../assets/logo-black.png')}
                            contentFit="cover"
                        />
                    </TouchableOpacity>
                ), tabBarLabelStyle: bottom_tabbar_styles.tab_bar_label_style, tabBarActiveTintColor: '#f19200', tabBarInactiveTintColor: (is_darkmode === true) ? '#ffffff' : '#000000', tabBarLabel: 'Watchlist', tabBarIcon: ({focused, color, size }) => (<Ionicons name={focused === true ? 'star' : 'star-outline'} color={color} size={24} />) })} component={WatchList} />
                
                <Tab.Screen name="Chart" options={{ tabBarLabelStyle: bottom_tabbar_styles.tab_bar_label_style, tabBarActiveTintColor: '#f19200', tabBarInactiveTintColor: (is_darkmode === true) ? '#ffffff' : '#000000', tabBarLabel: 'Chart', tabBarIcon: ({focused, color, size }) => (<Ionicons name={focused === true ? 'bar-chart' : 'bar-chart-outline'} color={color} size={24} />) }} component={Chart} />
                
                <Tab.Screen name="Community" options={({ navigation }) => ({ headerShown: true, headerTitleAlign: 'center', headerLeft: null, headerRight: () => (
                    <TouchableOpacity disabled={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? true : false} onPress={() => navigation.navigate('AddSymbolModal')} style={watchList.right_btn}>
                        <Ionicons name="search-outline" size={24} color={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? '#5a5a5a' : is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ), headerStyle: header_styles.header_appearance, headerShadowVisible: false, headerTitle: 'Community', headerTitleStyle: { color: is_darkmode === true ? '#ffffff' : '#000000' }, headerShadowVisible: false, headerStyle: { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }, headerTintColor: is_darkmode === true ? '#ffffff' : '#000000',   tabBarLabelStyle: bottom_tabbar_styles.tab_bar_label_style, tabBarActiveTintColor: '#f19200', tabBarInactiveTintColor: (is_darkmode === true) ? '#ffffff' : '#000000', tabBarLabel: 'Community', tabBarIcon: ({focused, color, size }) => (<Ionicons name={focused === true ? 'people' : 'people-outline'} color={color} size={24} />) })} component={Community} />

                <Tab.Screen name="News" options={({ navigation }) => ({ headerShown: true, headerTitleAlign: 'center', headerLeft: null, headerRight: () => (
                    <TouchableOpacity disabled={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? true : false} onPress={() => navigation.navigate('AddSymbolModal')} style={watchList.right_btn}>
                        <Ionicons name="search-outline" size={24} color={watchlist_state === 'loading' || watchlist_state === 'deleted' || watchlist_state === 'error' ? '#5a5a5a' : is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ), headerStyle: header_styles.header_appearance, headerShadowVisible: false, headerTitle: 'News', headerTitleStyle: { color: is_darkmode === true ? '#ffffff' : '#000000' }, headerShadowVisible: false, headerStyle: { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }, headerTintColor: is_darkmode === true ? '#ffffff' : '#000000',   tabBarLabelStyle: bottom_tabbar_styles.tab_bar_label_style, tabBarActiveTintColor: '#f19200', tabBarInactiveTintColor: (is_darkmode === true) ? '#ffffff' : '#000000', tabBarLabel: 'News', tabBarIcon: ({focused, color, size }) => (<Ionicons name={focused === true ? 'newspaper' : 'newspaper-outline'} color={color} size={24} />) })} component={News} />
                
                <Tab.Screen name="Menu" options={{ headerShown: true, headerLeft: () => (
                    <Text style={header_styles.title_left}>Menu</Text>
                ), headerStyle: header_styles.header_appearance, headerShadowVisible: false, headerTitle: '', tabBarLabelStyle: bottom_tabbar_styles.tab_bar_label_style, tabBarActiveTintColor: '#f19200', tabBarInactiveTintColor: (is_darkmode === true) ? '#ffffff' : '#000000', tabBarLabel: 'Menu', tabBarIcon: ({focused, color, size }) => (<Ionicons name={focused === true ? 'menu' : 'menu'} color={color} size={24} />) }} component={Menu} />
            </Tab.Navigator>

            <MenuBottomSheet bottomSheetRef={bottomSheetRef} handleSheetChanges={handleSheetChanges} />
        </>
    );
}