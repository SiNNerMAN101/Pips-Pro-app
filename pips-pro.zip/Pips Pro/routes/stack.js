import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useSelector } from 'react-redux';
import Login from '../screens/login';
import Signup from '../screens/signup';
import { AntDesign, Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import ForgotPassword from '../screens/forgot_password';
import AllWatchLists from '../screens/all_watchlists';
import Chat from '../screens/chat';
import News from '../screens/news';
import { TouchableOpacity } from 'react-native';
import VerifyAccount from '../screens/verify_account';
import VerifyConfirmationCode from '../screens/verify_confirmation_code';
import ResetPassword from '../screens/reset_password';
import { AddSymbolModal } from '../components/watchlist/AddSymbolModal';
import { CreateWatchlistModal } from '../components/all_watchlists/CreateWatchlistModal';
import { LogoutModal } from '../components/menu/LogoutModal';
import { RenameWatchlistModal } from '../components/all_watchlists/RenameWatchlistModal';
import { CreateChannelModal } from '../components/channels/CreateChannelModal';
import { SearchChannelsModal } from '../components/channels/SearchChannelsModal';
import { IdeaCategoryModal } from '../components/chart/IdeaCategoryModal';
import UserProfile from '../screens/user_profile';
import Tabs from './tab';
import { MarketTypeModal } from '../components/chart/MarketTypeModal';

const Stack = createNativeStackNavigator();

export default function StackRoute() {
    const logged_in = useSelector((state) => state.login_state.logged_in);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const all_watchlists_state = useSelector((state) => state.watch_list_state.all_watchlists_state); // The all watchlists state
    const channel_properties = useSelector((state) => state.chat.channel_properties); // Channel properties

    return (
        <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right', contentStyle: { backgroundColor: '#ffffff' } }} initialRouteName="WatchList">
            {/* Main screens on the app */}
            <Stack.Group>
                <Stack.Screen name="Tabs" component={Tabs} options={{ title: 'Tabs' }} />

                <Stack.Screen name="AllWatchLists" component={AllWatchLists} options={({ navigation }) => ({ title: 'Watchlists', headerShown: true, headerTitleStyle: { color: is_darkmode === true ? '#ffffff' : '#000000' }, headerShadowVisible: false, headerStyle: { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }, headerBackTitle: 'Back', headerTintColor: is_darkmode === true ? '#ffffff' : '#000000', headerRight: () => (
                    <>
                        {
                            logged_in === true ?
                                <TouchableOpacity disabled={all_watchlists_state === 'loading' || all_watchlists_state === 'no_access' || all_watchlists_state === 'error' ? true : false} onPress={() => navigation.navigate('CreateWatchlistModal')}>
                                    <Ionicons name="add-outline" size={31} color={all_watchlists_state === 'loading' || all_watchlists_state === 'no_access' || all_watchlists_state === 'error' ? '#5a5a5a' : is_darkmode === true ? '#ffffff' : '#000000'} />
                                </TouchableOpacity>
                            : null
                        }
                    </>
                ) })} />
                
                <Stack.Screen name="Chat" component={Chat} options={({ navigation }) => ({ title: channel_properties['channel_name'], headerShown: true, headerTitleStyle: { color: is_darkmode === true ? '#ffffff' : '#000000' }, headerShadowVisible: false, headerStyle: { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }, headerBackTitle: 'Back', headerTintColor: is_darkmode === true ? '#ffffff' : '#000000', headerRight: () => (
                    <TouchableOpacity>
                        <MaterialCommunityIcons name="dots-horizontal-circle-outline" size={27} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ) })} />

                <Stack.Screen name="News" component={News} options={{ title: 'News' }} />
                
                <Stack.Screen name="AddSymbolModal" component={AddSymbolModal} options={{ title: 'AddSymbolModal', presentation: 'formSheet' }} />
                
                <Stack.Screen name="CreateWatchlistModal" component={CreateWatchlistModal} options={{ title: 'CreateWatchlistModal', presentation: 'formSheet' }} />
                
                <Stack.Screen name="RenameWatchlistModal" component={RenameWatchlistModal} options={{ title: 'RenameWatchlistModal', presentation: 'formSheet' }} />
                
                <Stack.Screen name="CreateChannelModal" component={CreateChannelModal} options={{ title: 'CreateChannelModal', presentation: 'formSheet' }} />
                
                <Stack.Screen name="SearchChannelsModal" component={SearchChannelsModal} options={{ title: 'SearchChannelsModal', presentation: 'formSheet' }} />
                
                <Stack.Screen name="LogoutModal" component={LogoutModal} options={{ title: 'LogoutModal', gestureEnabled: false, animation: 'fade', presentation: 'fullScreenModal' }} />

                <Stack.Screen name="IdeaCategoryModal" component={IdeaCategoryModal} options={({ navigation }) => ({ title: 'Categories', headerShown: true, headerTitleStyle: { color: is_darkmode === true ? '#ffffff' : '#000000' }, headerShadowVisible: false, headerStyle: { backgroundColor: is_darkmode === true ? '#1e1e1e' : '#ffffff' }, headerBackTitle: 'Menu', headerTintColor: is_darkmode === true ? '#ffffff' : '#000000', presentation: 'formSheet', headerRight: () => (
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <AntDesign name="closecircleo" size={21.5} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ) })} />

                <Stack.Screen name="MarketTypeModal" component={MarketTypeModal} options={({ navigation }) => ({ title: 'Market types', headerShown: true, headerTitleStyle: { color: is_darkmode === true ? '#ffffff' : '#000000' }, headerShadowVisible: false, headerStyle: { backgroundColor: is_darkmode === true ? '#1e1e1e' : '#ffffff' }, headerBackTitle: 'Menu', headerTintColor: is_darkmode === true ? '#ffffff' : '#000000', presentation: 'formSheet', headerRight: () => (
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <AntDesign name="closecircleo" size={21.5} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ) })} />
                
                <Stack.Screen name="UserProfile" component={UserProfile} options={{ title: 'Profile', headerShown: true, headerTitleStyle: { color: is_darkmode === true ? '#ffffff' : '#000000' }, headerShadowVisible: false, headerStyle: { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }, headerBackTitle: 'Menu', headerTintColor: is_darkmode === true ? '#ffffff' : '#000000', headerRight: () => (
                    <TouchableOpacity>
                        <Feather name="edit" size={21} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                    </TouchableOpacity>
                ) }} />
            </Stack.Group>

            {(logged_in === false) ? (
                // Auth screens
                <Stack.Group>
                    <Stack.Screen name="Login" component={Login} options={{ title: 'Login' }} />
                    <Stack.Screen name="Signup" component={Signup} options={{ title: 'Signup' }} />
                    <Stack.Screen name="ForgotPassword" component={ForgotPassword} options={{ title: 'ForgotPassword' }} />
                    <Stack.Screen name="VerifyAccount" component={VerifyAccount} options={{ title: 'VerifyAccount' }} />
                    <Stack.Screen name="VerifyConfirmationCode" component={VerifyConfirmationCode} options={{ title: 'VerifyConfirmationCode' }} />
                    <Stack.Screen name="ResetPassword" component={ResetPassword} options={{ title: 'ResetPassword', gestureEnabled: false }} />
                </Stack.Group>
            ) : null}
        </Stack.Navigator>
    );
}