import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { Text, View } from 'react-native';
import ForYou from '../../screens/community_sections/for_you';
import Following from '../../screens/community_sections/following';
import Stock from '../../screens/community_sections/stock';
import Forex from '../../screens/community_sections/forex';
import Crypto from '../../screens/community_sections/crypto';
import { useMemo } from 'react';
import { allWatchlists } from '../../styles/all_watchlists';
import { useSelector } from 'react-redux';
import Channels from '../../screens/channels';

const Tab = createMaterialTopTabNavigator();

export default function TopTabBar() {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    return (
        <Tab.Navigator screenOptions={({ route }) => ({ tabBarStyle:  [{ backgroundColor: '#000000' }, all_watchlists_styles.native_header2], tabBarScrollEnabled: true, tabBarItemStyle: { borderRadius: 2, width: 'auto' }, tabBarActiveTintColor: 'red', tabBarInactiveTintColor: 'white', tabBarIndicatorStyle: { backgroundColor: 'transparent' }, tabBarLabelStyle: { fontWeight: 'bold', color: '#ffffff' }, tabBarPressColor: 'transparent', tabBarLabel: ({ focused }) => (
            <View
                style={{
                    backgroundColor: focused ? '#323335' : 'transparent', // Active tab background
                    borderRadius: 25, // Rounded corners
                    paddingHorizontal: 15,
                    paddingVertical: 7
                }}
            >
                <Text style={{ color: focused ? '#ffffff' : '#71767b', fontFamily: 'RobotoBold', fontSize: 17 }}>
                    {route.name === 'ForYou' ? 'For you' : route.name === 'Following' ? 'Following' : route.name === 'Stock' ? 'Stock' : route.name === 'Channels' ? 'Channels' : route.name === 'Forex' ? 'Forex' : route.name === 'Crypto' ? 'Crypto' : ''}
                </Text>
            </View>
        ), })}>
            <Tab.Screen name="ForYou" component={ForYou} />
            <Tab.Screen name="Following" component={Following} />
            <Tab.Screen name="Channels" component={Channels} />
            <Tab.Screen name="Stock" component={Stock} />
            <Tab.Screen name="Forex" component={Forex} />
            <Tab.Screen name="Crypto" component={Crypto} />
        </Tab.Navigator>
    );
}