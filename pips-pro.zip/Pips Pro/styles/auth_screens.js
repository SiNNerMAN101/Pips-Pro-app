import { StyleSheet, StatusBar } from "react-native";

export const authScreens = StyleSheet.create({
    form_container: {
        width: '100%',
        marginTop: 30,
        paddingHorizontal: 17
    },

    logo_view: { 
        flexDirection: 'row', 
        alignItems: 'center' 
    },

    logo_text: { 
        fontFamily: 'BlackOpsOne', 
        fontSize: 30, 
        marginLeft: 10   
    },

    left_logo_text: { 
        color: '#ffb748' 
    },

    right_logo_text: { 
        color: '#f19200' 
    },

    go_back_btn_view: {
        alignItems: 'flex-start',
        width: '100%',
        paddingHorizontal: 17,
        marginTop: 20
    },

    go_back_btn: { 
        flexDirection: 'row',
        alignItems: 'center'
    },

    go_back_btn_txt: { 
        fontSize: 17, 
        position: 'relative', 
        left: -2,
        fontFamily: 'RobotoRegular'    
    },

    logo: {
        width: 50,
        height: 50
    },

    head_txt: {
        fontSize: 22,
        marginTop: 30,
        fontWeight: 'bold',
        fontFamily: 'RobotoBold'
    },

    bottom_txt: {
        fontSize: 17,
        fontFamily: 'RobotoRegular'
    },

    bottom_view: {
        marginTop: 8,
        flexDirection: 'row'
    },

    ll_txt: {
        color: '#f19200',
        fontSize: 17,
        fontFamily: 'RobotoRegular'
    },

    formBody: {
        marginTop: 35
    },

    inp_field: {
        borderWidth: 1.5,
        fontFamily: 'RobotoRegular',
        borderStyle: 'solid',
        padding: 17,
        borderRadius: 6,
        width: '100%',
        fontSize: 17,
        backgroundColor: '#ffffff'
    },

    password_inp_field: {
        fontFamily: 'RobotoRegular',
        fontSize: 17,
        backgroundColor: '#ffffff',
        flex: 1,
        height: 30,
        paddingRight: 11
    },

    password_inp_container: {
        borderWidth: 1.5,
        borderStyle: 'solid',
        padding: 17,
        paddingVertical: 14,
        alignItems: 'center',
        borderRadius: 6,
        width: '100%',
        height: 54.5,
        backgroundColor: '#ffffff',
        flexDirection: 'row'
    },

    email_or_username_inp_field: {
        fontFamily: 'RobotoRegular',
        fontSize: 17,
        backgroundColor: '#ffffff',
        flex: 1,
        height: 30
    },

    email_or_username_inp_container: {
        borderWidth: 1.5,
        borderStyle: 'solid',
        padding: 17,
        paddingVertical: 14,
        alignItems: 'center',
        borderRadius: 6,
        width: '100%',
        height: 54.5,
        backgroundColor: '#ffffff',
        flexDirection: 'row'
    },

    channel_desc_inp: {
        paddingTop: 14,
        paddingBottom: 14,
        paddingHorizontal: 17,
        fontFamily: 'RobotoRegular',
        fontSize: 17,
        borderRadius: 6,
        height: 130,
        marginTop: 26,
        borderWidth: 1.5
    },

    btn_width: {
        width: '100%'
    },

    apple_auth_btn_container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },

    apple_auth_btn_button: {
        width: '100%',
        height: 54.5,
        fontFamily: 'RobotoBold',
        fontSize: 12
    },

    label: {
        marginBottom: 6,
        fontSize: 14
    },
    
    mt_23: {
        marginTop: 23
    },

    err_box: { 
        padding: 13, 
        borderRadius: 6
    },

    touchable: {
        flex: 0.5, 
        borderColor: 'black', 
        borderWidth: 1
    },

    btn_text: {
        alignSelf: 'center'
    },

    btn: {
        width: '100%',
        height: 54.5,
        padding: 6,
        borderRadius: 6,
        backgroundColor: '#f19200'
    },

    btn_container: {
        alignItems: 'center',
        display: 'flex',
        marginTop: 30
    },

    ll_txt2: {
        color: '#f19200',
        textAlign: 'center',
        fontSize: 17,
        marginTop: 23,
        fontWeight: 'bold'
    },

    or_box: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 17
    },

    or_txt: {
        fontSize: 17,
        fontFamily: 'RobotoBold'
    },

    divider_line1: {
        width: 120,
        height: 1,
        marginRight: 20
    },

    divider_line2: {
        width: 120,
        height: 1,
        marginLeft: 20
    },

    btn_font: {
        fontSize: 17,
        fontWeight: 'bold',
        color: '#ffffff',
        fontFamily: 'RobotoBold'
    },

    err_text: {
        fontSize: 14
    },

    auth_icon: {
        width: 25,
        height: 25
    },

    auth_button: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        borderWidth: 1.5,
        borderStyle: 'solid',
        padding: 11,
        borderRadius: 6,
        marginTop: 19,
        height: 54.5
    },

    auth_btn_txt_view: {
        alignItems: 'center'
    },

    auth_btn_txt: {
        fontFamily: 'RobotoBold',
        fontSize: 17,
        marginLeft: 13
    },

    errorText: {
        color: 'red',
        marginLeft: 17,
        marginTop: 6,
        fontSize: 12.5,
        fontFamily: 'RobotoRegular'
    },

    fgp_box: {
        alignItems: 'center',
        width: '100%',
        marginTop: 23
    },

    fgp_btn_txt: {
        color: '#f19200',
        textAlign: 'center',
        fontSize: 17,
        fontFamily: 'RobotoBold'
    },
})