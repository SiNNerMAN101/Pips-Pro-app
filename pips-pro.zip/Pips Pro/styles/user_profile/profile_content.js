import { StyleSheet } from "react-native";

export const profileContentStyles = (is_darkmode) => StyleSheet.create({
    user_profile_img_and_name: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 14, 
        margin: 17, 
        marginLeft: 3, 
        marginRight: 3, 
        marginBottom: 3, 
        borderRadius: 10 
    },
    
    username: { 
        fontSize: 20, 
        fontFamily: 'RobotoBold', 
        marginLeft: 13, 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        marginBottom: 5, 
        maxWidth: 243 
    },

    email: { 
        fontSize: 17, 
        fontFamily: 'RobotoRegular', 
        marginLeft: 13, 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        marginTop: 5, 
        maxWidth: 243 
    },

    user_data_box: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        justifyContent: 'space-between', 
        padding: 14, 
        margin: 17, 
        marginTop: 0, 
        marginLeft: 9, 
        marginRight: 9 
    },

    user_data_value: { 
        fontSize: 20, 
        fontFamily: 'RobotoRegular',
        color: is_darkmode === true ? '#ffffff' : '#000000'
    },

    user_data_label: { 
        fontSize: 14, 
        fontFamily: 'RobotoRegular',
        color: '#747474'
    }
})