import { StyleSheet } from "react-native";

export const createIdeaStyles = (is_darkmode, insets) => StyleSheet.create({
    header: { 
        flexDirection: 'row', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        height: 43, 
        marginTop: 13, 
        paddingHorizontal: 16 
    },

    header_left: { 
        width: 31.0, 
        height: 31.0 
    },

    header_title: { 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        fontFamily: 'RobotoBold', 
        fontWeight: 'bold', 
        fontSize: 20 
    },

    scroll_view: { 
        padding: 10, 
        paddingLeft: insets.left === 0 ? 25 : insets.left, 
        paddingRight: insets.right === 0 ? 25 : insets.right, 
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' 
    },

    mt25: {
        marginTop: 25
    },

    mt30: {
        marginTop: 30
    },

    mb36: {
        marginBottom: 36
    },

    form_field_title: { 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        fontFamily: 'RobotoRegular', 
        fontSize: 17 
    },

    form_field_desc: { 
        color: is_darkmode === true ? '#929292' : '#000000', 
        fontFamily: 'RobotoRegular', 
        fontSize: 14.5,
        marginTop: 10.5,
        lineHeight: 20 
    },

    field_view: { 
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', 
        marginTop: 13, 
        padding: 0, 
        borderRadius: 15, 
        borderColor: '#3a3a3a', 
        borderWidth: 1, 
        borderStyle: 'solid'
    },

    field_view2: { 
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', 
        marginTop: 13, 
        padding: 5, 
        height: 48,
        borderRadius: 15, 
        borderColor: '#3a3a3a', 
        borderWidth: 1, 
        borderStyle: 'solid',
        flexDirection: 'row',
        alignItems: 'center'
    },

    toggle_view: { 
        margin: 5, 
        flexDirection: 'row', 
        alignItems: 'center' 
    },

    field_toggle_tab: { 
        width: '50%', 
        alignItems: 'center',
        padding: 8, 
        borderRadius: 8 
    },

    field_toggle_tab6: { 
        flex: 1, 
        alignItems: 'center',
        padding: 8, 
        borderRadius: 8 
    },

    field_toggle_tab2: {
        flexDirection: 'row', 
        alignItems: 'center',  
        justifyContent: 'center', 
        padding: 8, 
        borderRadius: 8, 
        width: '50%'
    },

    field_toggle_tab5: {
        flexDirection: 'row', 
        alignItems: 'center',  
        justifyContent: 'center', 
        padding: 8, 
        borderRadius: 8, 
        flex: 1
    },

    field_toggle_tab3: {
        flexDirection: 'row', 
        alignItems: 'center',  
        justifyContent: 'center', 
        padding: 8, 
        borderRadius: 8,
        backgroundColor: '#3a3a3a'
    },

    field_toggle_text: { 
        color: is_darkmode === true ? '#ffffff' : '#000000',
        fontSize: 17 
    },

    field_toggle_text2: {
        color: is_darkmode === true ? '#ffffff' : '#000000',
        fontSize: 17,
        fontFamily: 'RobotoBold'
    },

    caret: { 
        width: 30, 
        height: 30, 
        alignItems: 'center', 
        justifyContent: 'center' 
    }
})