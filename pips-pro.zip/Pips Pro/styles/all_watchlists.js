import { StyleSheet } from "react-native";

export const allWatchlists = (is_darkmode) => StyleSheet.create({
    screen_bg_color: { 
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' 
    },

    native_header: { 
        borderTopColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd', 
        borderTopWidth: 0.5, 
        borderStyle: 'solid'
    },

    native_header2: { 
        borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd', 
        borderBottomWidth: 0.5, 
        borderStyle: 'solid'
    },

    header_bar: { 
        borderBottomColor: is_darkmode === true ? '#252525' : '#cdcdcd' 
    },

    go_back_btn: { 
        marginLeft: 9,
        width: 73.5, 
        height: 31.5,
        justifyContent: 'center'
    },

    back_txt: { 
        color: is_darkmode === true ? "#ffffff" : "#000000" 
    },

    watchlist_title: { 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        fontWeight: 'bold', 
        fontFamily: 'RobotoBold', 
        fontSize: 18 
    },

    add_watchlist_btn: { 
        width: 73.5, 
        height: 31.5, 
        marginRight: 9, 
        alignItems: 'flex-end',
        justifyContent: 'center'
    },

    watchlist_main_title: { 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        marginTop: 15, 
        marginBottom: 10
    },

    watchlist_item: { 
        borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', 
        paddingBottom: 10, 
        marginLeft: 17, 
        borderBottomWidth: 0.5, 
        borderStyle: 'solid' 
    },

    watchlist_name: {
        fontSize: 22, 
        fontFamily: 'RobotoRegular', 
        marginTop: 9 
    },

    symbols_list: { 
        flexDirection: 'row', 
        width: '96%', 
        overflow: 'hidden', 
        marginTop: 4 
    }
})