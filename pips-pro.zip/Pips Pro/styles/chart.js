import { StyleSheet } from "react-native";

export const chart = (is_darkmode) => StyleSheet.create({
    container: { 
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', 
        flex: 1, 
        alignItems: 'center', 
        justifyContent: 'center' 
    },

    inner_container: { 
        flex: 1, 
        width: '100%', 
        borderTopWidth: 1, 
        borderTopColor: is_darkmode === true ? '#434651' : '#e0e3eb', 
        borderStyle: 'solid' 
    },

    chart_container: { 
        flex: 1, 
        width: '100%', 
        backgroundColor: is_darkmode === true ? '#131722' : '#ffffff' 
    },

    btm_buttons: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', 
        justifyContent: 'center', 
        padding: 8, 
        borderTopWidth: 1, 
        borderTopColor: is_darkmode === true ? '#434651' : '#e0e3eb', 
        borderStyle: 'solid' 
    },

    left_and_right_btns: {
        padding: 6
    },

    center_btn: { 
        marginLeft: 40, 
        marginRight: 40, 
        padding: 6 
    },

    webview_comp: {
        backgroundColor: 'transparent' 
    }
})