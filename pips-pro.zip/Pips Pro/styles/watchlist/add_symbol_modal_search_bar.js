import { StyleSheet } from "react-native";

export const addSymbolModalSearchBarStyles = (is_darkmode) => StyleSheet.create({
    input_style: { 
        fontSize: 17, 
        fontFamily: 'RobotoRegular', 
        minHeight: 30, 
        color: is_darkmode === true ? '#ffffff' : '#000000'
    },

    input_container_style: { 
        height: 30, 
        borderRadius: 30, 
        backgroundColor: is_darkmode === true ? '#2c344a' : '#dcdce1'
    },

    cancel_btn: {
        fontFamily: 'RobotoRegular', 
        color: '#f19200'
    },

    container_style: {
        borderRadius: 20, 
        width: '100%', 
        backgroundColor: is_darkmode === true ? '#131722' : '#ffffff'
    }
})