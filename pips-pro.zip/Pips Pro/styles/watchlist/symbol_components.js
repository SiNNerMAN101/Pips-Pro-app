import { StyleSheet } from "react-native";

export const symbolComponentsStyles = (is_darkmode) => StyleSheet.create({
    item: { 
        flexDirection: 'row', 
        justifyContent: 'space-between', 
        marginBottom: 10, 
        borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', 
        paddingBottom: 10, 
        borderBottomWidth: 0.5, 
        borderStyle: 'solid',
        marginHorizontal: 15,
        marginRight: 0
    },

    symbol_details: { 
        flexDirection: 'row', 
        flex: 1, 
        alignItems: 'center' 
    },

    avatar_title: {
        color: '#ffffff'
    },

    avatar_bg: { 
        backgroundColor: "#cecece" 
    },

    ml13: { 
        marginLeft: 13 
    },

    mr8: { 
        marginRight: 8
    },

    symbol_short_name: { 
        fontSize: 17, 
        fontFamily: 'RobotoRegular', 
        color: is_darkmode === true ? '#ffffff' : '#000000' 
    },

    symbol_name: { 
        maxWidth: 153, 
        fontFamily: 'RobotoRegular', 
        fontSize: 15, 
        color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b', 
        marginTop: 4 
    },

    symbol_values: { 
        flexDirection: 'row', 
        alignSelf: 'center', 
        alignItems: 'center', 
        justifyContent: 'flex-end', 
        flex: 1, 
        marginRight: 8 
    },

    symbol_changes: { 
        fontSize: 15, 
        textAlign: 'right', 
        color: is_darkmode === true ? '#ffffff' : '#000000' 
    },

    symbol_type: { 
        marginTop: 4, 
        fontFamily: 'RobotoRegular', 
        fontSize: 15, 
        color: is_darkmode === true ? '#7f7f7f' : '#5b5b5b', 
        textAlign: 'right' 
    }
})