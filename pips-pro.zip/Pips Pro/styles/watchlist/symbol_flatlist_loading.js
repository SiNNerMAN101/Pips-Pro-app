import { StyleSheet } from "react-native";

export const symbolsFlatlistLoadingStyles = (is_darkmode) => StyleSheet.create({
    flatList: {
        flex: 1,
        marginRight: 0,
        marginLeft: 20
    },

    modal_flatlist: {
        flex: 1,
        marginRight: 0
    },

    item: { 
        flexDirection: 'row', 
        justifyContent: 'space-between', 
        marginLeft: 17, 
        marginBottom: 10, 
        borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', 
        paddingBottom: 10, 
        borderBottomWidth: 0.5, 
        borderStyle: 'solid' 
    },

    first_section: { 
        flexDirection: 'row', 
        flex: 1, 
        alignItems: 'center' 
    },

    second_section: { 
        flexDirection: 'row', 
        alignSelf: 'center', 
        alignItems: 'center', 
        justifyContent: 'flex-end', 
        flex: 1, 
        marginRight: 8 
    },

    mr8: { 
        marginRight: 8 
    },

    dfsc: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        marginBottom: 3 
    },

    ert: { 
        backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', 
        flex: 1 
    },

    profile: { 
        backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede' 
    },

    skeleton_style: { 
        backgroundColor: is_darkmode === true ? '#20242e' : '#d1d1d1' 
    },

    symbol_name: { 
        backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', 
        marginBottom: 3 
    },

    symbol_desc: { 
        backgroundColor: is_darkmode === true ? '#2a2e39' : '#dedede', 
        marginTop: 3 
    }
})