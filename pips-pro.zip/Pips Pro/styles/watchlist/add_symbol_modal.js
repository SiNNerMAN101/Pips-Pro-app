import { StyleSheet } from "react-native";

export const addSymbolModalStyles = (is_darkmode) => StyleSheet.create({
    container: { 
        flex: 1, 
        backgroundColor: is_darkmode === true ? '#131722' : '#ffffff'
    },

    searchbar_view: { 
        flexDirection: 'row', 
        paddingHorizontal: 16 
    }
})