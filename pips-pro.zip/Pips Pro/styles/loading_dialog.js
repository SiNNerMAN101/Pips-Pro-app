import { StyleSheet } from "react-native";

export const loadingDialogStyles = (is_darkmode) => StyleSheet.create({
    dialog_title: { 
        textAlign: 'center', 
        fontFamily: 'RobotoBold', 
        fontSize: 23,
        color: is_darkmode === true ? '#ffffff' : '#000000' 
    },

    overlay: { 
        borderRadius: 20,
        backgroundColor: is_darkmode === true ? '#131722' : '#ffffff'
    }
});