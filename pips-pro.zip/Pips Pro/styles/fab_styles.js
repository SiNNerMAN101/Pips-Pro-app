import { StyleSheet } from "react-native";

export const fabBtnStyles = (is_darkmode) => StyleSheet.create({
    fabContainer: { 
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 100,
    },

    fabContainer_for_user_profile: { 
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 40,
    },

    fab: {
        borderRadius: 100,
        alignItems: 'center', 
        justifyContent: 'center',
        backgroundColor: is_darkmode === true ? '#000000' : '#FFFFFF'
    },

    fab_user_profile: {
        borderRadius: 100,
        alignItems: 'center', 
        justifyContent: 'center',
        backgroundColor: '#f19200'
    },

    badgeContainer: {
        position: 'absolute',
        right: 0,
        top: -6,
        backgroundColor: 'red',
        borderRadius: 12,
        width: 22,
        height: 22,
        justifyContent: 'center',
        alignItems: 'center',
    },

    badgeText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 12
    },
})