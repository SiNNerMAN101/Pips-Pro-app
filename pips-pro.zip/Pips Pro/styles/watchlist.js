import { StyleSheet, Platform } from "react-native";

export const watchList = StyleSheet.create({
    container: {
        paddingBottom: 0, 
        margin: 30, 
        marginLeft: 0, 
        marginRight: 0, 
        marginBottom: 0, 
        marginTop: 0, 
        flex: 1
    },

    logo: {
        width: 30,
        height: 30
    },

    header_bar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        height: 55,
        borderBottomWidth: 0.5,
        borderStyle: 'solid'
    },

    right_btn: {
        marginRight: 20
    },

    left_btn: {
        marginLeft: 20
    },

    flatList: {
        flex: 1,
        marginRight: 0,
        marginLeft: 20
    },

    modal_flatlist: {
        flex: 1,
        marginRight: 0
    },

    flatlist_br: {
        flex: 1,
        marginRight: 0
    },

    watchlist_name_bold: {
        fontWeight: 'bold',
        fontSize: 32,
        marginTop: 15,
        marginBottom: 12,
        marginLeft: 20
    },

    active_watchlist_name: {
        fontWeight: 'bold',
        fontSize: 32,
        marginTop: 15,
        marginBottom: 20,
        fontFamily: 'RobotoBold'
    },

    bottomsheet_header: {
        flexDirection: 'row', 
        position: 'absolute', 
        top: 0, 
        left: 0, 
        right: 0, 
        zIndex: 1,
        alignContent: 'center', 
        justifyContent: 'flex-end', 
        paddingHorizontal: 16, 
        paddingVertical: 10, 
        paddingBottom: 15,
        borderBottomWidth: 1,
        borderStyle: 'solid', 
        justifyContent: 'space-between'
    },

    bottomsheet_scrollview: {
        flex: 1
    },

    bottomsheet_view: {
        height: 600, 
        marginTop: 48, 
        borderTopWidth: 1,
        borderStyle: 'solid'
    },

    flatlist_in_bottomsheet_container: {
        alignItems: 'center'
    },

    flatlist_in_bottomsheet_styles: {
        height: 80, 
        flexGrow: 0, 
        borderWidth: 1,
        borderStyle: 'solid'
    },

    header_title: {
        fontWeight: 'bold', 
        fontSize: 18,
        fontFamily: 'RobotoBold'
    },

    title_br: {
        fontWeight: 'bold',
        fontFamily: 'RobotoBold',
        fontSize: 32,
        marginTop: 10,
        marginBottom: 0,
        marginLeft: 17
    },

    section_name: {
        fontSize: 13.5,
        fontWeight: 'bold'
    },

    section_touch_opacity: {
        marginBottom: 23,
        marginTop: 4
    },

    handle: {
        alignItems: 'center',
        justifyContent: 'center',
        borderStyle: 'solid',
        borderWidth: 1,
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        height: 20
    },

    handleIndicator: {
        width: 40,
        height: 4,
        backgroundColor: '#ccc',
        borderRadius: 2,
        marginTop: 6,
    }
})