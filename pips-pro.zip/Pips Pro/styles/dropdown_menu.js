import { StyleSheet } from "react-native";

export const dropdownMenu = (is_darkmode) => StyleSheet.create({
    dropdown: {
        height: 54.5,
        marginTop: 26,
        backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', 
        color: is_darkmode === true ? '#ffffff' : '#000000',
        borderRadius: 6,
        paddingTop: 14,
        paddingBottom: 14,
        paddingHorizontal: 17,
        borderWidth: 1.5
    },

    icon: {
        marginRight: 5,
    },

    menu_list: {
        borderWidth: 1, 
        borderStyle: 'solid', 
        borderColor: is_darkmode === true ? '#000000' : '#ffffff'
    },

    item: {
        padding: 17,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', 
        borderColor: is_darkmode === true ? '#000000' : '#ffffff', 
        borderWidth: 1
    },

    textItem: {
        flex: 1,
        fontSize: 17,
        fontFamily: 'RobotoRegular',
        color: is_darkmode === true ? '#ffffff' : '#000000',
    },

    placeholderStyle: {
        fontSize: 17,
        color: '#999696',
        fontFamily: 'RobotoRegular'
    },

    selectedTextStyle: {
        fontSize: 17,
        fontFamily: 'RobotoRegular',
        color: is_darkmode === true ? '#ffffff' : '#000000',
    },

    iconStyle: {
        width: 20,
        height: 20,
    },

    inputSearchStyle: {
        height: 40,
        fontSize: 16,
    }
})