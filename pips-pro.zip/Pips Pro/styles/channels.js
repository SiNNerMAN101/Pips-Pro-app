import { StyleSheet } from "react-native";

export const channels = (is_darkmode) => StyleSheet.create({
    container: {
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', 
        marginRight: 0, 
        marginBottom: 0, 
        marginTop: 0, 
        flex: 1
    },

    header: { 
        borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd', 
        alignItems: 'center' 
    },

    header_title: { 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        fontFamily: 'RobotoBold', 
        fontWeight: 'bold', 
        fontSize: 32, 
        marginLeft: 17 
    },

    header_btns: {
        flexDirection: 'row', 
        alignItems: 'center' 
    },

    create_channel_btn: {
        marginRight: 26
    },

    segmented_ctrl_view: { 
        marginHorizontal: 17, 
        marginTop: 17 
    },

    segmented_ctrl: { 
        height: 40 
    },

    inp_container: {
        backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', 
        color: is_darkmode === true ? '#ffffff' : '#000000'
    },

    inp_field: { 
        backgroundColor: is_darkmode === true ? '#2a2e39' : '#ffffff', 
        color: is_darkmode === true ? '#ffffff' : '#000000' 
    },

    btn: {
        width: '100%',
        height: 40,
        marginTop: 23,
        padding: 6,
        borderRadius: 6,
        backgroundColor: '#f19200'
    },

    comp_title: { 
        marginTop: 15, 
        textAlign: 'center', 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        fontFamily: 'RobotoBold', 
        fontSize: 18.5 
    },

    comp_box: { 
        flexDirection: 'column', 
        marginTop: 20, 
        alignItems: 'center' 
    },

    comp_style: { 
        flex: 1, 
        padding: 20, 
        paddingVertical: 30 
    },

    comp_container_style: { 
        justifyContent: 'center', 
        alignItems: 'center' 
    },

    btn_width: { 
        width: 100 
    }
})