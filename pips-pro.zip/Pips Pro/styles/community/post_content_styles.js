import { StyleSheet } from "react-native";

export const postContentStyles = (is_darkmode) => StyleSheet.create({
    content: {
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff'
    },

    post_item: {
        flexDirection: 'column', 
        paddingLeft: 17, 
        paddingRight: 17, 
        marginBottom: 16, 
        paddingBottom: 21,
        borderBottomColor: is_darkmode === true ? '#323335' : '#cdcdcd',
        borderBottomWidth: 10,
        borderStyle: 'solid'
    },

    post_data: { 
        marginTop: 15, 
        flexDirection: 'row', 
        justifyContent: 'space-between',
    },

    username: {
        marginTop: 3,
        fontFamily: 'RobotoRegular',
        fontSize: 13.8,
        color: is_darkmode === true ? '#ffffff' : '#000000'
    },

    date: { 
        marginTop: 7,
        fontFamily: 'RobotoRegular',
        fontSize: 13,
        color: '#747474'
    },

    post_data_box: { 
        flexDirection: 'row', 
        alignItems: 'center' 
    },

    post_interaction_btn: {
        marginLeft: 14,
        flexDirection: 'row',
        alignItems: 'center'
    },

    like_btn: {
        marginRight: 14,
        flexDirection: 'row',
        alignItems: 'center'
    },

    interaction_values: {
        marginLeft: 6,
        fontFamily: 'RobotoRegular',
        fontSize: 14,
        color: is_darkmode === true ? '#71767b' : '#000000'
    },

    post_header: {
        flexDirection: 'row', 
        justifyContent: 'flex-start', 
        marginBottom: 14
    },

    post_header_info_view: { 
        flexDirection: 'column', 
        justifyContent: 'center', 
        marginLeft: 12 
    },

    post_header_info: { 
        flexDirection: 'row', 
        alignItems: 'center' 
    },

    post_header_fullname: {
        color: '#ffffff', 
        fontFamily: 'RobotoBold', 
        fontSize: 17, 
        marginBottom: 1.3
    },

    post_header_username: {
        color: '#71767b', 
        fontFamily: 'RobotoRegular', 
        fontSize: 16, 
        marginBottom: 1.3
    },

    post_header_dot_seperator: {
        color: '#71767b', 
        fontFamily: 'RobotoBold', 
        marginLeft: 5, 
        fontSize: 16, 
        marginBottom: 1.3
    },

    post_header_timestamp: { 
        color: '#71767b', 
        fontFamily: 'RobotoRegular', 
        marginLeft: 5, 
        fontSize: 14, 
        marginBottom: 1.3 
    },

    interactive_icons_view: { 
        borderTopColor: '#3a3d40', 
        marginTop: 15, 
        borderTopWidth: 1, 
        borderStyle: 'solid', 
        paddingVertical: 10, 
        borderBottomColor: '#3a3d40', 
        borderBottomWidth: 1 
    },

    interactive_icon_btn: {
        flexDirection: 'row', 
        backgroundColor: '#212223', 
        alignItems: 'center', 
        padding: 5, 
        borderRadius: 10, 
        borderColor: '#5f6368', 
        borderWidth: 1, 
        borderStyle: 'solid'
    },

    interactive_icon_total: { 
        fontFamily: 'RobotoRegular', 
        marginLeft: 5, 
        color: is_darkmode === true ? '#71767b' : '#000000', 
        fontSize: 16 
    }
})