// styles.js
import { StyleSheet } from 'react-native';

export const htmlViewStyles = (is_darkmode) => {
    return StyleSheet.create({
        p: {
            fontFamily: 'RobotoRegular',
            fontSize: 16,
            color: is_darkmode === true ? '#ffffff' : '#000000', // make links coloured pink
        }
    });
};
