import { StyleSheet } from "react-native";

export const bottomTabBarStyles = (Platform, is_darkmode, orientation) => StyleSheet.create({
    tab_bar_label_style: { 
        fontSize: 12, 
        fontFamily: 'RobotoRegular', 
        position: 'relative', 
        top: orientation === 1 ? (Platform.OS === 'ios' ? -7.5 : -7) : 0
    },

    tabbar_container: {
        backgroundColor: '#f7f8fb',
    },

    tab_bar_style: { 
        height: Platform.OS === 'ios' ? 88 : 57, 
        backgroundColor: (is_darkmode === true) ? '#000000' : '#ffffff', 
        borderTopColor: is_darkmode === true ? '#3a3a3a' : '#cdcdcd' 
    }
});