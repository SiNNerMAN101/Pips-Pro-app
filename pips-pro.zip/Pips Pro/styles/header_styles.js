import { StyleSheet } from "react-native";

export const headerStyles = (is_darkmode) => StyleSheet.create({
    double_items_header_right: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        marginRight: 17
    },

    title_left: { 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        fontFamily: 'RobotoBold', 
        fontWeight: 'bold', 
        fontSize: 32, 
        marginLeft: 17 
    },

    header_appearance: {
        backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', 
        shadowOpacity: 0, 
        elevation: 0
    }
})