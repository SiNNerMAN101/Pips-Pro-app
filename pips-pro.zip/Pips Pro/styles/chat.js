import { StyleSheet } from "react-native";

export const chat = (is_darkmode) => StyleSheet.create({
    chat_flatlist: { 
        backgroundColor: is_darkmode === true ? '#131722' : '#f1f1f1',
        flex: 1 
    }
})