import { StyleSheet } from "react-native";

export const chat_bubble = (message, is_darkmode, user_details, channel_properties) => StyleSheet.create({
    touch_bubble: {
        padding: 16, 
        flex: 1, 
        marginHorizontal: 14, 
        backgroundColor: user_details.user_id === message.user_id ? is_darkmode === true ? '#394357' : '#dddddd' : is_darkmode === true ? '#35383e' : '#ffffff', 
        flexDirection: 'row', 
        alignItems: 'flex-start', 
        marginVertical: 10, 
        borderRadius: 10, 
        elevation: 10, 
        shadowColor: '#171717', 
        shadowOffset: {
            width: -2, 
            height: 4
        }, 
        shadowOpacity: 0.2, 
        shadowRadius: 3
    },

    user_avatar: { 
        backgroundColor: message.color_code, 
        borderRadius: 8 
    },

    avatar_title: { 
        color: '#ffffff' 
    },

    user_data: { 
        flex: 1, 
        marginLeft: 14.5 
    },

    username: { 
        color: message.color_code, 
        fontWeight: '600', 
        fontFamily: 'RobotoBold', 
        fontSize: 15 
    },

    admin_txt: { 
        color: message.color_code, 
        fontWeight: '600', 
        fontFamily: 'RobotoRegular', 
        fontSize: 13 
    },

    chat_txt: { 
        fontSize: 15, 
        lineHeight: 21, 
        fontFamily: 'RobotoRegular', 
        color: is_darkmode === true ? '#ffffff' : '#000000' 
    },

    more_txt_button: { 
        fontSize: 14, 
        fontFamily: 'RobotoRegular', 
        color: is_darkmode === true ? '#b9b9b9' : '#747474', 
        marginTop: 10 
    },

    chat_datetime: { 
        fontSize: 13, 
        fontFamily: 'RobotoRegular', 
        color: is_darkmode === true ? '#b9b9b9' : '#747474', 
        marginLeft: 10 
    },

    chat_view: { 
        marginTop: channel_properties['creator_id'] === message.user_id ? 5 : 3.5 
    },

    reply_view: {
        flexDirection: 'row', 
        flex: 1, 
        marginBottom: 6, 
        marginTop: 10,
        borderLeftWidth: 3 
    },

    inner_reply_view: { 
        flex: 1, 
        justifyContent: 'center', 
        paddingLeft: 10, 
        paddingRight: 10 
    },

    reply_view_for_deleted_chat: { 
        flex: 1, 
        flexDirection: 'row',
        alignItems: 'center', 
        alignSelf: 'center',
        paddingLeft: 10, 
        paddingRight: 10 
    },

    reply_username: {
        fontFamily: 'RobotoBold', 
        fontSize: 15.3, 
        marginBottom: 2
    },

    reply_chat: { 
        color: is_darkmode === true ? '#ffffff' : '#000000', 
        marginTop: 2, 
        fontFamily: 'RobotoRegular', 
        fontSize: 15 
    },

    reply_chat2: { 
        color: is_darkmode === true ? '#b9b9b9' : '#747474',
        fontFamily: 'RobotoRegular',
        fontSize: 15,
        marginLeft: 1.6
    },

    img_container: {
        marginTop: 13
    },

    text_under_image: {
        marginTop: 14
    },

    time_view: {
        alignItems: 'flex-end'
    },

    clock_ticker: {
        marginTop: 5.3
    }
})