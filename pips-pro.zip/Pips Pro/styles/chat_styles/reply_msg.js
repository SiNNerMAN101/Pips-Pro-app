import { StyleSheet } from "react-native";

export const reply_msg = (message, is_darkmode, user_details, channel_data) => StyleSheet.create({
    reply_msg_block: { 
        flexDirection: 'row', 
        height: 50, 
        marginBottom: 6, 
        marginTop: 10, 
        borderLeftColor: message.reply_data.color_code, 
        borderLeftWidth: 3 
    }
})