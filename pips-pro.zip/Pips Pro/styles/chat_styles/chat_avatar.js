import { StyleSheet } from "react-native";

export const chat_avatar = (message) => StyleSheet.create({
    avatar_container_style: { 
        backgroundColor: message.color_code,
        borderRadius: 8 
    }
})