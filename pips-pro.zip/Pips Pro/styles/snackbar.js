import { StyleSheet } from "react-native";

export const snackBarStyles = (error) => StyleSheet.create({
    snack: { 
        position: 'relative',
        bottom: 30,
        backgroundColor: error === true ? '#f44336' : '#4caf50'
    },

    container: {
        flexDirection: 'row',
        alignItems: 'center'
    },

    msg: {
        fontFamily: 'RobotoRegular',
        fontSize: 15.4,
        color: '#ffffff',
        paddingLeft: 10
    },

    label: {
        fontSize: 15,
        color: '#ffffff'
    }
});