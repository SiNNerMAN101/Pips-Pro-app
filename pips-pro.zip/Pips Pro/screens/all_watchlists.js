import { View, Text } from "react-native";
import { watchList } from "../styles/watchlist";
import { MaterialIcons } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useCallback, useMemo, useRef, useState } from "react";
import { allWatchlists } from "../styles/all_watchlists";
import { AllWatchlistsFlatList } from "../components/all_watchlists/AllWatchlistsFlatList";
import { LoadingComp } from "../components/all_watchlists/LoadingComp";
import { WatchlistData } from "../components/all_watchlists/WatchlistData";
import { Error } from "../components/all_watchlists/Error";
import { useFocusEffect } from "@react-navigation/native";
import { enter_screen } from "../reusable_methods/all_watchlists/enter_screen";
import { LoadingDialog } from "../components/all_watchlists/LoadingDialog";
import { Snackbar } from "react-native-paper";
import { snackBarStyles } from "../styles/snackbar";

export default function AllWatchLists({ navigation }) {
    const [refreshing, setRefreshing] = useState(false);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const all_watchlists_state = useSelector((state) => state.watch_list_state.all_watchlists_state); // The all watchlists state
    const controller = useRef(new AbortController());
    const refresh_controller = useRef(new AbortController());
    const delete_watchlist_controller = useRef(new AbortController());
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);
    const [loading_modal, set_loading_modal] = useState(false);

    const insets = useSafeAreaInsets();

    const handleScroll = (event) => {
        const scrolling = event.nativeEvent.contentOffset.y;
    }

    // Memoize the styles to avoid recalculating them on each render
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        await enter_screen(controller);
    }, []);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort(); // Cancel all pending requests
                controller.current = new AbortController();
                refresh_controller.current.abort(); // Cancel refresh request
                refresh_controller.current = new AbortController();
                delete_watchlist_controller.current.abort(); // Cancel all pending requests
                delete_watchlist_controller.current = new AbortController();
                setRefreshing(false);
            }
        }, [])
    )

    return (
        <View style={[watchList.container, all_watchlists_styles.screen_bg_color, all_watchlists_styles.native_header, { paddingBottom: insets.bottom }]}>
            {
                all_watchlists_state === true ?
                    <AllWatchlistsFlatList navigation={navigation} handleScroll={handleScroll} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} loading_modal={loading_modal} set_loading_modal={set_loading_modal} delete_watchlist_controller={delete_watchlist_controller} />
                : all_watchlists_state === false || all_watchlists_state === 'no_access' ?
                    <WatchlistData watchlist_state={all_watchlists_state} refreshing={refreshing} setRefreshing={setRefreshing} refresh_controller={refresh_controller} navigation={navigation} />
                : all_watchlists_state === 'error' ?
                    <Error refreshing={refreshing} setRefreshing={setRefreshing} refresh_controller={refresh_controller} />
                : <LoadingComp />
            }

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>

            <LoadingDialog loading_modal={loading_modal} />

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}