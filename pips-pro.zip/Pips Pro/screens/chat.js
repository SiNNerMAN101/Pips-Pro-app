import { View, Text, useColorScheme } from "react-native";
import { useState, useRef, useMemo, useCallback, useEffect } from "react";
import { useDispatch, useSelector } from 'react-redux';
import { useFocusEffect } from "@react-navigation/native";
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { StatusBar } from "expo-status-bar";
import { BottomComponents } from "../components/chat/BottomComponents";
import { connectSocket, disconnectSocket, getSocket } from '../reusable_methods/chat/socket_service';
import { enter_screen } from "../reusable_methods/chat/enter_screen";
import { ChatsFlatList } from "../components/chat/ChatsFlatList";
import { ChatsFlatListLoading } from "../components/chat/ChatsFlatListLoading";
import { ChatsFlatListError } from "../components/chat/ChatsFlatListError";
import { store } from "../store/store";
import { reset_chat_data, set_channel_properties, set_chat_state, set_no_of_new_chats_for_fab, set_scrolled_away_from_bottom, update_chat_timestamp } from "../state/chat";
import { ChatsFlatListNoChats } from "../components/chat/ChatsFlatListNoChats";
import { FAB, Snackbar } from "react-native-paper";
import { snackBarStyles } from "../styles/snackbar";
import { Animated } from "react-native";
import { fabBtnStyles } from "../styles/fab_styles";
import { Header } from "../components/chat/Header";
import { update_channel_chats_seen_state } from "../state/channels";
import { allWatchlists } from "../styles/all_watchlists";

export default function Chat({ route, navigation }) {
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [refreshing, setRefreshing] = useState(false);
    const chat_state = useSelector((state) => state.chat.chat_state); // Chat state
    const reply_chat = useSelector((state) => state.chat.reply_chat); // Reply chat state
    const no_of_new_chats_for_fab = useSelector((state) => state.chat.no_of_new_chats_for_fab); // Number of new chats to be displayed in a badge near the FAB button
    const flatListRef = useRef(null);
    const colorScheme = useColorScheme();
    const controller = useRef(new AbortController());
    const join_channel_controller = useRef(new AbortController());
    const delete_chat_controller = useRef(new AbortController());
    const refresh_controller = useRef(new AbortController());
    const dispatch = useDispatch();
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);
    const [delete_chat_loading_dialog, set_delete_chat_loading_dialog] = useState(false);
    const [fetch_recent_chats, set_fetch_recent_chats] = useState(true);
    const load_recent_chats_controller = useRef(new AbortController());
    const chat_timestamp = useRef(null);
    const [showFab, setShowFab] = useState(false);

    const scroll_to_bottom = () => {
        flatListRef.current?.scrollToOffset({ animated: true, offset: 0 });
    }

    // Animation values
    const fabOpacity = useRef(new Animated.Value(0)).current;
    const fabScale = useRef(new Animated.Value(0)).current;
    const thresholdDistance = 100; // Adjust this value as needed

    const handleScroll = (event) => {
        const { contentOffset } = event.nativeEvent;

        // Since it's inverted, contentOffset.y = 0 means you're at the "bottom" of the chat (the top of the list)
        const isAtBottom = contentOffset.y <= thresholdDistance;

        if (isAtBottom) {
            // User is at the bottom, hide the FAB
            setShowFab(false);
            dispatch(set_scrolled_away_from_bottom({ value: false })); // The user is at the bottom of the chats

            // Reset the number of new chats received at the moment for the FAB button to zero when the user scrolls to the bottom of the chats
            dispatch(set_no_of_new_chats_for_fab({ value: 0 }));
        } else {
            // User has scrolled away from the bottom, show the FAB
            setShowFab(true);
            dispatch(set_scrolled_away_from_bottom({ value: true })); // The user has scrolled away from the bottom of the chats
        }
    };

    const handleScrollEnd = (event) => {
        const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;
        const isAtTop = contentOffset.y <= 20;

        if (isAtTop) {
            // Ensure FAB hides at the top (inverted list, this is actually the bottom of the data)
            setShowFab(false);
        }
    };
    
    useEffect(() => {
        if (showFab) {
            // Animate FAB to appear
            Animated.parallel([
              Animated.timing(fabOpacity, {
                toValue: 1,
                duration: 200,
                useNativeDriver: true,
              }),
              Animated.timing(fabScale, {
                toValue: 1,
                duration: 200,
                useNativeDriver: true,
              }),
            ]).start();
        } else {
            // Animate FAB to disappear
            Animated.parallel([
              Animated.timing(fabOpacity, {
                toValue: 0,
                duration: 200,
                useNativeDriver: true,
              }),
              Animated.timing(fabScale, {
                toValue: 0,
                duration: 200,
                useNativeDriver: true,
              }),
            ]).start();
        }
    }, [showFab]);

    const insets = useSafeAreaInsets();

    // Memoize the styles to avoid recalculating them on each render
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);
    const fab_styles = useMemo(() => fabBtnStyles(is_darkmode), [is_darkmode]);
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    // Bottomsheet ref
    const bottomSheetRef = useRef(null);

    // Handle changes in the bottomsheet
    const handleSheetChanges = useCallback((index) => {
        console.log('handleSheetChanges', index);
    }, []);

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        dispatch(set_chat_state({ value: 'loading' }));
        let route_params = route.params; 

        // Update the timestamps for all chats at a certain interval
        chat_timestamp.current = setInterval(() => {
            dispatch(update_chat_timestamp({}));
        }, 15000); // Update every 15 seconds

        // Store the channel properties from the route parameters
        dispatch(set_channel_properties({ channel_id: route_params.channel_id, channel_image: route_params.channel_image, channel_name: route_params.channel_name, channel_type: route_params.channel_type, channel_uid: route_params.channel_uid, creator_id: route_params.creator_id, joined: route_params.joined, seen_chats: route_params.seen_chats, recent_chat_msg: route_params.recent_chat_msg, total_subs: route_params.total_subs, type: route_params.type }));
        await enter_screen(connectSocket, getSocket, controller, colorScheme, flatListRef);
    }, []);

    useFocusEffect(
        useCallback(() => {
            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                // Run this function when the screen loses focus
                disconnectSocket();
                controller.current.abort();
                controller.current = new AbortController();
                join_channel_controller.current.abort();
                join_channel_controller.current = new AbortController();
                delete_chat_controller.current.abort();
                delete_chat_controller.current = new AbortController();
                load_recent_chats_controller.current.abort();
                load_recent_chats_controller.current = new AbortController();
                refresh_controller.current.abort(); // Cancel refresh request
                refresh_controller.current = new AbortController();
                if (chat_timestamp.current){
                    clearInterval(chat_timestamp.current);
                }
                store.dispatch(reset_chat_data({}));
            };
        }, [])
    );

    return (
        <View style={[{ backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', flex: 1 }, all_watchlists_styles.native_header, { paddingBottom: insets.bottom }]}>
            {
                chat_state === true ?
                    <>
                        <ChatsFlatList flatListRef={flatListRef} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} set_delete_chat_loading_dialog={set_delete_chat_loading_dialog} delete_chat_controller={delete_chat_controller} getSocket={getSocket} fetch_recent_chats={fetch_recent_chats} set_fetch_recent_chats={set_fetch_recent_chats} load_recent_chats_controller={load_recent_chats_controller} handleScroll={handleScroll} handleScrollEnd={handleScrollEnd} />
                        {
                            reply_chat === false ?
                                <Animated.View
                                    style={[
                                        fab_styles.fabContainer,
                                        { opacity: fabOpacity, transform: [{ scale: fabScale }] },
                                    ]}
                                >
                                    <FAB
                                        icon={() => <Ionicons name="caret-down-circle-outline" size={25} color={is_darkmode === true ? "#FFFFFF" : "#000000"} />}
                                        style={fab_styles.fab}
                                        animated={true}
                                        onPress={scroll_to_bottom}
                                    />

                                    {/* Badge */}
                                    {no_of_new_chats_for_fab > 0 && (
                                        <View style={fab_styles.badgeContainer}>
                                            <Text style={fab_styles.badgeText}>{no_of_new_chats_for_fab > 9 ? '9+' : no_of_new_chats_for_fab}</Text>
                                        </View>
                                    )}
                                </Animated.View>
                            : <></>
                        }
                    </>
                : chat_state === false || chat_state === 'channel_unavailable' || chat_state === 'non_channel_member' || chat_state === 'join_private_channel' || chat_state === 'no_access_to_private_channel' || chat_state === 'initial_payment_incomplete' || chat_state === 'subscription_pending' ?
                    <ChatsFlatListError chat_state={chat_state} refreshing={refreshing} setRefreshing={setRefreshing} refresh_controller={refresh_controller} connectSocket={connectSocket} flatListRef={flatListRef} />
                : chat_state === 'loading' ?
                    <ChatsFlatListLoading />
                : chat_state === 'no_chats' ?
                    <ChatsFlatListNoChats />
                : <ChatsFlatListNoChats />
            }

            <BottomComponents navigation={navigation} controller={join_channel_controller} flatListRef={flatListRef} connectSocket={connectSocket} getSocket={getSocket} bottomSheetRef={bottomSheetRef} handleSheetChanges={handleSheetChanges} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} />

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}