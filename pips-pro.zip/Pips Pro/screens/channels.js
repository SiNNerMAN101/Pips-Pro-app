import { View, Text, useColorScheme } from "react-native";
import { StatusBar } from 'expo-status-bar';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useDispatch, useSelector } from 'react-redux';
import { useFocusEffect } from "@react-navigation/native";
import SegmentedControl from '@react-native-segmented-control/segmented-control';
import { MyChannels } from "../components/channels/MyChannels";
import { TopChannels } from "../components/channels/TopChannels";
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from "react-native-safe-area-context";
import { LoadingMyChannels } from "../components/channels/LoadingMyChannels";
import { LoadingTopChannels } from "../components/channels/LoadingTopChannels";
import { channels } from "../styles/channels";
import { connectSocket, disconnectSocket, getSocket } from '../reusable_methods/channels/socket_service';
import { enter_screen } from "../reusable_methods/channels/enter_screen";
import { NoDataAvailableTopChannels } from "../components/channels/NoDataAvailableTopChannels";
import { NoDataAvailableMyChannels } from "../components/channels/NoDataAvailableMyChannels";
import { ErrorMyChannels } from "../components/channels/ErrorMyChannels";
import { ErrorTopChannels } from "../components/channels/ErrorTopChannels";
import { NotLoggedIn } from "../components/channels/NotLoggedIn";
import { set_new_channel_created, set_refreshing, update_channel_timestamp } from "../state/channels";
import { Snackbar } from "react-native-paper";
import { snackBarStyles } from "../styles/snackbar";
import { LoadingDialog } from "../components/channels/LoadingDialog";
import { allWatchlists } from "../styles/all_watchlists";

export default function Channels({ navigation }) {
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // User current logged in state
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const channels_state = useSelector((state) => state.channels.channels_state); // Current state of both my channels and top channels tabs
    const my_channels = useSelector((state) => state.channels.my_channels); // List of channels that the user has joined
    const top_channels = useSelector((state) => state.channels.top_channels); // List of top trending channels
    const new_channel_created = useSelector((state) => state.channels.new_channel_created); // Detect when the user has created a new channel
    const [selectedIndex, setSelectedIndex] = useState(0); // Current index of the segmented control
    const controller = useRef(new AbortController());
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);
    const colorScheme = useColorScheme(); // Get the current system theme
    const refresh_controller = useRef(new AbortController());
    const channel_timestamp = useRef(null);
    const [fetch_more_channels, set_fetch_more_channels] = useState(true);
    const [loading_dialog, set_loading_dialog] = useState(false);
    const [loading_dialog_title, set_loading_dialog_title] = useState('');
    const load_more_channels_controller = useRef(new AbortController());
    const exit_delete_channel_controller = useRef(new AbortController());
    const dispatch = useDispatch();

    // Memoize the styles to avoid recalculating them on each render
    const channels_styles = useMemo(() => channels(is_darkmode), [is_darkmode]);
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    // Change the index of the segmented control
    const change_index = (index) => {
        setSelectedIndex(index);
    }

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        dispatch(update_channel_timestamp({}));
        
        // Update the timestamps for all channels at a certain interval
        channel_timestamp.current = setInterval(() => {
            dispatch(update_channel_timestamp({}));
        }, 15000); // Update every 15 seconds

        await enter_screen(connectSocket, getSocket, disconnectSocket, controller, colorScheme);
    }, []);

    // If the user logs out, disconnect the socket
    useEffect(() => {
        if (is_user_logged_in === false){
            disconnectSocket();
            set_fetch_more_channels(true);
            set_loading_dialog(false);
            set_loading_dialog_title('');
            exit_delete_channel_controller.current.abort();
            exit_delete_channel_controller.current = new AbortController();
        }
    }, [is_user_logged_in]);

    // If the user logs out, disconnect the socket
    useEffect(() => {
        if (new_channel_created === true){
            /* 
                If the user just created a new channel, send an event to the websockets server 
                to connect the user to the rooms of all the channels that the user has joined including 
                the new channel that the user just created
            */
            if (getSocket()){
                getSocket().emit('connect_to_channels');
            }
            
            dispatch(set_new_channel_created({ value: false }));
        }
    }, [new_channel_created]);

    useFocusEffect(
        useCallback(() => {
            execute();

            return () => {
                //disconnectSocket();
                controller.current.abort();
                controller.current = new AbortController();
                refresh_controller.current.abort(); // Cancel refresh request
                refresh_controller.current = new AbortController();
                load_more_channels_controller.current.abort();
                load_more_channels_controller.current = new AbortController();
                if (channel_timestamp.current){
                    clearInterval(channel_timestamp.current);
                }
                dispatch(set_refreshing({ value: false }));
            }
        }, [])
    )

    return (
        <View style={[channels_styles.container, all_watchlists_styles.native_header]}>
            <View style={channels_styles.segmented_ctrl_view}>
                <SegmentedControl
                    appearance={is_darkmode === true ? 'dark' : 'light'}
                    style={channels_styles.segmented_ctrl}
                    values={['My Channels', 'Top Channels']}
                    selectedIndex={selectedIndex}
                    onChange={(event) => {
                        change_index(event.nativeEvent.selectedSegmentIndex);
                    }}
                />
            </View>

            {
                selectedIndex === 0 ?
                    <>
                        {
                            channels_state === 'loading' ?
                                <LoadingMyChannels />
                            : channels_state === true ?
                                <>
                                    {
                                        my_channels.length > 0 ?
                                            <MyChannels navigation={navigation} fetch_more_channels={fetch_more_channels} set_fetch_more_channels={set_fetch_more_channels} load_more_channels_controller={load_more_channels_controller} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} getSocket={getSocket} set_loading_dialog={set_loading_dialog} set_loading_dialog_title={set_loading_dialog_title} exit_delete_channel_controller={exit_delete_channel_controller} />
                                        : <NoDataAvailableMyChannels navigation={navigation} />
                                    }
                                </>
                            : channels_state === false ?
                                <>
                                    {
                                        is_user_logged_in === true ?
                                            <ErrorMyChannels refresh_controller={refresh_controller} connectSocket={connectSocket} disconnectSocket={disconnectSocket} />
                                        : <NotLoggedIn navigation={navigation} />
                                    }
                                </>
                            : channels_state === 'not_logged_in' ?
                                <NotLoggedIn navigation={navigation} />
                            : <></>
                        }
                    </>
                :   <>
                        {
                            channels_state === 'loading' ?
                                <LoadingTopChannels />
                            : channels_state === true ? 
                                <>
                                    {
                                        top_channels.length > 0 ?
                                            <TopChannels navigation={navigation} />
                                        : <NoDataAvailableTopChannels />
                                    }
                                </>
                            : channels_state === false ?
                                <ErrorTopChannels refresh_controller={refresh_controller} connectSocket={connectSocket} disconnectSocket={disconnectSocket} />
                            : channels_state === 'not_logged_in' ?
                                <>
                                    {
                                        top_channels.length > 0 ?
                                            <TopChannels navigation={navigation} />
                                        : <NoDataAvailableTopChannels />
                                    }
                                </>
                            : <></>
                        }
                    </> 
            }

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>

            <LoadingDialog loading_dialog={loading_dialog} title={loading_dialog_title} />

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}