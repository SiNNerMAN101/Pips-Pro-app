import TopTabBar from "../routes/community_screen/top_tab_bar";

// The pipspro community
export default function Community({ navigation }) {

    return (
        <TopTabBar />
    );
}