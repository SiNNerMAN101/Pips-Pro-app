import { View, TouchableOpacity, Text } from "react-native";
import { WebView } from 'react-native-webview';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MaterialIcons, Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { useFocusEffect } from "@react-navigation/native";
import { useDispatch, useSelector } from 'react-redux';
import { render_technical_analysis_chart } from "../reusable_methods/chart/render_technical_analysis_chart";
import ViewShot from "react-native-view-shot";
import * as MediaLibrary from 'expo-media-library';
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from 'react-native-safe-area-context';
import { chart } from "../styles/chart";
import { Snackbar } from "react-native-paper";
import { snackBarStyles } from "../styles/snackbar";
import * as ScreenOrientation from 'expo-screen-orientation';
import { set_btm_sheet_index, set_btm_sheet_option, set_enable_btm_sheet } from "../state/chart";
import CreateTradeIdea from "../components/chart/CreateTradeIdea";
import FinalTouches from "../components/chart/FinalTouches";

export default function Chart({ navigation }) {
    const [hide_side_toolbar, set_hide_side_toolbar] = useState(true); // Keep track of the visibility of the drawing toolbar in the trading view chart 
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current darkmode state
    const [permissionResponse, requestPermission] = MediaLibrary.usePermissions();
    const [source_state, onSourceState] = useState({ html: render_technical_analysis_chart(hide_side_toolbar, is_darkmode) }) // Current contents of the webview
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);
    const [current_view, set_current_view] = useState(1); // The current view of the chart screen, Eg: 1 => Chart view and 2 => Create idea view
    const btm_sheet_option = useSelector((state) => state.chart.btm_sheet_option); // Keeps track of the options that the user selects in the menu bottom sheet
    const dispatch = useDispatch();
    const [title, set_title] = useState('');
    const [body, set_body] = useState('');
    const [form_info, set_form_info] = useState({ idea_type: 1, content: 1, read_length: 2 });

    // Memoize the styles to avoid recalculating them on each render
    const chart_styles = useMemo(() => chart(is_darkmode), [is_darkmode]);
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);

    // Reload the webview
    const reloadWebView = (value) => {
        if (current_view === 1){
            onSourceState({ html: `` });

            setTimeout(() => {
                onSourceState({ html: render_technical_analysis_chart(value, is_darkmode) });
            }, 30);
        }
    };

    const webViewRef = useRef(); // Create a ref for the WebView

    // Toggle side toolbar on or off
    const toggle_side_toolbar = () => {
        if (current_view === 1){
            let value = null;

            if (hide_side_toolbar === true){
                value = false;
            } else {
                value = true;
            }

            set_hide_side_toolbar(value);

            reloadWebView(value);
        }
    }

    // Capture an image of the technical analysis chart
    const open_menu_btm_sheet = async () => {
        dispatch(set_enable_btm_sheet({ value: true }));
        setTimeout(() => {
            dispatch(set_btm_sheet_index({ value: 0 }));
        }, 50);
    }

    // Function to unlock the orientation (allow any default orientation)
    const allowAnyOrientation = async () => {
        await ScreenOrientation.unlockAsync();
    };

    // Function to lock back to portrait when leaving the screen
    const lockToPortrait = async () => {
        await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    };

    useEffect(() => {
        reloadWebView(hide_side_toolbar);
    }, [is_darkmode]); // Dependency array

    useEffect(() => {
        if (btm_sheet_option === 1){ // Save chart image option
            dispatch(set_btm_sheet_option({ value: null }));
            const save_chart_image = async () => {
                try {
                    if (permissionResponse.status !== 'granted') {
                        await requestPermission();
                    }
                    webViewRef.current.capture().then(async uri => {
                        // Save the image to the device's storage
                        await MediaLibrary.createAssetAsync(uri);
                        set_snackbar_msg('Chart image saved');
                        set_snackbar_err(false);
                        set_snackbar_toggle(true);
                    });
                } catch (error) {
                    set_snackbar_msg('Unable to save chart image');
                    set_snackbar_err(true);
                    set_snackbar_toggle(true);
                }
            }

            save_chart_image();
        } else if (btm_sheet_option === 2){ // Create idea option
            dispatch(set_btm_sheet_option({ value: null })); 
            set_current_view(2);
        }
    }, [btm_sheet_option]); // Dependency array

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            allowAnyOrientation();
            onSourceState({ html: render_technical_analysis_chart(hide_side_toolbar, is_darkmode) });
    
            // Return a cleanup function to run when the screen loses focus
            return () => {
                // Run this function when the screen loses focus
                lockToPortrait(); // Lock back to portrait when leaving the screen
                dispatch(set_enable_btm_sheet({ value: false }));
                dispatch(set_btm_sheet_index({ value: -1 }));
            };
        }, [is_darkmode])
    );

    return (
        <SafeAreaView edges={['left', 'right', 'top']} style={chart_styles.container}>
            <View style={chart_styles.inner_container}>
                {
                    current_view === 1 ?
                        <ViewShot style={chart_styles.chart_container} ref={webViewRef} options={{ fileName: "Your-File-Name", format: "jpg", quality: 0.9 }}>
                            <WebView
                                scrollEnabled={false}
                                style={chart_styles.webview_comp}
                                originWhitelist={['*']}
                                javaScriptEnabled={true}
                                source={source_state}
                                domStorageEnabled={true}
                            />
                        </ViewShot>
                    : current_view === 2 ? 
                        <CreateTradeIdea set_current_view={set_current_view} title={title} body={body} set_title={set_title} set_body={set_body} />
                    : <FinalTouches set_current_view={set_current_view} navigation={navigation} title={title} body={body} form_info={form_info} set_form_info={set_form_info} />
                }

                <View style={chart_styles.btm_buttons}>
                    <TouchableOpacity style={chart_styles.left_and_right_btns} onPress={() => reloadWebView(hide_side_toolbar)}><MaterialIcons name="refresh" size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity> 
                    <TouchableOpacity style={chart_styles.center_btn} onPress={open_menu_btm_sheet}><Feather name="plus-circle" size={30} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity> 
                    <TouchableOpacity style={chart_styles.left_and_right_btns} onPress={toggle_side_toolbar}><MaterialCommunityIcons name={ hide_side_toolbar === true ? "pencil-off-outline" : "pencil-outline" } size={26} color={is_darkmode === true ? '#ffffff' : '#000000'} /></TouchableOpacity> 
                </View>
            </View>

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </SafeAreaView>
    );
}