import { View, Text, KeyboardAvoidingView, Platform, BackHandler } from "react-native";
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Dialog } from "@rneui/themed";
import { MaterialIcons } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Snackbar } from "react-native-paper";
import { snackBarStyles } from '../styles/snackbar';
import { Header } from "../components/login/Header";
import LoginContainer from "../components/login/LoginContainer";
import { LoadingDialog } from "../components/login/LoadingDialog";
import { useFocusEffect } from "@react-navigation/native";

export default function Login({ route, navigation }) {
    const insets = useSafeAreaInsets();
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);
    const [loading_modal, set_loading_modal] = useState(false);

    // Memoize the styles to avoid recalculating them on each render
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            const backAction = () => {
                // Navigate to the home screen
                navigation.navigate('WatchList');
                
                // Returning true prevents the default back action
                return true;
            };
        
            const backHandler = BackHandler.addEventListener(
                'hardwareBackPress',
                backAction
            );

            // Return a cleanup function to run when the screen loses focus
            return () => {
                backHandler.remove();
            };
        }, [])
    )

    return (
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ paddingTop: insets.top, backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', paddingLeft: insets.left, paddingRight: insets.right, paddingBottom: insets.bottom, flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Header navigation={navigation} />

            <LoginContainer route={route} navigation={navigation} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} loading_modal={loading_modal} set_loading_modal={set_loading_modal} />

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>

            <LoadingDialog loading_modal={loading_modal} />

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </KeyboardAvoidingView>
    );
}