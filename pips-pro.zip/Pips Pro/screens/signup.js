import { View, Text, KeyboardAvoidingView, ScrollView, TouchableOpacity, Platform } from "react-native";
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { authScreens } from "../styles/auth_screens";
import { SignupForm } from "../components/signup/SignupForm";
import { useSelector } from "react-redux";
import { Image } from "expo-image";
import { StatusBar } from "expo-status-bar";
import { useMemo, useState } from "react";
import { Header } from "../components/signup/Header";
import SignupContainer from "../components/signup/SignupContainer";
import { Snackbar } from "react-native-paper";
import { snackBarStyles } from "../styles/snackbar";
import { MaterialIcons } from '@expo/vector-icons';

export default function Signup({ route, navigation }) {
    const insets = useSafeAreaInsets();
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const [snackbar_toggle, set_snackbar_toggle] = useState(false);
    const [snackbar_msg, set_snackbar_msg] = useState('');
    const [snackbar_err, set_snackbar_err] = useState(false);

    // Memoize the styles to avoid recalculating them on each render
    const snackbar_styles = useMemo(() => snackBarStyles(snackbar_err), [snackbar_err]);

    return (
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ paddingTop: insets.top, backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', paddingLeft: insets.left, paddingRight: insets.right, paddingBottom: insets.bottom, flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Header navigation={navigation} />

            <SignupContainer route={route} navigation={navigation} snackbar_toggle={snackbar_toggle} set_snackbar_toggle={set_snackbar_toggle} snackbar_msg={snackbar_msg} set_snackbar_msg={set_snackbar_msg} snackbar_err={snackbar_err} set_snackbar_err={set_snackbar_err} />

            <Snackbar
                style={snackbar_styles.snack}
                theme={{ colors: { inversePrimary: '#ffffff' } }}
                visible={snackbar_toggle}
                duration={2000}
                onDismiss={() => set_snackbar_toggle(false)}
                action={{
                    label: 'Close',
                    labelStyle: snackbar_styles.label,
                    onPress: () => {
                        // Do something
                    },
                }}
            >
                <View style={snackbar_styles.container}>
                    <MaterialIcons name={snackbar_err === true ? "info-outline" : "check-circle-outline"} size={24} color="white" />
                    <Text style={snackbar_styles.msg}>{snackbar_msg}</Text>
                </View>
            </Snackbar>

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </KeyboardAvoidingView>
    );
}