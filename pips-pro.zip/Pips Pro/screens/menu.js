import React, { useCallback, useMemo, useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TouchableWithoutFeedback } from "react-native";
import { watchList } from "../styles/watchlist";
import { useSelector, useDispatch } from 'react-redux';
import { Image } from 'expo-image';
import { Ionicons, Feather, MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import { Avatar, Switch } from '@rneui/themed';
import { set_darkmode } from '../state/loginState';
import { StatusBar } from 'expo-status-bar';
import { list_items } from '../reusable_methods/menu/list_items';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { handle_item_click } from '../reusable_methods/menu/handle_item_click';
import { useFocusEffect } from '@react-navigation/native';
import { UserProfileImageLoad } from '../components/menu/UserProfileImageLoad';
import { allWatchlists } from '../styles/all_watchlists';

export default function Menu({ navigation }) {
    const user_details = useSelector((state) => state.login_state.user_details); // User current account details
    const is_user_logged_in = useSelector((state) => state.login_state.logged_in); // User current logged in state
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const dispatch = useDispatch();
    const controller = useRef(new AbortController());

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    // All menu items
    let menu_items = list_items();

    // Filter out "Sign out" item if user is not logged in
    if (!is_user_logged_in) {
        menu_items = menu_items.filter(item => item.item_name !== 'Sign out');
    }

    // Filter out "Sign in" item if the user is logged in
    if (is_user_logged_in) {
        menu_items = menu_items.filter(item => item.item_name !== 'Sign in');
    }

    // Toggle darkmode on or off
    const toggleSwitch = async (value) => {
        dispatch(set_darkmode({ value: value }));

        try {
            await AsyncStorage.setItem('darkmode', JSON.stringify({ value: value })); // Store the users details with async storage
        } catch (e) {
            // saving error
        }
    };
  
    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort(); // Cancel all pending requests
                controller.current = new AbortController();
            }
        }, [])
    )

    return (
        <View style={[{ backgroundColor: is_darkmode === true ? '#000000' : '#ffffff', marginRight: 0, marginBottom: 0, marginTop: 0, flex: 1 }, all_watchlists_styles.native_header]}>
            <ScrollView style={{ flex: 1 }}>
                { 
                    is_user_logged_in === true ? 
                        <TouchableWithoutFeedback onPress={() => navigation.navigate('UserProfile')}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: is_darkmode === true ? '#292219' : '#fbf3e8', padding: 14, margin: 17, marginBottom: 36, borderRadius: 10 }}>
                                { 
                                    user_details.profile_image === null || user_details.profile_image === undefined ? 
                                        <Avatar
                                            size={50}
                                            rounded
                                            titleStyle={{ color: '#ffffff' }}
                                            title={user_details.username.charAt(0)}
                                            containerStyle={{ backgroundColor: user_details.color_code, borderRadius: 100 }}
                                        />
                                    : <UserProfileImageLoad img_url={user_details.profile_image} user_name={user_details.username} color_code={user_details.color_code} size={50} /> 
                                }

                                <Text numberOfLines={1} ellipsizeMode="tail" style={{ fontSize: 17, fontWeight: 'bold', fontFamily: 'RobotoBold', marginLeft: 13, color: is_darkmode === true ? '#ffffff' : '#000000', marginBottom: 2, maxWidth: 243 }}>{ user_details.username }</Text>
                            </View>
                        </TouchableWithoutFeedback>
                    : <></>
                }

                <View style={{ marginTop: is_user_logged_in === true ? 0 : 37 }}>
                    {menu_items.map((item, index) => (
                        <TouchableOpacity onPress={() => handle_item_click(item.item_name, navigation)} key={index} style={{ marginBottom: 20, flexDirection: 'row', justifyContent: 'space-between', marginLeft: 17, borderBottomColor: is_darkmode === true ? '#3a3a3a' : '#b5b5b5', height: 41.5, alignItems: 'center', paddingBottom: 10, borderBottomWidth: 0.5, borderStyle: 'solid' }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                {
                                    item.icon_category === 'ionicons' ?
                                        <Ionicons name={item.icon_name} size={23} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                                    : item.icon_category === 'feather' ?
                                        <Feather name={item.icon_name} size={23} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                                    : item.icon_category === 'materialcommunityicons' ?
                                        <MaterialCommunityIcons name={item.icon_name} size={23} color={is_darkmode === true ? '#ffffff' : '#000000'} />
                                    : item.icon_category === 'materialicons' ?
                                        <MaterialIcons name={item.icon_name} size={23} color={item.item_name === 'Sign out' ? 'red' : (is_darkmode === true ? '#ffffff' : '#000000')} />
                                    : <></>
                                }

                                <Text style={{ fontSize: 17, fontFamily: 'RobotoRegular', marginLeft: 15, color: item.item_name === 'Sign out' ? 'red' : (is_darkmode === true ? '#ffffff' : '#000000') }}>{item.item_name}</Text>
                            </View>

                            {
                                item.item_name === 'Dark mode' ?
                                    <Switch
                                        color="#f19200"
                                        value={is_darkmode}
                                        style={{ marginRight: 17 }}
                                        onValueChange={(value) => toggleSwitch(value)}
                                    />
                                : <></>
                            }
                        </TouchableOpacity>
                    ))}
                </View>
            </ScrollView>

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}