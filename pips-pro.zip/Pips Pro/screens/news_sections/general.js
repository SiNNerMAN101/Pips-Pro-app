import { watchList } from "../../styles/watchlist";
import { useState, useRef, useCallback, useMemo } from "react";
import { useSelector } from 'react-redux';
import { StatusBar } from "expo-status-bar";
import { useFocusEffect } from "@react-navigation/native";
import { useColorScheme, Text, View } from 'react-native';
import PostsLoading from '../../components/user_profile/PostsLoading'
import PostsList from "../../components/community/PostsList";

// List of general news that consist of crypto, forex and stock
export default function General({ navigation }) {
    const controller = useRef(new AbortController());
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const top_picks_state = useSelector((state) => state.trade_ideas.top_picks_state); // The state of the top picks list
    const colorScheme = useColorScheme(); // Get the current system theme

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        //await enter_screen(controller, colorScheme);
    }, []);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort();
                controller.current = new AbortController();
            }
        }, [])
    )

    return (
        <View style={[watchList.container, { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }]}>
            {
                top_picks_state === 'loading' ?
                    <View style={{ flex: 1, paddingTop: 20 }}>
                        <PostsLoading />
                    </View> 
                : top_picks_state === true ?
                    <PostsList navigation={navigation} section={1} />
                : <></>
            }

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}