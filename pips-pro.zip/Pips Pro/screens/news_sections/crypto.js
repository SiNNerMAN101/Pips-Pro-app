import { watchList } from "../../styles/watchlist";
import { useRef, useCallback } from "react";
import { useSelector } from 'react-redux';
import { StatusBar } from "expo-status-bar";
import { useFocusEffect } from "@react-navigation/native";
import { useColorScheme, View } from 'react-native';
import PostsList from "../../components/community/PostsList";
import PostsLoading from "../../components/user_profile/PostsLoading";

// List of trading ideas whose contents are based on the crypto market
export default function Crypto({ navigation }) {
    const controller = useRef(new AbortController());
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const crypto_state = useSelector((state) => state.trade_ideas.crypto_state); // The state of the crypto ideas list
    const colorScheme = useColorScheme(); // Get the current system theme

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        //await enter_screen(controller, colorScheme);
    }, []);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort();
                controller.current = new AbortController();
            }
        }, [])
    )

    return (
        <View style={[watchList.container, { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }]}>
            {
                crypto_state === 'loading' ?
                    <View style={{ flex: 1, paddingTop: 20 }}>
                        <PostsLoading />
                    </View> 
                : crypto_state === true ?
                    <PostsList navigation={navigation} section={5} />
                : <></>
            }

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}