import { watchList } from "../../styles/watchlist";
import { useRef, useCallback, useMemo } from "react";
import { useSelector } from 'react-redux';
import { StatusBar } from "expo-status-bar";
import { useFocusEffect } from "@react-navigation/native";
import { useColorScheme, View } from 'react-native';
import PostsList from "../../components/community/PostsList";
import PostsLoading from "../../components/user_profile/PostsLoading";
import { postContentStyles } from "../../styles/community/post_content_styles";

// List of posts based on the forex market
export default function Forex({ navigation }) {
    const controller = useRef(new AbortController());
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const forex_state = useSelector((state) => state.community.forex_state); // The state of the forex posts list
    const colorScheme = useColorScheme(); // Get the current system theme

    // Memoize the styles to avoid recalculating them on each render
    const post_content_styles = useMemo(() => postContentStyles(is_darkmode), [is_darkmode]);

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        //await enter_screen(controller, colorScheme);
    }, []);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort();
                controller.current = new AbortController();
            }
        }, [])
    )

    return (
        <View style={[watchList.container, post_content_styles.content]}>
            {
                forex_state === 'loading' ?
                    <View style={{ flex: 1, paddingTop: 20 }}>
                        <PostsLoading />
                    </View> 
                : forex_state === true ?
                    <PostsList navigation={navigation} section={4} />
                : <></>
            }

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}