import { watchList } from "../styles/watchlist";
import { useState, useRef, useCallback, useMemo } from "react";
import { useSelector } from 'react-redux';
import { ActiveWatchlist } from "../components/watchlist/ActiveWatchlist";
import { StatusBar } from "expo-status-bar";
import { useFocusEffect } from "@react-navigation/native";
import { LoadingComp } from "../components/watchlist/active_watchlist_comp/LoadingComp";
import { enter_screen } from "../reusable_methods/watchlist/enter_screen";
import { WatchlistData } from "../components/watchlist/WatchlistData";
import { Error } from "../components/watchlist/Error";
import { useColorScheme, Text, View } from 'react-native';
import { allWatchlists } from "../styles/all_watchlists";

// View current active watchlist
export default function WatchList({ navigation }) {
    const [refreshing, setRefreshing] = useState(false);
    const controller = useRef(new AbortController());
    const refresh_controller = useRef(new AbortController());
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // Current state of darkmode
    const watchlist_state = useSelector((state) => state.watch_list_state.watchlist_state); // Current watchlist state
    const active_watchlist_name = useSelector((state) => state.watch_list_state.active_watchlist_name); // The users active watchlist name
    const colorScheme = useColorScheme(); // Get the current system theme

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        await enter_screen(controller, colorScheme);
    }, []);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort(); // Cancel all pending requests
                controller.current = new AbortController();
                refresh_controller.current.abort(); // Cancel refresh request
                refresh_controller.current = new AbortController();
                setRefreshing(false);
            }
        }, [])
    )

    return (
        <View style={[watchList.container, { backgroundColor: is_darkmode === true ? '#000000' : '#ffffff' }, all_watchlists_styles.native_header]}>
            {
                watchlist_state === true ?
                    <ActiveWatchlist navigation={navigation} refreshing={refreshing} refresh_controller={refresh_controller} setRefreshing={setRefreshing} />
                : watchlist_state === false || watchlist_state === 'non_active' || watchlist_state === 'no_watchlist' || watchlist_state === 'deleted' ?
                    <>
                        {
                            watchlist_state === false ?
                                <Text style={[watchList.active_watchlist_name, { color: is_darkmode === true ? '#ffffff' : '#000000', marginHorizontal: 20 } ]}>{active_watchlist_name}</Text>
                            : <></>
                        }
        
                        <WatchlistData watchlist_state={watchlist_state} refreshing={refreshing} setRefreshing={setRefreshing} refresh_controller={refresh_controller} navigation={navigation} />
                    </>
                : watchlist_state === 'error' ?
                    <Error refreshing={refreshing} setRefreshing={setRefreshing} refresh_controller={refresh_controller} />
                : <LoadingComp />
            }

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}