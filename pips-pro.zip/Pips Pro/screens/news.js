import TopTabBar from "../routes/news_screen/top_tab_bar";

export default function News({ navigation }) {
    /*
        <AllNewsList navigation={navigation} handleSnapPress={handleSnapPress} news_scroll_ref={news_scroll_ref} />
        <ViewNewsArticleBottomSheet sheetRef={sheetRef} news_article={news_article} snapPoints={snapPoints} handleSheetChange={handleSheetChange} handleClosePress={handleClosePress} />
    */

    return (
        <TopTabBar />
    );
}