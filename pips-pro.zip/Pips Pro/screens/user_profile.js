import { RefreshControl, ScrollView, View } from "react-native";
import { watchList } from "../styles/watchlist";
import { useSelector } from 'react-redux';
import { StatusBar } from "expo-status-bar";
import { useCallback, useMemo, useRef, useState } from "react";
import { allWatchlists } from "../styles/all_watchlists";
import { useFocusEffect } from "@react-navigation/native";
import { enter_screen } from "../reusable_methods/all_watchlists/enter_screen";
import ProfileDetails from "../components/user_profile/ProfileDetails";
import PostsLoading from "../components/user_profile/PostsLoading";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import NoTradeIdeas from "../components/user_profile/NoTradeIdeas";
import Error from "../components/user_profile/Error";
import PostsList from "../components/user_profile/PostsList";
import { FAB } from "react-native-paper";
import { fabBtnStyles } from "../styles/fab_styles";

export default function UserProfile({ navigation }) {
    const [refreshing, setRefreshing] = useState(false);
    const is_darkmode = useSelector((state) => state.login_state.darkmode); // current state of darkmode
    const trade_ideas_state = useSelector((state) => state.trade_ideas.trade_ideas_state); // The state of the trade idea list
    const controller = useRef(new AbortController());
    const refresh_controller = useRef(new AbortController());

    const insets = useSafeAreaInsets();

    // Memoize the styles to avoid recalculating them on each render
    const all_watchlists_styles = useMemo(() => allWatchlists(is_darkmode), [is_darkmode]);
    const fab_styles = useMemo(() => fabBtnStyles(is_darkmode), [is_darkmode]);

    // Listen to pull to refresh event
    const onRefresh = useCallback(async () => {
        //await refresh_chats(refresh_controller, setRefreshing, connectSocket, flatListRef);
    }, []);

    // Run this function to check if the user is logged in or not before clearing the splash screen
    const execute = useCallback(async () => {
        await enter_screen(controller);
    }, []);

    useFocusEffect(
        useCallback(() => {
            // Run this function when the screen gains focus
            execute();

            // Return a cleanup function to run when the screen loses focus
            return () => {
                controller.current.abort(); // Cancel all pending requests
                controller.current = new AbortController();
                refresh_controller.current.abort(); // Cancel refresh request
                refresh_controller.current = new AbortController();
                setRefreshing(false);
            }
        }, [])
    )

    return (
        <View style={[watchList.container, all_watchlists_styles.screen_bg_color, all_watchlists_styles.native_header, { paddingBottom: insets.bottom }]}>
            <ScrollView showsVerticalScrollIndicator={false} refreshControl={
                trade_ideas_state !== 'loading' ?
                    <RefreshControl
                        tintColor={is_darkmode ? '#ffffff' : '#000000'} // color of the spinner
                        colors={['#000000']} // Android-specific spinner color
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                    />
                : null
            }>
                <ProfileDetails navigation={navigation} />

                {   
                    trade_ideas_state === true ?
                        <PostsList navigation={navigation} />
                    : trade_ideas_state === 'loading' ?
                        <PostsLoading />
                    : trade_ideas_state === 'no_trade_ideas' ?
                        <NoTradeIdeas />
                    : trade_ideas_state === 'error' ?
                        <Error />
                    : <></>
                }
            </ScrollView>

            {
                trade_ideas_state === true ?
                    <View
                        style={fab_styles.fabContainer_for_user_profile}
                    >
                        <FAB
                            icon="plus"
                            color="#ffffff"
                            style={fab_styles.fab_user_profile}
                            onPress={() => navigation.navigate('CreateTradeIdea')}
                        />
                    </View>
                : null
            }

            <StatusBar style={is_darkmode === true ? "light" : "dark"} />
        </View>
    );
}