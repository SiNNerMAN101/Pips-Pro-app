import { createSlice } from '@reduxjs/toolkit'

/* Watchlist state values */
// 'error' => An error occured while fetching watchlist
// 'true' => The users watchlist is not empty
// 'false' => The users active watchlist is empty
// 'non_active' => No watchlist is active
// 'no_watchlist' => The user has no watchlists

const initialState = {
  active_watchlist_id: null,
  active_watchlist_name: 'Watchlist',
  active_watchlist: [],
  all_watchlists: [],
  search_symbols: [],
  watchlist_state: 'loading',
  all_watchlists_state: 'loading'
}

export const store_state = createSlice({
  name: 'watch_list_state',
  initialState,
  reducers: {
    set_active_watchlist_id: (state, action) => {
      state.active_watchlist_id = action.payload.value;
    },

    set_active_watchlist: (state, action) => {
      state.active_watchlist = action.payload.data;
    },

    set_active_watchlist_name: (state, action) => {
      state.active_watchlist_name = action.payload.value;
    },

    set_all_watchlists: (state, action) => {
      state.all_watchlists = action.payload.data;
    },

    set_search_symbols: (state, action) => {
      state.search_symbols = action.payload.data;
    },

    set_watchlist_state: (state, action) => {
      state.watchlist_state = action.payload.value;
    },

    set_all_watchlists_state: (state, action) => {
      state.all_watchlists_state = action.payload.value;
    },

    update_all_watchlists: (state, action) => {
      let all_watchlists = state.all_watchlists; // Get all watchlists array
      all_watchlists.unshift(action.payload.data); // Push the new watchlist into the array

      // Update the index of all elements in the array
      for (const [index, watchlist] of all_watchlists.entries()) {
        watchlist['index'] = index;
      }
      
      state.all_watchlists_state = true;
      state.all_watchlists = all_watchlists; // Update the all watchlists array
    },

    select_active_watchlist: (state, action) => {
      let all_watchlists = state.all_watchlists; // Get all watchlists array
      let current_watchlist_id = action.payload.current_watchlist_id;

      for (const [index, watchlist] of all_watchlists.entries()) {
        watchlist['active_watchlist_id'] = current_watchlist_id;
      }

      state.all_watchlists = all_watchlists; // Update the all watchlists array
      state.active_watchlist_id = current_watchlist_id; // Set the new active watchlist ID
      state.watchlist_state = 'loading'; // Display the skeleton loader on the watchlist screen
    },

    rename_user_watchlist: (state, action) => {
      let all_watchlists = state.all_watchlists; // Get all watchlists array
      let current_watchlist_id = action.payload.current_watchlist_id; // The ID of the watchlist that the user wants to rename
      let new_watchlist_name = action.payload.new_watchlist_name; // The new name to replace the watchlists current name

      for (const [index, watchlist] of all_watchlists.entries()) {
        if (watchlist['id'] === current_watchlist_id){
          watchlist['name'] = new_watchlist_name;
        };
      }

      state.all_watchlists = all_watchlists; // Update the all watchlists array
    },

    delete_user_watchlist: (state, action) => {
      let all_watchlists = state.all_watchlists; // Get all watchlists array
      let current_watchlist_id = action.payload.current_watchlist_id; // The ID of the watchlist that the user wants to delete
      let new_all_watchlists_array = [];

      for (const [index, watchlist] of all_watchlists.entries()) {
        if (watchlist['id'] !== current_watchlist_id){
          new_all_watchlists_array.push(watchlist);
        };
      }

      if (new_all_watchlists_array.length > 0){
        state.all_watchlists = new_all_watchlists_array; // Update the all watchlists array
      } else {
        state.all_watchlists_state = false;
        state.all_watchlists = [];
      }
    }
  },
})

// Action creators are generated for each case reducer function
export const { set_active_watchlist_id, set_active_watchlist, set_active_watchlist_name, set_all_watchlists, set_search_symbols, set_watchlist_state, set_all_watchlists_state, update_all_watchlists, select_active_watchlist, rename_user_watchlist, delete_user_watchlist } = store_state.actions

export default store_state.reducer