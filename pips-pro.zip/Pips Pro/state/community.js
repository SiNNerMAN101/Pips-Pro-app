import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    for_you_section: [
        {
            id: 0,
            post_id: 13,
            post_desc: '<p>Bitcoin\'s Rally Toward $62,000</p>',
            fullname: 'James',
            username: 'James',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp', media_type: 'image' }],
            total_views: 33,
            total_comments: 21,
            total_reposts: 5,
            total_reactions: 15,
            reactions: [{ reaction_id: 1, total: 7, user_reacted: false }, { reaction_id: 2, total: 9, user_reacted: false }, { reaction_id: 3, total: 12, user_reacted: false }, { reaction_id: 5, total: 10, user_reacted: false }],
            timestamp: '10h'
        },
        {
            id: 1,
            post_id: 17,
            post_desc: '<p>BITCOIN → The fall will continue after a pullback</p>',
            fullname: 'MillionGx',
            username: 'MillionGx',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [],
            total_views: 58,
            total_comments: 36,
            total_reposts: 8,
            total_reactions: 25,
            reactions: [{ reaction_id: 1, total: 10, user_reacted: false }, { reaction_id: 2, total: 8, user_reacted: false }, { reaction_id: 4, total: 7, user_reacted: false }],
            timestamp: '6h'
        },
    ],
    following_section: [
        {
            id: 0,
            post_id: 13,
            post_desc: 'Bitcoin\'s Rally Toward $62,000',
            fullname: 'James',
            username: 'James',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp', media_type: 'image' }],
            total_views: 33,
            total_comments: 21,
            total_reposts: 5,
            total_reactions: 15,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '10h'
        },
        {
            id: 1,
            post_id: 17,
            post_desc: 'BITCOIN → The fall will continue after a pullback',
            fullname: 'MillionGx',
            username: 'MillionGx',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp', media_type: 'image' }],
            total_views: 58,
            total_comments: 36,
            total_reposts: 8,
            total_reactions: 25,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '6h'
        },
    ],
    stock_section: [
        {
            id: 0,
            post_id: 13,
            post_desc: 'Bitcoin\'s Rally Toward $62,000',
            fullname: 'James',
            username: 'James',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp', media_type: 'image' }],
            total_views: 33,
            total_comments: 21,
            total_reposts: 5,
            total_reactions: 15,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '10h'
        },
        {
            id: 1,
            post_id: 17,
            post_desc: 'BITCOIN → The fall will continue after a pullback',
            fullname: 'MillionGx',
            username: 'MillionGx',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp', media_type: 'image' }],
            total_views: 58,
            total_comments: 36,
            total_reposts: 8,
            total_reactions: 25,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '6h'
        },
    ],
    forex_section: [
        {
            id: 0,
            post_id: 13,
            post_desc: 'Bitcoin\'s Rally Toward $62,000',
            fullname: 'James',
            username: 'James',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp', media_type: 'image' }],
            total_views: 33,
            total_comments: 21,
            total_reposts: 5,
            total_reactions: 15,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '10h'
        },
        {
            id: 1,
            post_id: 17,
            post_desc: 'BITCOIN → The fall will continue after a pullback',
            fullname: 'MillionGx',
            username: 'MillionGx',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp', media_type: 'image' }],
            total_views: 58,
            total_comments: 36,
            total_reposts: 8,
            total_reactions: 25,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '6h'
        },
    ],
    crypto_section: [
        {
            id: 0,
            post_id: 13,
            post_desc: 'Bitcoin\'s Rally Toward $62,000',
            fullname: 'James',
            username: 'James',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp', media_type: 'image' }],
            total_views: 33,
            total_comments: 21,
            total_reposts: 5,
            total_reactions: 15,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '10h'
        },
        {
            id: 1,
            post_id: 17,
            post_desc: 'BITCOIN → The fall will continue after a pullback',
            fullname: 'MillionGx',
            username: 'MillionGx',
            profile_image: null,
            color_code: '#FF33AA',
            attachments: [{ url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp', media_type: 'image' }],
            total_views: 58,
            total_comments: 36,
            total_reposts: 8,
            total_reactions: 25,
            reactions: [{ reaction_id: 'reaction-id:1', user_reacted: false }, { reaction_id: 'reaction-id:2', user_reacted: false }, { reaction_id: 'reaction-id:3', user_reacted: false }],
            timestamp: '6h'
        },
    ],
    for_you_state: true,
    following_state: 'loading',
    stock_state: 'loading',
    forex_state: 'loading',
    crypto_state: 'loading'
}

export const store_state = createSlice({
    name: 'community',
    initialState,
    reducers: {
        set_for_you_state: (state, action) => {
            state.for_you_state = action.payload.value;
        },
        set_following_state: (state, action) => {
            state.following_state = action.payload.value;
        },
        set_stock_state: (state, action) => {
            state.stock_state = action.payload.value;
        },
        set_forex_state: (state, action) => {
            state.forex_state = action.payload.value;
        },
        set_crypto_state: (state, action) => {
            state.crypto_state = action.payload.value;
        },
        reset_data: (state, action) => {
            state.trade_ideas = [];
            state.for_you_section = [];
            state.following_section = [];
            state.stock_section = [];
            state.forex_section = [];
            state.crypto_section = [];
            state.for_you_state = true;
            state.following_state = 'loading';
            state.stock_state = 'loading';
            state.forex_state = 'loading';
            state.crypto_state = 'loading';
        }
    }
})

// Action creators are generated for each case reducer function
export const { set_for_you_state, set_following_state, set_stock_state, set_forex_state, set_crypto_state, reset_data } = store_state.actions

export default store_state.reducer