import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    trade_ideas: [
        {
            id: 0,
            trade_idea_id: 13,
            title: 'Bitcoin\'s Rally Toward $62,000',
            main_media_url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp',
            media_type: 'image',
            date: 'Sep 6',
            comments: 32,
            likes: 284
        },
        {
            id: 1,
            trade_idea_id: 15,
            title: 'BITCOIN → The fall will continue after a pullback',
            main_media_url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp',
            media_type: 'image',
            date: 'Aug 13',
            comments: 15,
            likes: 120
        }
    ],
    top_picks: [
        {
            id: 0,
            trade_idea_id: 13,
            title: 'Bitcoin\'s Rally Toward $62,000',
            user: 'James',
            main_media_url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp',
            media_type: 'image',
            date: 'Sep 6',
            comments: 32,
            likes: 284
        },
        {
            id: 1,
            trade_idea_id: 15,
            title: 'BITCOIN → The fall will continue after a pullback',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp',
            media_type: 'image',
            date: 'Aug 13',
            comments: 15,
            likes: 120
        }
    ],
    following: [
        {
            id: 0,
            trade_idea_id: 13,
            title: 'Bitcoin\'s Rally Toward $62,000',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp',
            media_type: 'image',
            date: 'Sep 6',
            comments: 32,
            likes: 284
        },
        {
            id: 1,
            trade_idea_id: 15,
            title: 'BITCOIN → The fall will continue after a pullback',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp',
            media_type: 'image',
            date: 'Aug 13',
            comments: 15,
            likes: 120
        }
    ],
    stock: [
        {
            id: 0,
            trade_idea_id: 13,
            title: 'Bitcoin\'s Rally Toward $62,000',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp',
            media_type: 'image',
            date: 'Sep 6',
            comments: 32,
            likes: 284
        },
        {
            id: 1,
            trade_idea_id: 15,
            title: 'BITCOIN → The fall will continue after a pullback',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp',
            media_type: 'image',
            date: 'Aug 13',
            comments: 15,
            likes: 120
        }
    ],
    forex: [
        {
            id: 0,
            trade_idea_id: 13,
            title: 'Bitcoin\'s Rally Toward $62,000',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp',
            media_type: 'image',
            date: 'Sep 6',
            comments: 32,
            likes: 284
        },
        {
            id: 1,
            trade_idea_id: 15,
            title: 'BITCOIN → The fall will continue after a pullback',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp',
            media_type: 'image',
            date: 'Aug 13',
            comments: 15,
            likes: 120
        }
    ],
    crypto: [
        {
            id: 0,
            trade_idea_id: 13,
            title: 'Bitcoin\'s Rally Toward $62,000',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/o/ocoytJe5_mid.webp',
            media_type: 'image',
            date: 'Sep 6',
            comments: 32,
            likes: 284
        },
        {
            id: 1,
            trade_idea_id: 15,
            title: 'BITCOIN → The fall will continue after a pullback',
            user: 'MillionGx',
            main_media_url: 'https://s3.tradingview.com/t/Tz4zeVfl_mid.webp',
            media_type: 'image',
            date: 'Aug 13',
            comments: 15,
            likes: 120
        }
    ],
    top_picks_state: true,
    following_state: 'loading',
    stock_state: 'loading',
    forex_state: 'loading',
    crypto_state: 'loading',
    trade_ideas_state: true
}

export const store_state = createSlice({
    name: 'trade_ideas',
    initialState,
    reducers: {
        set_trade_ideas: (state, action) => {
            state.trade_ideas = action.payload.data;
        },
        set_trade_ideas_state: (state, action) => {
            state.trade_ideas_state = action.payload.value;
        },
        reset_data: (state, action) => {
            state.trade_ideas = [];
            state.top_picks = [];
            state.following = [];
            state.stock = [];
            state.forex = [];
            state.crypto = [];
            state.top_picks_state = true;
            state.following_state = 'loading';
            state.stock_state = 'loading';
            state.forex_state = 'loading';
            state.crypto_state = 'loading';
            state.trade_ideas_state = true;
        }
    }
})

// Action creators are generated for each case reducer function
export const { set_trade_ideas, set_trade_ideas_state, reset_data } = store_state.actions

export default store_state.reducer