import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  news_state: 'loading'
}

export const store_state = createSlice({
  name: 'news',
  initialState,
  reducers: {
    set_news_state: (state, action) => {
      state.news_state = action.payload.value;
    }
  },
})

// Action creators are generated for each case reducer function
export const { set_news_state } = store_state.actions

export default store_state.reducer