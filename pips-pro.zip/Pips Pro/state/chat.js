import { createSlice } from '@reduxjs/toolkit'
import { format_datetime } from '../reusable_methods/format_datetime';

const initialState = {
    messages: [],
    in_chats_screen: false,
    page: 1,
    chat_state: 'loading',
    err_msg: '',
    send_msg_btn_state: false,
    reply_chat: false,
    new_chat_notif_sound: true,
    no_of_new_chats_at_the_moment: 5,
    no_of_new_chats_for_fab: 0,
    scrolled_away_from_bottom: false,
    reply_data: {
        chat: '',
        chat_id: 0,
        chat_type: 1,
        color_code: '#FFFFFF',
        user_id: 0,
        username: ''
    },
    reply_to_chat_id: 0,
    channel_properties: {
        channel_id: 0, 
        channel_image: null, 
        channel_name: '', 
        channel_type: 'public', 
        channel_uid: '', 
        creator_id: 0, 
        joined: false, 
        seen_chats: false,
        recent_chat_msg: {
            chat: null, chat_type: null, datetime: null
        }, 
        total_subs: 0,
        type: ''
    }
}

export const store_state = createSlice({
    name: 'chat_state',
    initialState,
    reducers: {
        set_messages: (state, action) => {
            let messages = action.payload.data;

            for (const [i, chat] of messages.entries()){
                chat['id'] = i;
                chat['formatted_date'] = format_datetime(chat['createdAt']);
            }

            state.messages = messages;
        },

        set_in_chats_screen: (state, action) => {
            state.in_chats_screen = action.payload.value;
        },

        set_page: (state, action) => {
            state.page = action.payload.value;
        },

        update_messages: (state, action) => {
            let new_chat = action.payload.data;
            new_chat['id'] = 0;
            new_chat['formatted_date'] = format_datetime(new_chat['createdAt']);
            for (const [index, chat] of state.messages.entries()) {
                chat['id'] = index + 1;
            }
            state.messages.unshift(new_chat);
        },

        new_chat_received: (state, action) => {
            let new_chat = action.payload.data;
            new_chat['id'] = 0;
            new_chat['formatted_date'] = format_datetime(new_chat['createdAt']);
            new_chat['sent_msg'] = true;
            for (const [index, chat] of state.messages.entries()) {
                chat['id'] = index + 1;
            }
            state.messages.unshift(new_chat);
        },

        delete_chat: (state, action) => {
            state.messages.splice(action.payload.value, 1); // Remove the existing chat from the messages array

            if (state.messages.length > 0){
                for (const [index, chat] of state.messages.entries()) {
                    chat['id'] = index;
                }
            } else {
                state.chat_state = 'no_chats';
            }
        },

        update_my_message: (state, action) => {
            let new_chat = action.payload.data;

            for (const [index, chat] of state.messages.entries()) {
                if (chat.hasOwnProperty('uuid')){
                    if (chat['uuid'] === new_chat['uuid']){
                        delete new_chat['uuid']; // Remove the uuid from the new chat
                        let id = chat['id'];
                        new_chat['id'] = id;
                        new_chat['sent_msg'] = true;
                        new_chat['formatted_date'] = format_datetime(new_chat['createdAt']);
                        state.messages.splice(index, 1, new_chat); // Replace the existing chat with the new chat
                        break;
                    }
                }
            }
        },

        set_chat_state: (state, action) => {
            state.chat_state = action.payload.value;
        },

        set_err_msg: (state, action) => {
            state.err_msg = action.payload.value;
        },

        update_chat_timestamp: (state, action) => {
            if (state.chat_state === true){
                if (state.messages.length > 0){
                    for (const [i, chat] of state.messages.entries()){
                        let createdAt = chat['createdAt'];
                        chat['formatted_date'] = format_datetime(createdAt);
                    }
                }
            }
        },

        load_more_recent_chats: (state, action) => {
            let recent_chats = action.payload.chats; // The recent chats fetched from the server
            let all_messages = state.messages; // All the chats for the channel at the current moment

            // Push all the recent chats into the all messages array
            for (const [i, chat] of recent_chats.entries()) {
                let count = 0;

                for (const [index, current_chat] of all_messages.entries()) {
                    if (chat['chat_id'] === current_chat['chat_id']){
                        count = count + 1;
                    }
                }

                if (count === 0){
                    chat['formatted_date'] = format_datetime(chat['createdAt']);
                    all_messages.push(chat);
                }
            }

            // Replace the IDs with new ones
            for (const [i, chat] of all_messages.entries()) {
                chat['id'] = i;
            }
            
            state.messages = all_messages; // Update the messages state array
        },

        set_send_msg_btn_state: (state, action) => {
            state.send_msg_btn_state = action.payload.value;
        },

        set_reply_chat: (state, action) => {
            state.reply_chat = action.payload.value;
        },

        set_reply_to_chat_id: (state, action) => {
            state.reply_to_chat_id = action.payload.value;
        },

        set_channel_properties: (state, action) => {
            state.channel_properties = action.payload;
        },

        add_user_to_channel: (state, action) => {
            let channel_properties = state.channel_properties;
            channel_properties.joined = true;
            state.channel_properties = channel_properties;
        },

        modify_reply_data: (state, action) => {
            state.reply_data = action.payload.data;
            state.reply_chat = action.payload.value;
            state.reply_to_chat_id = action.payload.id;
        },

        set_new_chat_notif_sound: (state, action) => {
            state.new_chat_notif_sound = action.payload.value;
        },

        set_no_of_new_chats_at_the_moment: (state, action) => {
            state.no_of_new_chats_at_the_moment = action.payload.value;
        },

        set_no_of_new_chats_for_fab: (state, action) => {
            state.no_of_new_chats_for_fab = action.payload.value;
        },

        set_scrolled_away_from_bottom: (state, action) => {
            state.scrolled_away_from_bottom = action.payload.value;
        },

        update_deleted_chat: (state, action) => {
            let chat_to_delete = action.payload.chat_to_delete; // The particular chat that is getting deleted

            for (const [i, chat] of state.messages.entries()) {
                if (chat['chat_id'] === chat_to_delete['chat_id']){
                    state.messages.splice(i, 1); // Remove the chat from the messages array
                }
            }
        },

        reset_chat_data: (state, action) => {
            state.messages = [];
            state.in_chats_screen = false;
            state.page = 1;
            state.chat_state = 'loading';
            state.err_msg = '';
            state.send_msg_btn_state = false;
            state.reply_chat = false;
            state.new_chat_notif_sound = true;
            state.no_of_new_chats_at_the_moment = 5;
            state.no_of_new_chats_for_fab = 0;
            state.scrolled_away_from_bottom = false;
            state.reply_data = {
                chat: '',
                chat_id: 0,
                chat_type: 1,
                color_code: '#FFFFFF',
                user_id: 0,
                username: ''
            };
            state.reply_to_chat_id = 0;
            state.channel_properties = {
                channel_id: 0, 
                channel_image: null, 
                channel_name: state.channel_properties.channel_name, 
                channel_type: 'public', 
                channel_uid: '', 
                creator_id: 0, 
                joined: false, 
                seen_chats: false,
                recent_chat_msg: {
                    chat: null, chat_type: null, datetime: null
                }, 
                total_subs: 0,
                type: ''
            }
        }
    },
})

// Action creators are generated for each case reducer function
export const { set_messages, set_in_chats_screen, set_page, update_messages, new_chat_received, delete_chat, update_my_message, set_chat_state, set_err_msg, update_chat_timestamp, load_more_recent_chats, set_send_msg_btn_state, set_reply_chat, set_reply_to_chat_id, set_channel_properties, add_user_to_channel, modify_reply_data, set_new_chat_notif_sound, set_no_of_new_chats_at_the_moment, set_no_of_new_chats_for_fab, set_scrolled_away_from_bottom, update_deleted_chat, reset_chat_data } = store_state.actions

export default store_state.reducer;