import { createSlice } from '@reduxjs/toolkit'
import { format_datetime } from '../reusable_methods/format_datetime';

const initialState = {
    my_channels: [],
    top_channels: [],
    my_channels_state: 'loading',
    top_channels_state: 'loading',
    my_channels_page: 1,
    channels_state: 'loading',
    new_channel_created: false,
    refreshing: false
}

export const store_state = createSlice({
    name: 'channels_state',
    initialState,
    reducers: {
        set_my_channels: (state, action) => {
            let my_channels = action.payload.data;
            for (const [i, channel] of my_channels.entries()){
                if (channel['recent_chat_msg']['datetime'] !== null){
                    channel['recent_chat_msg']['formatted_date'] = format_datetime(channel['recent_chat_msg']['datetime']);
                }
            }
            state.my_channels = my_channels;
        },
        set_new_channel_created: (state, action) => {
            state.new_channel_created = action.payload.value;
        },
        add_new_channel: (state, action) => {
            let new_channel = action.payload.new_channel;
            let my_channels = state.my_channels;
            let found_match = 0;

            for (const [i, channel] of my_channels.entries()) {
                if (channel['channel_id'] === new_channel['channel_id']){
                    found_match = found_match + 1;
                }
            }

            for (const [i, channel] of state.top_channels.entries()) {
                if (channel['channel_id'] === new_channel['channel_id']){
                    channel['total_subs'] = channel['total_subs'] + 1;
                    channel['joined'] = true;
                }
            }

            if (found_match === 0){
                my_channels.unshift(new_channel);

                for (const [i, channel] of my_channels.entries()){
                    channel['id'] = i;
                }
                
                state.my_channels = my_channels;
            }
        },
        deleted_chat_channel_update: (state, action) => {
            let chat_to_delete = action.payload.chat_to_delete; // The particular chat that is getting deleted
            let logged_in = action.payload.logged_in; // To know if the user is logged in or not
            
            if (logged_in === true){ // Check if the user is logged in
                if (state.channels_state === true){ // Check if there are no errors in the channels screen
                    if (state.my_channels.length > 0){ // Check if there are any channels in the my channels section
                        for (const [i, channel] of state.my_channels.entries()) {
                            if (chat_to_delete['channel_id'] === channel['channel_id']){
                                if (chat_to_delete['chat_id'] === channel['recent_chat_msg']['chat_id']){
                                    channel['type'] = "msg_deleted";
                                }
                            }
                        }
                    }
                }
            }
        },
        set_top_channels: (state, action) => {
            state.top_channels = action.payload.data;
        },
        set_my_channels_state: (state, action) => {
            state.my_channels_state = action.payload.value;
        },
        set_top_channels_state: (state, action) => {
            state.top_channels_state = action.payload.value;
        },
        set_channels_state: (state, action) => {
            state.channels_state = action.payload.value;
        },
        update_my_channels: (state, action) => {
            let channel_update = action.payload.data;
            if (channel_update['recent_chat_msg']['datetime'] !== null){
                channel_update['recent_chat_msg']['formatted_date'] = format_datetime(channel_update['recent_chat_msg']['datetime']);
            }
            let new_array = state.my_channels;
            new_array.unshift(channel_update);

            for (const [i, channel] of new_array.entries()) {
                channel['id'] = i;
            }

            state.my_channels = new_array;
        },
        update_top_channels: (state, action) => {
            let new_array = state.top_channels;
            new_array.unshift(action.payload.data);

            for (const [i, channel] of new_array.entries()) {
                channel['id'] = i;
            }

            state.top_channels = new_array;
        },
        update_a_channel_in_my_channels: (state, action) => {
            let new_update = action.payload.data;
            let channel_id = action.payload.channel_id; // Asuming that the user is in the chats screen, this will be the current ID of the channel for the chats
            let in_chats_screen = action.payload.in_chats_screen;
            let my_channels = state.my_channels;
            let found_match = false;
            
            if (in_chats_screen === true){
                if (new_update['channel_id'] === channel_id){
                    new_update['seen_chats'] = true;
                }
            }

            for (const [i, channel] of my_channels.entries()) {
                if (channel.channel_id === new_update.channel_id){
                    my_channels.splice(i, 1);
                    found_match = true;
                    break;
                }
            }

            if (found_match === true){
                if (new_update['recent_chat_msg']['datetime'] !== null){
                    new_update['recent_chat_msg']['formatted_date'] = format_datetime(new_update['recent_chat_msg']['datetime']);
                }
                my_channels.unshift(new_update);

                for (const [i, channel] of my_channels.entries()) {
                    channel['id'] = i;
                }

                state.my_channels = my_channels;
            } else {
                if (new_update['recent_chat_msg']['datetime'] !== null){
                    new_update['recent_chat_msg']['formatted_date'] = format_datetime(new_update['recent_chat_msg']['datetime']);
                }
                my_channels.unshift(new_update);

                for (const [i, channel] of my_channels.entries()) {
                    channel['id'] = i;
                }

                state.my_channels = my_channels;
            }
        },
        mark_chats_as_seen_for_a_channel: (state, action) => {
            let channel_id = action.payload.channel_id; // ID of the channel that we want to mark the chats of as seen by the user
            let new_update = action.payload.data;

            for (const [i, channel] of state.my_channels.entries()) {
                if (channel.channel_id === channel_id){
                    if (new_update['creator_id'] === user_id){
                        new_update['seen_chats'] = true;
                    }
                    channel['seen_chats'] = true;
                }
            }
        },
        set_my_channels_page: (state, action) => {
            state.my_channels_page = action.payload.value;
        },
        load_my_channels: (state, action) => {
            let new_updates = action.payload.data;
            let my_channels = state.my_channels;

            if (new_updates.length > 0){
                for (const [i, channel_update] of new_updates.entries()){
                    for (const [ix, channel] of my_channels.entries()){
                        if (channel_update.channel_id === channel.channel_id){
                            my_channels.splice(ix, 1);
                        }
                    }    
                }

                for (const [i, channel_update] of new_updates.entries()){
                    if (channel_update['recent_chat_msg']['datetime'] !== null){
                        channel_update['recent_chat_msg']['formatted_date'] = format_datetime(channel_update['recent_chat_msg']['datetime']);
                    }
                    my_channels.push(channel_update);
                }

                for (const [i, channel] of my_channels.entries()){
                    channel['id'] = i;
                }

                state.my_channels = my_channels;
                state.my_channels_state(true);
            }
        },
        load_top_channels: (state, action) => {
            let new_updates = action.payload.data;
            let top_channels = state.top_channels;

            if (new_updates.length > 0){
                for (const [i, channel_update] of new_updates.entries()){
                    for (const [ix, channel] of top_channels.entries()){
                        if (channel_update.channel_id === channel.channel_id){
                            top_channels.splice(ix, 1);
                        }
                    }    
                }

                for (const [i, channel_update] of new_updates.entries()){
                    top_channels.push(channel_update);
                }

                for (const [i, channel] of top_channels.entries()){
                    channel['id'] = i;
                }

                state.top_channels = top_channels;
                state.top_channels_state(true);
            }
        },
        update_channel_timestamp: (state, action) => {
            if (state.channels_state === true){
                if (state.my_channels.length > 0){
                    for (const [i, channel] of state.my_channels.entries()){
                        if (channel['recent_chat_msg']['datetime'] !== null){
                            channel['recent_chat_msg']['formatted_date'] = format_datetime(channel['recent_chat_msg']['datetime']);
                        }
                    }
                }
            }
        },
        load_more_user_channels: (state, action) => {
            let more_channels = action.payload.channels; // The more channels fetched from the server
            let my_channels = state.my_channels; // All the users channels at the current moment

            // Push all the channels fetched into the my channels array
            for (const [i, channel] of more_channels.entries()) {
                let count = 0;

                for (const [index, current_channel] of my_channels.entries()) {
                    if (channel['channel_id'] === current_channel['channel_id']){
                        count = count + 1;
                    }
                }

                if (count === 0){
                    if (channel['recent_chat_msg']['chat_type'] !== null){
                        let recent_chat_msg_datetime = channel['recent_chat_msg']['datetime'];
                        channel['recent_chat_msg']['formatted_date'] = format_datetime(recent_chat_msg_datetime);
                        my_channels.push(channel);
                    } else {
                        my_channels.push(channel);
                    }
                }
            }

            // Replace the IDs with new ones
            for (const [i, channel] of my_channels.entries()) {
                channel['id'] = i;
            }
            
            state.my_channels = my_channels; // Update the my channels state array
        },
        update_channel_chats_seen_state: (state, action) => {
            for (const [index, channel] of state.my_channels.entries()) {
                if (channel['channel_id'] === action.payload.channel_id){
                    channel['seen_chats'] = true;
                }
            }
        },
        remove_channel: (state, action) => {
            for (const [index, channel] of state.my_channels.entries()) {
                if (channel['channel_id'] === action.payload.channel_id){
                    state.my_channels.splice(index, 1);
                }
            }

            for (const [index, channel] of state.top_channels.entries()) {
                if (channel['channel_id'] === action.payload.channel_id){
                    if (action.payload.state === 'delete_channel'){
                        state.top_channels.splice(index, 1);
                    } else {
                        channel['joined'] = false;
                        if (channel['total_subs'] > 0){
                            channel['total_subs'] = channel['total_subs'] - 1;
                        }
                    }
                }
            }
        },
        set_refreshing: (state, action) => {
            state.refreshing = action.payload.value;
        },
        reset_channels_state: (state, action) => {
            state.my_channels = [];
            state.top_channels = [];
            state.my_channels_state = 'loading';
            state.top_channels_state = 'loading';
            state.my_channels_page = 1;
            state.channels_state = 'loading';
            state.new_channel_created = false;
            state.refreshing = false;
        }
    },
})

// Action creators are generated for each case reducer function
export const { set_my_channels, set_new_channel_created, add_new_channel, deleted_chat_channel_update, set_top_channels, set_top_channels_state, set_channels_state, mark_chats_as_seen_for_a_channel, set_my_channels_state, update_my_channels, update_top_channels, update_a_channel_in_my_channels, set_my_channels_page, set_top_channels_page, load_my_channels, load_top_channels, update_channel_timestamp, load_more_user_channels, update_channel_chats_seen_state, remove_channel, set_refreshing, reset_channels_state } = store_state.actions

export default store_state.reducer