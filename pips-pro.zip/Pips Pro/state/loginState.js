import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  logged_in: false,
  current_route: 'Watchlist',
  darkmode: false,
  user_details: {
    username: '',
    email: '',
    user_id: null,
    profile_image: null,
    color_code: '#FFFFFF',
    premium_account: false
  },
  accessToken: '',
  reset_password: false
}

export const store_state = createSlice({
  name: 'login_state',
  initialState,
  reducers: {
    set_logged_in: (state, action) => {
      state.logged_in = action.payload.value;
    },
    set_current_route: (state, action) => {
      state.current_route = action.payload.value;
    },
    set_darkmode: (state, action) => {
      state.darkmode = action.payload.value;
    },
    set_user_details: (state, action) => {
      state.user_details = action.payload.details;
    },
    set_accessToken: (state, action) => {
      state.accessToken = action.payload.token;
    },
    set_reset_password: (state, action) => {
      state.reset_password = action.payload.value;
    },
    reset_data: (state, action) => {
      state.logged_in = false;
      state.user_details = {
        username: '',
        email: '',
        user_id: 0,
        profile_image: null,
        color_code: '#FFFFFF',
        premium_account: false
      };
      state.accessToken = '';
    }
  },
})

// Action creators are generated for each case reducer function
export const { set_logged_in, set_current_route, set_darkmode, set_user_details, set_accessToken, set_reset_password, reset_data } = store_state.actions

export default store_state.reducer