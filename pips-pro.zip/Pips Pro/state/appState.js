import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  backend_api: 'http://172.20.10.14:3000'
}

export const store_state = createSlice({
  name: 'app_state',
  initialState,
  reducers: {
    set_backend_api: (state, action) => {
      state.backend_api = action.payload.value;
    }
  },
})

// Action creators are generated for each case reducer function
export const { set_backend_api } = store_state.actions

export default store_state.reducer