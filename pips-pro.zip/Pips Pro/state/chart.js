import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  btm_sheet_index: -1,
  enable_btm_sheet: false,
  btm_sheet_option: null,
  idea_category: null,
  user_selected_categories: [],
  categories_list: [{ id: 1, title: 'Time horizon', checked: false, expanded: false, sub_list: [{ id: 5, title: 'Day trade', checked: false }, { id: 6, title: 'Swing trade', checked: false }, { id: 7, title: 'Position trade', checked: false }, { id: 8, title: 'Scalping', checked: false }, { id: 9, title: 'Investment', checked: false }] }, { id: 2, title: 'Trend analysis', checked: false, expanded: false, sub_list: [{ id: 10, title: 'Uptrend', checked: false }, { id: 11, title: 'Downtrend', checked: false }, { id: 12, title: 'Sideways/Range-bound', checked: false }, { id: 13, title: 'Reversal', checked: false }, { id: 14, title: 'Fibonacci', checked: false }, { id: 15, title: 'Cycles', checked: false }, { id: 16, title: 'Pivot points', checked: false }] }, { id: 3, title: 'Enter and exit strategy', checked: false, expanded: false, sub_list: [{ id: 17, title: 'Entry price', checked: false }, { id: 18, title: 'Target price', checked: false }, { id: 19, title: 'Stop loss level', checked: false }] }, { id: 4, title: 'Technical indicators', checked: false, expanded: false, sub_list: [{ id: 20, title: 'Moving average', checked: false }, { id: 21, title: 'Relative Strength Index', checked: false }, { id: 22, title: 'Oscillators', checked: false }, { id: 23, title: 'Volume', checked: false }, { id: 24, title: 'Volatility', checked: false }, { id: 25, title: 'Candlestick patterns', checked: false }] }, { id: 26, title: 'Fundamental analysis', checked: false, expanded: false, sub_list: [{ id: 27, title: 'Growth', checked: false }, { id: 28, title: 'Earnings', checked: false }, { id: 29, title: 'Dividends', checked: false }, { id: 30, title: 'Value', checked: false }] }],
  user_selected_market_type: null,
  market_types_list: [{ id: 1, title: 'Stock' }, { id: 2, title: 'Forex' }, { id: 3, title: 'Crypto' }]
}

export const store_state = createSlice({
  name: 'chart_state',
  initialState,
  reducers: {
    set_btm_sheet_index: (state, action) => {
      state.btm_sheet_index = action.payload.value;
    },

    set_enable_btm_sheet: (state, action) => {
      state.enable_btm_sheet = action.payload.value;
    },

    set_btm_sheet_option: (state, action) => {
      state.btm_sheet_option = action.payload.value;
    },

    set_idea_category: (state, action) => {
      state.idea_category = action.payload.value;
    },

    update_category_expansion: (state, action) => {
      let category_index = action.payload.index; // The index of the category
      let exp_value = action.payload.exp_value; // The new expansion value of the category

      state.categories_list[category_index].expanded = exp_value; // Update the expansion value of the category
    },

    update_main_category_list_chkbox: (state, action) => {
      let main_category_index = action.payload.index; // The index of the main category
      let main_checked_value = action.payload.checked_value; // The new checked value of the main category
      let count = 0;

      // Loop through the user selected categories list to see if the user has added the current category to the list
      for (const [index, category] of state.user_selected_categories.entries()) {
        if (state.categories_list[main_category_index].id === category.id){
          count = count + 1;
        }
      }

      if (count > 0){
        state.categories_list[main_category_index].checked = false; // Update the checked value of the main category
        for (const [index, category] of state.user_selected_categories.entries()) {
          if (state.categories_list[main_category_index].id === category.id){
            state.user_selected_categories.splice(index, 1);
          }
        }
      } else {
        if (state.user_selected_categories.length !== 3){
          state.categories_list[main_category_index].checked = true; // Update the checked value of the main category
          let selected_category = { id: state.categories_list[main_category_index].id, title: state.categories_list[main_category_index].title };
          state.user_selected_categories.push(selected_category);
        } else {
          // Do nothing since the user has already selected a max of 3 categories
        }
      }
    },

    update_sub_category_list_chkbox: (state, action) => {
      let main_category_index = action.payload.main_index; // The index of the main category
      let sub_category_index = action.payload.sub_index; // The index of the sub category
      let checked_value = action.payload.checked_value; // The new checked value of the category

      //state.categories_list[main_category_index].sub_list[sub_category_index].checked = checked_value; // Update the checked value of the sub category
    
      let count = 0;

      for (const [index, category] of state.user_selected_categories.entries()) {
        if (state.categories_list[main_category_index].sub_list[sub_category_index].id === category.id){
          count = count + 1;
        }
      }

      if (count > 0){
        state.categories_list[main_category_index].sub_list[sub_category_index].checked = false; // Update the checked value of the main category
        for (const [index, category] of state.user_selected_categories.entries()) {
          if (state.categories_list[main_category_index].sub_list[sub_category_index].id === category.id){
            state.user_selected_categories.splice(index, 1);
            state.category_disabled = false;
          }
        }
      } else {
        if (state.user_selected_categories.length !== 3){
          state.categories_list[main_category_index].sub_list[sub_category_index].checked = true; // Update the checked value of the main category
          let selected_category = { id: state.categories_list[main_category_index].sub_list[sub_category_index].id, title: state.categories_list[main_category_index].sub_list[sub_category_index].title };
          state.user_selected_categories.push(selected_category);
        } else {
          // Do nothing since the user has already selected a max of 3 categories
        }
      }
    },

    remove_category: (state, action) => {
      let category_id = action.payload.id; // The ID of the selected category

      // Loop through the categories list to find out the category that the user wants to remove from the user selected categories list
      for (const [index, category] of state.categories_list.entries()) {
        if (category.id === category_id){ // Check if the current category ID is the same as the ID of the category that the user wants to remove
          category.checked = false; // Disable the checkbox for the category

          // Loop through the user selected categories list and remove the category that the user wants removed
          for (const [i, selected_category] of state.user_selected_categories.entries()) {
            if (selected_category.id === category_id){
              state.user_selected_categories.splice(i, 1);
              state.category_disabled = false;
            }
          }
        } else {
          // Since the current category was not found amongst the main categories, check the sub categories of each main category
          for (const [i, selected_category] of category.sub_list.entries()) {
            if (selected_category.id === category_id){
              selected_category.checked = false;

              // Loop through the user selected categories list and remove the category that the user wants removed
              for (const [index1, selected_category1] of state.user_selected_categories.entries()) {
                if (selected_category1.id === category_id){
                  state.user_selected_categories.splice(index1, 1);
                  state.category_disabled = false;
                }
              }
            }
          }
        }
      }
    },

    set_user_selected_market_type: (state, action) => {
      state.user_selected_market_type = action.payload.value;
    },

    reset_chart_state_data: (state, action) => {
      state.btm_sheet_index = -1;
      state.enable_btm_sheet = false;
      state.btm_sheet_option = null;
      state.idea_category = null;
      state.user_selected_categories = [];
      state.categories_list = [{ id: 1, title: 'Trend analysis', checked: false, expanded: false, sub_list: [{ id: 5, title: 'Pivot points', checked: false }, { id: 6, title: 'Trend lines', checked: false }] }, { id: 2, title: 'Technical indicators', checked: false, expanded: false, sub_list: [{ id: 7, title: 'Volatility', checked: false }, { id: 8, title: 'Oscillators', checked: false }] }, { id: 3, title: 'Chart patterns', checked: false, expanded: false, sub_list: [{ id: 9, title: 'Flag', checked: false }, { id: 10, title: 'Head and Shoulders', checked: false }] }];
      state.user_selected_market_type = null;
      state.market_types_list = [{ id: 1, title: 'Stock' }, { id: 2, title: 'Forex' }, { id: 3, title: 'Crypto' }];
    }
  },
})

// Action creators are generated for each case reducer function
export const { set_btm_sheet_index, set_enable_btm_sheet, set_btm_sheet_option, set_idea_category, update_category_expansion, update_main_category_list_chkbox, update_sub_category_list_chkbox, remove_category, set_user_selected_market_type, reset_chart_state_data } = store_state.actions

export default store_state.reducer