import { configureStore } from '@reduxjs/toolkit';
import login_state from '../state/loginState';
import watch_list_state from '../state/watchListState';
import chart from '../state/chart';
import channels from '../state/channels';
import app_state from '../state/appState';
import news from '../state/news';
import chat from '../state/chat';
import trade_ideas from '../state/trade_ideas'
import community from '../state/community'

export const store = configureStore({
  reducer: {
    login_state: login_state,
    watch_list_state: watch_list_state,
    chart: chart,
    channels: channels,
    app_state: app_state,
    news: news,
    chat: chat,
    trade_ideas: trade_ideas,
    community: community
  }
})